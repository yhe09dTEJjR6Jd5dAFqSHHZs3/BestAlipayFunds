# -*- coding: utf-8 -*-
from __future__ import annotations

import concurrent.futures
import ctypes
import datetime as _dt
import gzip
import json
import math
import os
import queue
import random
import re
import statistics
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


APP_NAME = "Best Alipay Funds"
VERSION = "2.0.0"
REFRESH_SECONDS = 10
MIN_HISTORY_POINTS = 680
MIN_PYTHON = (3, 10)
BASE_DIR = Path(__file__).resolve().parent
CACHE_PATH = BASE_DIR / "BestAlipayFunds_cache.json.gz"
MODEL_PATH = BASE_DIR / "BestAlipayFunds_AI.json"
CACHE_VERSION = 4
MODEL_VERSION = 3
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
)


class DataError(RuntimeError):
    pass


def _now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def _parse_iso(value: str | None) -> _dt.datetime | None:
    if not value:
        return None
    try:
        return _dt.datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None


def _finite(value, default=0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _compound(values) -> float:
    total = 1.0
    for value in values:
        total *= max(0.01, 1.0 + _clamp(_finite(value), -0.95, 3.0))
    return total - 1.0


def _max_drawdown(values) -> float:
    wealth = 1.0
    peak = 1.0
    worst = 0.0
    for value in values:
        wealth *= max(0.01, 1.0 + _clamp(_finite(value), -0.95, 3.0))
        peak = max(peak, wealth)
        worst = min(worst, wealth / peak - 1.0)
    return worst


def _pearson(xs, ys) -> float:
    if len(xs) != len(ys) or len(xs) < 3:
        return 0.0
    mx = sum(xs) / len(xs)
    my = sum(ys) / len(ys)
    numerator = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = sum((x - mx) ** 2 for x in xs)
    dy = sum((y - my) ** 2 for y in ys)
    if dx <= 1e-15 or dy <= 1e-15:
        return 0.0
    return numerator / math.sqrt(dx * dy)


def _rank_scale(values) -> list[float]:
    count = len(values)
    if count <= 1:
        return [0.0] * count
    order = sorted(range(count), key=lambda i: (_finite(values[i]), i))
    result = [0.0] * count
    start = 0
    while start < count:
        end = start + 1
        current = _finite(values[order[start]])
        while end < count and abs(_finite(values[order[end]]) - current) < 1e-12:
            end += 1
        average_rank = (start + end - 1) / 2.0
        scaled = 2.0 * average_rank / (count - 1) - 1.0
        for position in range(start, end):
            result[order[position]] = scaled
        start = end
    return result


def _atomic_bytes(path: Path, data: bytes) -> None:
    temp = path.with_name(path.name + ".tmp")
    with open(temp, "wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp, path)


def _write_json(path: Path, payload) -> None:
    raw = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
    _atomic_bytes(path, raw)


def _read_json(path: Path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError, TypeError):
        return default


def _decode_response(raw: bytes, charset: str | None) -> str:
    candidates = [charset, "utf-8-sig", "utf-8", "gb18030"]
    for candidate in candidates:
        if not candidate:
            continue
        try:
            return raw.decode(candidate)
        except (LookupError, UnicodeDecodeError):
            pass
    return raw.decode("utf-8", errors="replace")


def _http_text(
    url: str,
    *,
    data: dict | None = None,
    referer: str = "https://fund.eastmoney.com/",
    timeout: float = 9.0,
    attempts: int = 2,
) -> str:
    encoded = None
    if data is not None:
        encoded = urllib.parse.urlencode(data).encode("utf-8")
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/json,text/javascript,*/*;q=0.8",
        "Accept-Encoding": "gzip",
        "Referer": referer,
        "Cache-Control": "no-cache",
        "X-Requested-With": "XMLHttpRequest",
    }
    if encoded is not None:
        headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
    last_error = None
    for attempt in range(attempts):
        try:
            request = urllib.request.Request(url, data=encoded, headers=headers)
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read()
                if response.headers.get("Content-Encoding", "").lower() == "gzip":
                    raw = gzip.decompress(raw)
                return _decode_response(raw, response.headers.get_content_charset())
        except (OSError, urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as exc:
            last_error = exc
            if attempt + 1 < attempts:
                time.sleep(0.35 * (attempt + 1) + random.random() * 0.2)
    raise DataError(f"网络请求失败：{last_error}")


def _http_json(url: str, **kwargs):
    text = _http_text(url, **kwargs)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        match = re.search(r"\{[\s\S]*\}", text)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                pass
        raise DataError(f"数据格式无法识别：{exc}") from exc


def _coarse_type(value: str) -> str:
    text = value or "其他"
    if "债" in text:
        return "债券"
    if "指数" in text or "ETF" in text:
        return "指数"
    if "股票" in text:
        return "股票"
    if "混合" in text:
        return "混合"
    if "QDII" in text.upper() or "海外" in text:
        return "QDII"
    if "FOF" in text.upper() or "基金中基金" in text:
        return "FOF"
    return "其他"


def _base_name(name: str) -> str:
    value = re.sub(r"[（(](人民币|前端|后端|场外)[）)]", "", name or "")
    value = re.sub(r"(?:ETF)?联接基金?([AC])?$", "联接", value, flags=re.I)
    value = re.sub(r"(?:人民币)?[A-EH-IY]类?$", "", value, flags=re.I)
    value = re.sub(r"[\s·\-_（）()]", "", value)
    return value


def _share_preference(name: str) -> int:
    compact = (name or "").strip().upper()
    if re.search(r"A类?$", compact):
        return 4
    if re.search(r"C类?$", compact):
        return 2
    if re.search(r"[BDEHIY]类?$", compact):
        return 0
    return 3


def _theme(name: str) -> str:
    groups = {
        "医药医疗": ("医药", "医疗", "生物", "创新药"),
        "科技半导体": ("科技", "半导体", "芯片", "软件", "计算机", "人工智能", "机器人"),
        "新能源": ("新能源", "光伏", "电池", "汽车"),
        "消费": ("消费", "白酒", "食品", "家电"),
        "周期资源": ("煤炭", "有色", "钢铁", "资源", "化工", "黄金"),
        "军工": ("军工", "国防", "航天"),
        "金融地产": ("金融", "银行", "证券", "地产"),
        "海外": ("全球", "海外", "美国", "纳斯达克", "标普", "港股", "恒生"),
    }
    for label, words in groups.items():
        if any(word in (name or "") for word in words):
            return label
    return "宽基/全市场"


def _candidate_allowed(name: str, fund_type: str) -> bool:
    text = f"{name} {fund_type}".upper()
    blocked = (
        "货币", "理财", "同业存单", "REIT", "封闭", "定期开放", "定开", "持有期",
        "滚动持有", "后端", "分级", "杠杆", "商品", "原油", "白银",
    )
    if any(word.upper() in text for word in blocked):
        return False
    if not re.fullmatch(r"[\s\S]{2,80}", name or ""):
        return False
    return _coarse_type(fund_type) != "其他" and _share_preference(name) > 0


class FundDataSource:
    RANK_URL = "https://fund.eastmoney.com/data/rankhandler.aspx"
    LIST_URL = "https://fund.eastmoney.com/js/fundcode_search.js"
    HISTORY_URL = "https://api.fund.eastmoney.com/f10/lsjz"
    PING_URL = "https://fund.eastmoney.com/pingzhongdata/{code}.js"
    MOBILE_BASE = "https://fundmobapi.eastmoney.com/FundMNewApi"

    SEED_CODES = (
        "000001", "000311", "000478", "001015", "001938", "005827", "007119",
        "010854", "050011", "100038", "110007", "110020", "161005", "163406",
        "202101", "217022", "260108", "519697", "519732", "270002",
    )

    def _rank_page(self, fund_type: str, sort_key: str, count: int) -> list[dict]:
        today = _dt.date.today()
        try:
            start = today.replace(year=today.year - 6)
        except ValueError:
            start = today - _dt.timedelta(days=365 * 6)
        params = {
            "op": "ph", "dt": "kf", "ft": fund_type, "rs": "", "gs": "0",
            "sc": sort_key, "st": "desc", "sd": start.isoformat(), "ed": today.isoformat(),
            "qdii": "", "tabSubtype": ",,,,,", "pi": "1", "pn": str(count),
            "dx": "1", "v": f"{random.random():.16f}",
        }
        text = _http_text(self.RANK_URL + "?" + urllib.parse.urlencode(params))
        match = re.search(r"datas\s*:\s*(\[[\s\S]*?\])\s*,\s*allRecords", text)
        if not match:
            raise DataError("基金排行接口返回异常")
        try:
            rows = json.loads(match.group(1))
        except json.JSONDecodeError as exc:
            raise DataError("基金排行解析失败") from exc
        result = []
        for rank, row in enumerate(rows):
            fields = row.split(",")
            if len(fields) < 4 or not re.fullmatch(r"\d{6}", fields[0]):
                continue
            result.append({
                "code": fields[0], "name": fields[1].strip(), "type": fields[3].strip(),
                "rank": rank, "count": max(1, len(rows)),
            })
        return result

    def _all_funds(self) -> list[dict]:
        text = _http_text(self.LIST_URL)
        start, end = text.find("["), text.rfind("]")
        if start < 0 or end <= start:
            raise DataError("基金清单接口返回异常")
        try:
            rows = json.loads(text[start:end + 1])
        except json.JSONDecodeError as exc:
            raise DataError("基金清单解析失败") from exc
        funds = []
        for row in rows:
            if not isinstance(row, list) or len(row) < 4 or not re.fullmatch(r"\d{6}", str(row[0])):
                continue
            funds.append({"code": str(row[0]), "name": str(row[2]), "type": str(row[3])})
        return funds

    def candidates(self, progress=lambda *_: None) -> list[dict]:
        tasks = [
            ("all", "6yzf", 150), ("all", "1nzf", 150), ("all", "2nzf", 150),
            ("all", "3nzf", 170), ("all", "5nzf", 140),
            ("gp", "3nzf", 65), ("hh", "3nzf", 70), ("zq", "3nzf", 80),
            ("zs", "3nzf", 70), ("qdii", "3nzf", 45), ("fof", "3nzf", 45),
        ]
        aggregate: dict[str, dict] = {}
        failures = 0
        for index, (fund_type, sort_key, count) in enumerate(tasks, 1):
            progress(f"获取候选池 {index}/{len(tasks)}", 2 + 8 * index / len(tasks))
            try:
                rows = self._rank_page(fund_type, sort_key, count)
            except DataError:
                failures += 1
                continue
            horizon_weight = {"6yzf": 0.65, "1nzf": 0.85, "2nzf": 1.0, "3nzf": 1.15, "5nzf": 1.25}.get(sort_key, 1.0)
            for row in rows:
                if not _candidate_allowed(row["name"], row["type"]):
                    continue
                quality = horizon_weight * (1.15 - row["rank"] / row["count"])
                item = aggregate.setdefault(row["code"], {
                    "code": row["code"], "name": row["name"], "type": row["type"], "prefilter": 0.0,
                })
                item["name"], item["type"] = row["name"], row["type"]
                item["prefilter"] += quality

        all_funds = []
        if len(aggregate) < 90 or failures >= 6:
            progress("排行源不完整，启用全量清单降级", 10)
            all_funds = self._all_funds()
            for position, fund in enumerate(all_funds):
                if not _candidate_allowed(fund["name"], fund["type"]):
                    continue
                if fund["code"] in self.SEED_CODES or position % 97 == 0:
                    item = dict(fund)
                    item["prefilter"] = 0.25
                    aggregate.setdefault(fund["code"], item)

        by_base: dict[str, dict] = {}
        for item in aggregate.values():
            key = _base_name(item["name"])
            old = by_base.get(key)
            if old is None or (item["prefilter"], _share_preference(item["name"])) > (
                old["prefilter"], _share_preference(old["name"])
            ):
                by_base[key] = item

        quotas = {"混合": 46, "股票": 27, "指数": 31, "债券": 37, "QDII": 12, "FOF": 10, "其他": 0}
        groups: dict[str, list[dict]] = {key: [] for key in quotas}
        for item in by_base.values():
            groups.setdefault(_coarse_type(item["type"]), []).append(item)
        selected = []
        for group, quota in quotas.items():
            ranked = sorted(groups.get(group, []), key=lambda item: item["prefilter"], reverse=True)
            selected.extend(ranked[:quota])

        known = {item["code"] for item in selected}
        lookup = {item["code"]: item for item in aggregate.values()}
        if not all_funds:
            try:
                all_funds = self._all_funds()
            except DataError:
                all_funds = []
        full_lookup = {item["code"]: item for item in all_funds}
        for code in self.SEED_CODES:
            if code in known:
                continue
            item = lookup.get(code) or full_lookup.get(code)
            if item and _candidate_allowed(item["name"], item["type"]):
                selected.append({**item, "prefilter": _finite(item.get("prefilter"), 0.2)})
                known.add(code)
        if len(selected) < 65:
            raise DataError("可分析的开放式基金候选不足，请稍后重试")
        return selected[:180]

    @staticmethod
    def _history_rows(payload) -> tuple[list[dict], int]:
        if not isinstance(payload, dict):
            return [], 0
        data = payload.get("Data")
        if isinstance(data, dict):
            rows = data.get("LSJZList") or []
            total = int(_finite(data.get("TotalCount"), len(rows)))
            return rows, total
        rows = payload.get("Datas") or []
        total = int(_finite(payload.get("TotalCount"), len(rows)))
        return rows, total

    @staticmethod
    def _normalize_history(rows: list[dict]) -> dict:
        clean = []
        for row in rows:
            date = str(row.get("FSRQ") or "")[:10]
            nav = _finite(row.get("DWJZ"), float("nan"))
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) or not math.isfinite(nav) or nav <= 0:
                continue
            change_raw = row.get("JZZZL")
            change = None if change_raw in (None, "", "--") else _finite(change_raw) / 100.0
            clean.append((date, nav, change))
        clean.sort(key=lambda item: item[0])
        dedup = {}
        for item in clean:
            dedup[item[0]] = item
        clean = list(dedup.values())
        dates, returns = [], []
        previous_nav = None
        for date, nav, source_change in clean:
            dates.append(date)
            if previous_nav is None:
                value = 0.0
            elif source_change is not None and -0.8 < source_change < 2.0:
                value = source_change
            else:
                value = nav / previous_nav - 1.0
            returns.append(_clamp(value, -0.8, 2.0))
            previous_nav = nav
        return {
            "dates": dates, "returns": returns,
            "latest_nav": clean[-1][1] if clean else None,
            "latest_date": clean[-1][0] if clean else "",
        }

    def _ping_history(self, code: str, start: _dt.date) -> dict:
        params = urllib.parse.urlencode({"v": int(time.time() * 1000)})
        text = _http_text(
            self.PING_URL.format(code=code) + "?" + params,
            referer=f"https://fund.eastmoney.com/{code}.html",
            attempts=1,
        )
        match = re.search(r"var\s+Data_netWorthTrend\s*=\s*(\[[\s\S]*?\])\s*;", text)
        if not match:
            raise DataError(f"{code} 走势图数据缺失")
        try:
            source_rows = json.loads(match.group(1))
        except json.JSONDecodeError:
            source_rows = []
            for object_text in re.findall(r"\{[^{}]*\}", match.group(1)):
                x_match = re.search(r'["\']?x["\']?\s*:\s*(\d+)', object_text)
                y_match = re.search(r'["\']?y["\']?\s*:\s*(-?\d+(?:\.\d+)?)', object_text)
                r_match = re.search(r'["\']?equityReturn["\']?\s*:\s*(-?\d+(?:\.\d+)?)', object_text)
                if x_match and y_match:
                    source_rows.append({
                        "x": int(x_match.group(1)), "y": float(y_match.group(1)),
                        "equityReturn": float(r_match.group(1)) if r_match else None,
                    })
        rows = []
        for row in source_rows:
            try:
                day = _dt.datetime.fromtimestamp(float(row.get("x")) / 1000.0, tz=_dt.timezone.utc).date()
            except (TypeError, ValueError, OSError, OverflowError):
                continue
            if day < start:
                continue
            rows.append({
                "FSRQ": day.isoformat(), "DWJZ": row.get("y"), "JZZZL": row.get("equityReturn"),
            })
        result = self._normalize_history(rows)
        if len(result["dates"]) < 450:
            raise DataError(f"{code} 走势图历史不足")
        name_match = re.search(r"var\s+fS_name\s*=\s*['\"]([^'\"]+)['\"]", text)
        if name_match:
            result["name"] = name_match.group(1).strip()
        return result

    def history(self, code: str) -> dict:
        today = _dt.date.today()
        start = today - _dt.timedelta(days=365 * 6 + 30)
        errors = []
        try:
            return self._ping_history(code, start)
        except DataError as exc:
            errors.append(str(exc))

        mobile_params = {
            "FCODE": code, "pageIndex": 1, "pageSize": 1600, "plat": "Android",
            "appType": "ttjj", "product": "EFund", "version": "6.2.4",
            "deviceid": "best-alipay-funds-local",
        }
        try:
            payload = _http_json(
                f"{self.MOBILE_BASE}/FundMNHisNetList?" + urllib.parse.urlencode(mobile_params),
                attempts=1,
            )
            rows, _ = self._history_rows(payload)
            result = self._normalize_history(rows)
            if len(result["dates"]) >= 450:
                return result
        except DataError as exc:
            errors.append(str(exc))

        params = {
            "fundCode": code, "pageIndex": 1, "pageSize": 1600,
            "startDate": start.isoformat(), "endDate": today.isoformat(),
            "_": int(time.time() * 1000),
        }
        try:
            payload = _http_json(
                self.HISTORY_URL + "?" + urllib.parse.urlencode(params),
                referer="https://fundf10.eastmoney.com/",
                attempts=1,
            )
            rows, total = self._history_rows(payload)
            if len(rows) >= 450 or total <= len(rows):
                result = self._normalize_history(rows)
                if len(result["dates"]) >= 450:
                    return result
        except DataError as exc:
            errors.append(str(exc))
        raise DataError(f"{code} 历史净值不足或暂不可用：{'；'.join(errors[-2:]) or '数据不足'}")

    def latest(self, codes: list[str]) -> dict[str, dict]:
        if not codes:
            return {}
        params = {
            "pageIndex": 1, "pageSize": max(10, len(codes)), "plat": "Android",
            "appType": "ttjj", "product": "EFund", "Version": "6.2.4",
            "deviceid": "best-alipay-funds-local", "Fcodes": ",".join(codes),
        }
        payload = _http_json(
            f"{self.MOBILE_BASE}/FundMNFInfo?" + urllib.parse.urlencode(params),
            attempts=2,
        )
        output = {}
        for row in payload.get("Datas") or []:
            code = str(row.get("FCODE") or "")
            if code not in codes:
                continue
            output[code] = {
                "code": code,
                "name": str(row.get("SHORTNAME") or "").strip(),
                "nav": _finite(row.get("NAV"), float("nan")),
                "day_change": _finite(row.get("NAVCHGRT"), float("nan")),
                "nav_date": str(row.get("PDATE") or "")[:10],
            }
        if not output:
            raise DataError("最新披露净值暂不可用")
        return output


class LocalStore:
    def __init__(self):
        self.cache = self._load_cache()
        self.model = self._load_model()

    @staticmethod
    def _load_cache() -> dict:
        try:
            with gzip.open(CACHE_PATH, "rt", encoding="utf-8") as handle:
                data = json.load(handle)
            if data.get("version") != CACHE_VERSION:
                raise ValueError("version")
            data.setdefault("funds", {})
            return data
        except (OSError, ValueError, TypeError, EOFError):
            return {"version": CACHE_VERSION, "updated_at": None, "funds": {}}

    @staticmethod
    def default_model() -> dict:
        return {
            "version": MODEL_VERSION,
            "trained_at": None,
            "feature_names": AdaptiveRanker.FEATURE_NAMES,
            "weights": [0.0] * len(AdaptiveRanker.FEATURE_NAMES),
            "validation_ic": 0.0,
            "blend": 0.0,
            "training_samples": 0,
            "universe_size": 0,
            "engine": "walk-forward ridge ensemble + risk expert",
        }

    def _load_model(self) -> dict:
        model = _read_json(MODEL_PATH, self.default_model())
        if (
            model.get("version") != MODEL_VERSION
            or model.get("feature_names") != AdaptiveRanker.FEATURE_NAMES
            or len(model.get("weights") or []) != len(AdaptiveRanker.FEATURE_NAMES)
        ):
            model = self.default_model()
        if not MODEL_PATH.exists():
            try:
                _write_json(MODEL_PATH, model)
            except OSError:
                pass
        return model

    def save_cache(self) -> None:
        raw = json.dumps(self.cache, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        _atomic_bytes(CACHE_PATH, gzip.compress(raw, compresslevel=6))

    def save_model(self, model: dict) -> None:
        _write_json(MODEL_PATH, model)
        self.model = model


class AdaptiveRanker:
    FEATURE_NAMES = [
        "return_6m", "return_1y", "return_3y_ann", "sharpe_3y", "sortino_3y",
        "calmar_3y", "drawdown_quality", "volatility_quality", "worst_year",
        "positive_months", "trend_quality", "tail_quality", "stability_quality",
        "recovery_quality",
    ]
    EXPERT_WEIGHTS = [0.35, 0.55, 0.75, 0.90, 0.65, 0.75, 1.05, 0.55, 0.75, 0.45, 0.30, 0.50, 0.55, 0.25]

    @staticmethod
    def features(returns: list[float], end: int | None = None) -> tuple[list[float], dict] | None:
        end = len(returns) if end is None else min(end, len(returns))
        if end < MIN_HISTORY_POINTS:
            return None
        clean = [_clamp(_finite(value), -0.8, 2.0) for value in returns[:end]]
        long_n = min(756, len(clean) - 1)
        long_values = clean[-long_n:]

        ret_6m = _compound(clean[-min(126, len(clean)):])
        ret_1y = _compound(clean[-min(252, len(clean)):])
        total_long = _compound(long_values)
        years = max(long_n / 252.0, 0.25)
        ann = (max(0.01, 1.0 + total_long) ** (1.0 / years)) - 1.0
        daily_mean = sum(long_values) / len(long_values)
        daily_std = statistics.pstdev(long_values) if len(long_values) > 1 else 0.0
        volatility = daily_std * math.sqrt(252)
        risk_free = 0.015
        sharpe = (daily_mean * 252 - risk_free) / max(volatility, 0.015)
        downside = math.sqrt(sum(min(0.0, r - risk_free / 252) ** 2 for r in long_values) / len(long_values)) * math.sqrt(252)
        sortino = (daily_mean * 252 - risk_free) / max(downside, 0.01)
        max_dd = _max_drawdown(long_values)
        calmar = (ann - risk_free) / max(abs(max_dd), 0.035)

        month_returns = []
        for start in range(max(0, len(long_values) - 504), len(long_values), 21):
            segment = long_values[start:min(start + 21, len(long_values))]
            if len(segment) >= 12:
                month_returns.append(_compound(segment))
        positive_months = sum(value > 0 for value in month_returns) / max(1, len(month_returns))

        rolling_year = []
        recent = long_values[-min(756, len(long_values)):]
        if len(recent) >= 252:
            for finish in range(252, len(recent) + 1, 21):
                rolling_year.append(_compound(recent[finish - 252:finish]))
        worst_year = min(rolling_year) if rolling_year else ret_1y

        rolling_quarter = []
        if len(recent) >= 63:
            for finish in range(63, len(recent) + 1, 21):
                rolling_quarter.append(_compound(recent[finish - 63:finish]))
        stability = -(statistics.pstdev(rolling_quarter) if len(rolling_quarter) > 1 else 0.0)

        trend_values = clean[-min(252, len(clean)):]
        logs = []
        wealth = 1.0
        for value in trend_values:
            wealth *= max(0.01, 1.0 + value)
            logs.append(math.log(max(wealth, 1e-9)))
        n = len(logs)
        x_mean = (n - 1) / 2.0
        y_mean = sum(logs) / n
        xx = sum((i - x_mean) ** 2 for i in range(n))
        xy = sum((i - x_mean) * (logs[i] - y_mean) for i in range(n))
        slope = xy / max(xx, 1e-12)
        fitted_var = sum((slope * (i - x_mean)) ** 2 for i in range(n))
        total_var = sum((value - y_mean) ** 2 for value in logs)
        r2 = _clamp(fitted_var / max(total_var, 1e-12), 0.0, 1.0)
        trend_quality = _clamp(slope * 252, -1.0, 1.5) * (0.35 + 0.65 * r2)

        sorted_returns = sorted(long_values)
        tail_count = max(5, int(len(sorted_returns) * 0.05))
        cvar = sum(sorted_returns[:tail_count]) / tail_count

        recent_year = clean[-min(252, len(clean)):]
        wealth = peak = 1.0
        for value in recent_year:
            wealth *= max(0.01, 1.0 + value)
            peak = max(peak, wealth)
        recovery = wealth / peak - 1.0

        vector = [
            ret_6m, ret_1y, ann, _clamp(sharpe, -5, 8), _clamp(sortino, -5, 12),
            _clamp(calmar, -5, 10), max_dd, -volatility, worst_year, positive_months,
            trend_quality, -abs(cvar) * math.sqrt(252), stability, recovery,
        ]
        stats = {
            "return_6m": ret_6m, "return_1y": ret_1y, "return_3y_ann": ann,
            "volatility": volatility, "max_drawdown": max_dd, "sharpe": sharpe,
            "sortino": sortino, "calmar": calmar, "positive_months": positive_months,
            "worst_year": worst_year, "current_drawdown": recovery, "observations": end,
        }
        return vector, stats

    @staticmethod
    def _solve_ridge(xs: list[list[float]], ys: list[float], sample_weights: list[float], lam: float) -> list[float]:
        columns = len(xs[0])
        matrix = [[0.0] * columns for _ in range(columns)]
        target = [0.0] * columns
        for row, y, weight in zip(xs, ys, sample_weights):
            for i in range(columns):
                target[i] += weight * row[i] * y
                for j in range(i, columns):
                    matrix[i][j] += weight * row[i] * row[j]
        for i in range(columns):
            matrix[i][i] += lam
            for j in range(i):
                matrix[i][j] = matrix[j][i]
        augmented = [matrix[i][:] + [target[i]] for i in range(columns)]
        for pivot in range(columns):
            best = max(range(pivot, columns), key=lambda row: abs(augmented[row][pivot]))
            augmented[pivot], augmented[best] = augmented[best], augmented[pivot]
            divisor = augmented[pivot][pivot]
            if abs(divisor) < 1e-12:
                continue
            for column in range(pivot, columns + 1):
                augmented[pivot][column] /= divisor
            for row in range(columns):
                if row == pivot:
                    continue
                factor = augmented[row][pivot]
                if abs(factor) < 1e-15:
                    continue
                for column in range(pivot, columns + 1):
                    augmented[row][column] -= factor * augmented[pivot][column]
        return [augmented[i][-1] for i in range(columns)]

    def train(self, funds: list[dict]) -> dict:
        snapshots = []
        for offset in range(1, 19):
            rows = []
            for fund in funds:
                returns = fund["returns"]
                end = len(returns) - 63 * offset
                if end < MIN_HISTORY_POINTS or end + 63 > len(returns):
                    continue
                feature_result = self.features(returns, end)
                if not feature_result:
                    continue
                forward = returns[end:end + 63]
                forward_return = _compound(forward)
                forward_drawdown = abs(_max_drawdown(forward))
                forward_vol = (statistics.pstdev(forward) * math.sqrt(252)) if len(forward) > 1 else 0.0
                utility = forward_return - 0.55 * forward_drawdown - 0.08 * forward_vol
                rows.append((feature_result[0], utility))
            if len(rows) < 24:
                continue
            feature_columns = list(zip(*(row[0] for row in rows)))
            scaled_columns = [_rank_scale(list(column)) for column in feature_columns]
            targets = _rank_scale([row[1] for row in rows])
            scaled_rows = [[scaled_columns[j][i] for j in range(len(self.FEATURE_NAMES))] for i in range(len(rows))]
            snapshots.append((offset, scaled_rows, targets))

        training_x, training_y, training_w = [], [], []
        validation_x, validation_y = [], []
        for offset, rows, targets in snapshots:
            if offset <= 3:
                validation_x.extend(rows)
                validation_y.extend(targets)
            else:
                weight = math.exp(-0.045 * offset)
                training_x.extend(rows)
                training_y.extend(targets)
                training_w.extend([weight] * len(rows))

        if len(training_x) < 180 or len(validation_x) < 40:
            model = LocalStore.default_model()
            model.update({"trained_at": _now_iso(), "universe_size": len(funds)})
            return model

        best_weights, best_ic, best_lambda = None, -9.0, None
        for lam in (0.15, 0.5, 1.5, 4.0):
            weights = self._solve_ridge(training_x, training_y, training_w, lam)
            predictions = [sum(w * x for w, x in zip(weights, row)) for row in validation_x]
            ic = _pearson(predictions, validation_y)
            if ic > best_ic:
                best_weights, best_ic, best_lambda = weights, ic, lam
        best_weights = [_clamp(_finite(value), -2.0, 2.0) for value in (best_weights or [])]
        scale = sum(abs(value) for value in best_weights) or 1.0
        best_weights = [value / scale for value in best_weights]
        blend = _clamp(0.25 + max(0.0, best_ic) * 1.6, 0.22, 0.68)
        return {
            "version": MODEL_VERSION, "trained_at": _now_iso(),
            "feature_names": self.FEATURE_NAMES, "weights": best_weights,
            "validation_ic": best_ic, "blend": blend, "ridge_lambda": best_lambda,
            "training_samples": len(training_x), "validation_samples": len(validation_x),
            "universe_size": len(funds),
            "engine": "walk-forward ridge ensemble + risk expert",
        }

    def score(self, funds: list[dict], model: dict, profile: str) -> list[dict]:
        usable = []
        for fund in funds:
            result = self.features(fund["returns"])
            if not result:
                continue
            usable.append({**fund, "feature_vector": result[0], "stats": result[1]})
        if len(usable) < 10:
            return []
        columns = list(zip(*(item["feature_vector"] for item in usable)))
        scaled_columns = [_rank_scale(list(column)) for column in columns]
        for i, item in enumerate(usable):
            item["scaled"] = [scaled_columns[j][i] for j in range(len(self.FEATURE_NAMES))]

        learned_weights = model.get("weights") or [0.0] * len(self.FEATURE_NAMES)
        expert_weights = self.EXPERT_WEIGHTS[:]
        if profile == "稳健":
            expert_weights = [0.15, 0.30, 0.45, 0.85, 0.75, 0.90, 1.45, 1.10, 1.10, 0.55, 0.20, 0.85, 0.85, 0.50]
        elif profile == "进取":
            expert_weights = [0.65, 0.85, 1.05, 0.75, 0.45, 0.45, 0.50, 0.15, 0.35, 0.30, 0.65, 0.20, 0.30, 0.10]
        expert_scale = sum(abs(value) for value in expert_weights) or 1.0
        expert_weights = [value / expert_scale for value in expert_weights]
        blend = _clamp(_finite(model.get("blend"), 0.0), 0.0, 0.68)

        for item in usable:
            vector = item["scaled"]
            learned = sum(weight * value for weight, value in zip(learned_weights, vector))
            expert = sum(weight * value for weight, value in zip(expert_weights, vector))
            raw = blend * learned + (1.0 - blend) * expert
            coarse = _coarse_type(item["type"])
            if profile == "稳健":
                raw += {"债券": 0.16, "FOF": 0.06, "股票": -0.12, "QDII": -0.10}.get(coarse, 0.0)
            elif profile == "进取":
                raw += {"股票": 0.07, "指数": 0.04, "债券": -0.12}.get(coarse, 0.0)
            if re.search(r"C类?$", item["name"].strip(), re.I):
                raw -= 0.035
            if _theme(item["name"]) != "宽基/全市场":
                raw -= 0.025
            if item["stats"]["return_6m"] > 0.50 and item["stats"]["volatility"] > 0.25:
                raw -= 0.08
            item["raw_score"] = raw

        raw_scaled = _rank_scale([item["raw_score"] for item in usable])
        for item, percentile in zip(usable, raw_scaled):
            item["score"] = round(73.0 + 23.0 * percentile, 1)
            item["risk"] = self._risk_label(item)
            item["reason"] = self._reason(item)
        usable.sort(key=lambda item: item["raw_score"], reverse=True)
        return usable

    @staticmethod
    def _risk_label(item: dict) -> str:
        volatility = item["stats"]["volatility"]
        coarse = _coarse_type(item["type"])
        if coarse == "债券" and volatility < 0.07:
            return "中低"
        if volatility < 0.10:
            return "中"
        if volatility < 0.20:
            return "中高"
        return "高"

    @staticmethod
    def _reason(item: dict) -> str:
        stats = item["stats"]
        strengths = []
        if stats["sharpe"] >= 1.0:
            strengths.append("风险调整收益较强")
        if stats["max_drawdown"] > -0.16:
            strengths.append("长期回撤较低")
        if stats["positive_months"] >= 0.60:
            strengths.append("月度胜率较稳")
        if stats["return_3y_ann"] >= 0.10:
            strengths.append("三年复利靠前")
        if stats["current_drawdown"] < -0.16:
            strengths.append("当前仍在回撤")
        if stats["return_6m"] > 0.50:
            strengths.append("近期涨幅偏热")
        if not strengths:
            strengths.append("多周期综合均衡")
        return "；".join(strengths[:2])


class AnalysisEngine:
    def __init__(self):
        self.source = FundDataSource()
        self.store = LocalStore()
        self.ranker = AdaptiveRanker()
        self.funds: list[dict] = []
        self.lock = threading.RLock()

    def cache_age_hours(self) -> float:
        stamp = _parse_iso(self.store.cache.get("updated_at"))
        if stamp is None:
            return float("inf")
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        return max(0.0, (_dt.datetime.now().astimezone() - stamp).total_seconds() / 3600)

    def load_cached(self) -> bool:
        loaded = []
        for code, item in self.store.cache.get("funds", {}).items():
            returns = item.get("returns") or []
            dates = item.get("dates") or []
            if len(returns) < MIN_HISTORY_POINTS or len(returns) != len(dates):
                continue
            loaded.append({
                "code": code, "name": item.get("name") or code, "type": item.get("type") or "其他",
                "dates": dates, "returns": returns, "latest_nav": item.get("latest_nav"),
                "latest_date": item.get("latest_date") or (dates[-1] if dates else ""),
                "updated_at": item.get("updated_at"),
            })
        with self.lock:
            self.funds = loaded
        return len(loaded) >= 25

    @staticmethod
    def _history_fresh(item: dict) -> bool:
        stamp = _parse_iso(item.get("updated_at"))
        if stamp is None:
            return False
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        return (_dt.datetime.now().astimezone() - stamp).total_seconds() < 14 * 3600

    def rebuild(self, progress=lambda *_: None, force: bool = False) -> None:
        progress("连接公开基金数据源", 1)
        candidates = self.source.candidates(progress)
        existing = self.store.cache.get("funds", {})
        completed = 0
        total = len(candidates)
        results: list[dict] = []
        failures = []

        def load_one(candidate):
            cached = existing.get(candidate["code"])
            if cached and not force and self._history_fresh(cached) and len(cached.get("returns") or []) >= MIN_HISTORY_POINTS:
                history = {
                    "dates": cached["dates"], "returns": cached["returns"],
                    "latest_nav": cached.get("latest_nav"), "latest_date": cached.get("latest_date", ""),
                }
            else:
                history = self.source.history(candidate["code"])
            return {
                **candidate, **history, "updated_at": _now_iso(),
            }

        progress(f"并行分析 {total} 只基金的六年净值", 11)
        with concurrent.futures.ThreadPoolExecutor(max_workers=10, thread_name_prefix="fund-data") as executor:
            future_map = {executor.submit(load_one, candidate): candidate for candidate in candidates}
            for future in concurrent.futures.as_completed(future_map):
                candidate = future_map[future]
                completed += 1
                try:
                    item = future.result()
                    if len(item.get("returns") or []) >= MIN_HISTORY_POINTS:
                        results.append(item)
                except Exception as exc:
                    failures.append((candidate["code"], str(exc)))
                progress(
                    f"净值分析 {completed}/{total} · 有效 {len(results)}",
                    11 + 62 * completed / max(1, total),
                )
        if len(results) < 25:
            if self.load_cached():
                raise DataError("本次全市场更新失败，已保留上次本地结果")
            raise DataError(f"有效历史数据仅 {len(results)} 只，无法可靠训练")

        progress("滚动样本外训练本地 AI", 77)
        model = self.ranker.train(results)
        progress("生成多风险偏好排名", 91)
        with self.lock:
            self.funds = results
            self.store.model = model
            self.store.cache = {
                "version": CACHE_VERSION, "updated_at": _now_iso(),
                "failures": len(failures),
                "funds": {
                    item["code"]: {
                        "name": item["name"], "type": item["type"], "dates": item["dates"],
                        "returns": item["returns"], "latest_nav": item.get("latest_nav"),
                        "latest_date": item.get("latest_date"), "updated_at": item.get("updated_at"),
                    }
                    for item in results
                },
            }
            self.store.save_model(model)
            self.store.save_cache()
        progress("模型与缓存已保存到脚本目录", 100)

    def rankings(self, profile: str) -> list[dict]:
        with self.lock:
            scored = self.ranker.score(self.funds, self.store.model, profile)
        if not scored:
            return []
        chosen, rejected = [], []
        bases, type_counts, theme_counts = set(), {}, {}
        for item in scored:
            base = _base_name(item["name"])
            coarse = _coarse_type(item["type"])
            theme = _theme(item["name"])
            if base in bases or type_counts.get(coarse, 0) >= 4 or theme_counts.get(theme, 0) >= (4 if theme == "宽基/全市场" else 2):
                rejected.append(item)
                continue
            chosen.append(item)
            bases.add(base)
            type_counts[coarse] = type_counts.get(coarse, 0) + 1
            theme_counts[theme] = theme_counts.get(theme, 0) + 1
            if len(chosen) == 10:
                break
        if len(chosen) < 10:
            for item in rejected:
                base = _base_name(item["name"])
                if base in bases:
                    continue
                chosen.append(item)
                bases.add(base)
                if len(chosen) == 10:
                    break
        return chosen

    def refresh_latest(self, profile: str) -> list[dict]:
        current = self.rankings(profile)
        latest = self.source.latest([item["code"] for item in current])
        with self.lock:
            lookup = {item["code"]: item for item in self.funds}
            for code, row in latest.items():
                item = lookup.get(code)
                if not item:
                    continue
                if row["name"]:
                    item["name"] = row["name"]
                if math.isfinite(row["nav"]):
                    item["latest_nav"] = row["nav"]
                if row["nav_date"]:
                    item["latest_date"] = row["nav_date"]
                if math.isfinite(row["day_change"]):
                    item["day_change"] = row["day_change"]
            refreshed = self.rankings(profile)
            for item in refreshed:
                row = latest.get(item["code"])
                if row and math.isfinite(row["day_change"]):
                    item["day_change"] = row["day_change"]
        return refreshed


METHOD_TEXT = """这是什么

这是本地运行的公募基金量化筛选器。它给出的“模型分”是候选池内的相对排序，不是收益保证、买入指令或适当性结论。

数据与刷新

数据来自东方财富/天天基金公开页面和公开接口。程序只使用基金公司已披露的单位净值和日增长率；不读取支付宝账户，不要求密码，不进行交易，也不展示盘中估算净值。界面每 10 秒查询一次最新披露状态，但公募基金净值通常按交易日披露，所以数据日期可能不会每次变化。

AI 方法

首次运行建立最多约 180 只开放式公募基金候选池，下载约六年历史净值，并在本机做滚动样本外训练。特征包括 6/12/36 个月收益、年化波动、夏普、索提诺、卡玛、最大回撤、最差滚动年度、月度胜率、尾部损失、趋势质量、稳定性和当前回撤。学习模型与金融风险专家模型加权集成，随后限制同类型和同主题集中度。模型参数保存在 BestAlipayFunds_AI.json，缓存保存在 BestAlipayFunds_cache.json.gz；两者都与脚本同目录。

支付宝口径

支付宝/蚂蚁财富没有面向个人程序公开匿名、实时的完整在售清单接口。程序从公开可申购候选中筛选，并显示可在支付宝搜索的 6 位基金代码；实际是否在售、份额类别、限购、费率和风险等级必须在支付宝下单页再次核实。长期持有时 A/C 份额成本差异尤其需要核对。

如何使用

默认“均衡”并不代表适合所有人。稳健、均衡、进取只改变模型的风险权重，不能代替风险测评。关注净值日期、最大回撤与风险标签，分散配置，避免仅因短期排名追涨；购买前阅读基金合同、招募说明书和最新公告。历史表现不预示未来。
"""


class FundsApp:
    def __init__(self, root, tk, ttk, messagebox):
        self.root, self.tk, self.ttk, self.messagebox = root, tk, ttk, messagebox
        self.engine = AnalysisEngine()
        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.busy = False
        self.refreshing = False
        self.next_refresh = time.monotonic() + REFRESH_SECONDS
        self.current = []
        self.profile = tk.StringVar(value="均衡")
        self.status = tk.StringVar(value="正在启动本地 AI…")
        self.clock = tk.StringVar(value="下次刷新 10 秒")
        self.model_info = tk.StringVar(value="模型：等待训练")
        self.data_info = tk.StringVar(value="数据日期：—")
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(120, self._poll_events)
        self.root.after(1000, self._tick)
        self._start_initial()

    def _build_ui(self):
        self.root.title(f"{APP_NAME} {VERSION}")
        self.root.geometry("1420x760")
        self.root.minsize(1120, 640)
        self.root.configure(bg="#0b1220")
        try:
            self.root.iconname(APP_NAME)
        except Exception:
            pass
        style = self.ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except self.tk.TclError:
            pass
        font = ("Microsoft YaHei UI", 10)
        style.configure(".", font=font)
        style.configure("Root.TFrame", background="#0b1220")
        style.configure("Card.TFrame", background="#111c31")
        style.configure("Title.TLabel", background="#0b1220", foreground="#f8fafc", font=("Microsoft YaHei UI", 22, "bold"))
        style.configure("Sub.TLabel", background="#0b1220", foreground="#94a3b8", font=("Microsoft YaHei UI", 10))
        style.configure("Badge.TLabel", background="#18263f", foreground="#cbd5e1", padding=(10, 5))
        style.configure("Status.TLabel", background="#0b1220", foreground="#94a3b8")
        style.configure("Warn.TLabel", background="#0b1220", foreground="#fbbf24", font=("Microsoft YaHei UI", 9))
        style.configure("TButton", padding=(11, 7), background="#1d4ed8", foreground="#ffffff")
        style.map("TButton", background=[("active", "#2563eb"), ("disabled", "#334155")])
        style.configure("TCombobox", padding=5)
        style.configure("Treeview", background="#111c31", fieldbackground="#111c31", foreground="#e2e8f0", rowheight=36, borderwidth=0)
        style.configure("Treeview.Heading", background="#18263f", foreground="#cbd5e1", relief="flat", padding=(6, 8), font=("Microsoft YaHei UI", 9, "bold"))
        style.map("Treeview", background=[("selected", "#1d4ed8")], foreground=[("selected", "#ffffff")])
        style.configure("Horizontal.TProgressbar", background="#22c55e", troughcolor="#18263f")

        outer = self.ttk.Frame(self.root, style="Root.TFrame", padding=(24, 20, 24, 16))
        outer.pack(fill="both", expand=True)
        header = self.ttk.Frame(outer, style="Root.TFrame")
        header.pack(fill="x")
        titles = self.ttk.Frame(header, style="Root.TFrame")
        titles.pack(side="left", fill="x", expand=True)
        self.ttk.Label(titles, text="支付宝长期基金候选 · 本地 AI", style="Title.TLabel").pack(anchor="w")
        self.ttk.Label(
            titles,
            text="公开净值 · 滚动样本外训练 · 10 秒查询最新披露 · 支付宝下单页复核在售",
            style="Sub.TLabel",
        ).pack(anchor="w", pady=(5, 0))

        controls = self.ttk.Frame(header, style="Root.TFrame")
        controls.pack(side="right", anchor="e")
        self.ttk.Label(controls, text="风险偏好", style="Sub.TLabel").grid(row=0, column=0, padx=(0, 7))
        profile_box = self.ttk.Combobox(controls, textvariable=self.profile, values=("稳健", "均衡", "进取"), state="readonly", width=7)
        profile_box.grid(row=0, column=1, padx=(0, 8))
        profile_box.bind("<<ComboboxSelected>>", lambda _event: self._rerank())
        self.ttk.Button(controls, text="立即刷新", command=self._start_refresh).grid(row=0, column=2, padx=4)
        self.ttk.Button(controls, text="重建 AI", command=self._confirm_rebuild).grid(row=0, column=3, padx=4)
        self.ttk.Button(controls, text="复制代码", command=self._copy_selected).grid(row=0, column=4, padx=4)
        self.ttk.Button(controls, text="方法与风险", command=self._show_method).grid(row=0, column=5, padx=(4, 0))

        badges = self.ttk.Frame(outer, style="Root.TFrame")
        badges.pack(fill="x", pady=(18, 12))
        self.ttk.Label(badges, textvariable=self.data_info, style="Badge.TLabel").pack(side="left", padx=(0, 8))
        self.ttk.Label(badges, textvariable=self.model_info, style="Badge.TLabel").pack(side="left", padx=8)
        self.ttk.Label(badges, textvariable=self.clock, style="Badge.TLabel").pack(side="right")

        table_card = self.ttk.Frame(outer, style="Card.TFrame", padding=1)
        table_card.pack(fill="both", expand=True)
        columns = ("rank", "code", "name", "type", "score", "risk", "nav", "day", "ann", "dd", "sharpe", "reason", "date")
        self.tree = self.ttk.Treeview(table_card, columns=columns, show="headings", selectmode="browse")
        headings = {
            "rank": "#", "code": "基金代码", "name": "基金名称", "type": "类型", "score": "模型分",
            "risk": "风险", "nav": "最新净值", "day": "披露日涨跌", "ann": "近3年年化",
            "dd": "近3年最大回撤", "sharpe": "夏普", "reason": "入选理由", "date": "净值日期",
        }
        widths = {"rank": 42, "code": 76, "name": 190, "type": 92, "score": 68, "risk": 60, "nav": 80, "day": 86, "ann": 88, "dd": 105, "sharpe": 64, "reason": 210, "date": 92}
        for column in columns:
            self.tree.heading(column, text=headings[column])
            self.tree.column(column, width=widths[column], minwidth=widths[column], anchor="center" if column not in ("name", "reason") else "w", stretch=column in ("name", "reason"))
        scrollbar = self.ttk.Scrollbar(table_card, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.tree.tag_configure("positive", foreground="#fb7185")
        self.tree.tag_configure("negative", foreground="#4ade80")
        self.tree.tag_configure("neutral", foreground="#e2e8f0")
        self.tree.bind("<Double-1>", lambda _event: self._copy_selected())

        footer = self.ttk.Frame(outer, style="Root.TFrame")
        footer.pack(fill="x", pady=(12, 0))
        self.progress = self.ttk.Progressbar(footer, mode="determinate", maximum=100, value=0, length=230)
        self.progress.pack(side="left", padx=(0, 10))
        self.ttk.Label(footer, textvariable=self.status, style="Status.TLabel").pack(side="left", fill="x", expand=True)
        self.ttk.Label(
            outer,
            text="仅供研究：历史表现不预示未来；基金代码、份额、限购、费率和风险等级请在支付宝下单页再次核实。",
            style="Warn.TLabel",
        ).pack(fill="x", pady=(9, 0))

    def _start_initial(self):
        self.busy = True

        def worker():
            try:
                cached = self.engine.load_cached()
                if cached:
                    self.events.put(("results", self.engine.rankings(self.profile.get()), "已载入本地缓存"))
                if not cached or self.engine.cache_age_hours() >= 14:
                    self.engine.rebuild(lambda text, pct: self.events.put(("progress", text, pct)), force=False)
                    self.events.put(("results", self.engine.rankings(self.profile.get()), "全市场分析完成"))
                self.events.put(("done",))
            except Exception as exc:
                self.events.put(("error", str(exc)))
                self.events.put(("done",))

        threading.Thread(target=worker, name="initial-analysis", daemon=True).start()

    def _confirm_rebuild(self):
        if self.busy:
            self.status.set("当前任务尚未完成")
            return
        if not self.messagebox.askyesno("重建本地 AI", "将重新下载候选基金历史净值并训练，可能需要几十秒。继续吗？"):
            return
        self.busy = True
        self.progress["value"] = 0

        def worker():
            try:
                self.engine.rebuild(lambda text, pct: self.events.put(("progress", text, pct)), force=True)
                self.events.put(("results", self.engine.rankings(self.profile.get()), "AI 重建完成"))
            except Exception as exc:
                self.events.put(("error", str(exc)))
            finally:
                self.events.put(("done",))

        threading.Thread(target=worker, name="rebuild-analysis", daemon=True).start()

    def _start_refresh(self):
        if self.refreshing or not self.current:
            return
        self.refreshing = True
        self.status.set("查询最新披露净值…")

        def worker():
            try:
                results = self.engine.refresh_latest(self.profile.get())
                self.events.put(("results", results, "最新披露查询成功"))
            except Exception as exc:
                self.events.put(("refresh_error", str(exc)))
            finally:
                self.events.put(("refresh_done",))

        threading.Thread(target=worker, name="latest-refresh", daemon=True).start()

    def _rerank(self):
        results = self.engine.rankings(self.profile.get())
        if results:
            self._render(results)
            self.status.set(f"已切换为“{self.profile.get()}”权重")
            self.next_refresh = time.monotonic() + REFRESH_SECONDS

    def _render(self, results):
        self.current = results
        selected_code = None
        selected = self.tree.selection()
        if selected:
            values = self.tree.item(selected[0], "values")
            selected_code = values[1] if values else None
        for child in self.tree.get_children():
            self.tree.delete(child)
        latest_dates = []
        selected_id = None
        for rank, item in enumerate(results, 1):
            stats = item["stats"]
            day = item.get("day_change")
            day_text = "—" if day is None or not math.isfinite(_finite(day, float("nan"))) else f"{day:+.2f}%"
            tag = "positive" if _finite(day) > 0 else "negative" if _finite(day) < 0 else "neutral"
            nav = item.get("latest_nav")
            nav_text = "—" if nav is None or not math.isfinite(_finite(nav, float("nan"))) else f"{nav:.4f}"
            date = item.get("latest_date") or (item.get("dates") or [""])[-1]
            if date:
                latest_dates.append(date)
            row_id = self.tree.insert("", "end", values=(
                rank, item["code"], item["name"], item["type"], f"{item['score']:.1f}", item["risk"],
                nav_text, day_text, f"{stats['return_3y_ann']:+.1%}", f"{stats['max_drawdown']:.1%}",
                f"{stats['sharpe']:.2f}", item["reason"], date or "—",
            ), tags=(tag,))
            if item["code"] == selected_code:
                selected_id = row_id
        if selected_id:
            self.tree.selection_set(selected_id)
        self.data_info.set(f"数据日期：{max(latest_dates) if latest_dates else '—'}")
        model = self.engine.store.model
        ic = _finite(model.get("validation_ic"))
        trained = (model.get("trained_at") or "—")[:10]
        self.model_info.set(f"AI：{model.get('universe_size', 0)}只 · 样本外IC {ic:+.2f} · {trained}")

    def _copy_selected(self):
        selected = self.tree.selection()
        if not selected:
            self.status.set("请先选择一只基金")
            return
        values = self.tree.item(selected[0], "values")
        if not values:
            return
        code = str(values[1])
        self.root.clipboard_clear()
        self.root.clipboard_append(code)
        self.root.update_idletasks()
        self.status.set(f"已复制 {code}；请在支付宝搜索并核实在售状态")

    def _show_method(self):
        window = self.tk.Toplevel(self.root)
        window.title("方法、数据与风险说明")
        window.geometry("780x620")
        window.configure(bg="#0b1220")
        text = self.tk.Text(
            window, wrap="word", bg="#111c31", fg="#e2e8f0", insertbackground="#ffffff",
            relief="flat", padx=22, pady=18, font=("Microsoft YaHei UI", 10), spacing2=4, spacing3=8,
        )
        text.insert("1.0", METHOD_TEXT)
        text.configure(state="disabled")
        text.pack(fill="both", expand=True, padx=16, pady=16)

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "progress":
                    self.status.set(event[1])
                    self.progress["value"] = event[2]
                elif kind == "results":
                    self._render(event[1])
                    self.status.set(event[2])
                    self.progress["value"] = 100
                    self.next_refresh = time.monotonic() + REFRESH_SECONDS
                elif kind == "error":
                    self.status.set(f"更新失败：{event[1]}")
                    if not self.current:
                        self.messagebox.showerror("无法完成基金分析", event[1] + "\n\n请确认网络可访问公开基金数据源后重试。")
                elif kind == "refresh_error":
                    self.status.set(f"本轮刷新失败，保留上次数据：{event[1]}")
                elif kind == "done":
                    self.busy = False
                elif kind == "refresh_done":
                    self.refreshing = False
                    self.next_refresh = time.monotonic() + REFRESH_SECONDS
        except queue.Empty:
            pass
        if not self.stop_event.is_set():
            self.root.after(150, self._poll_events)

    def _tick(self):
        remaining = max(0, int(math.ceil(self.next_refresh - time.monotonic())))
        self.clock.set(f"下次刷新 {remaining} 秒")
        if remaining <= 0:
            self._start_refresh()
            self.next_refresh = time.monotonic() + REFRESH_SECONDS
        if not self.stop_event.is_set():
            self.root.after(1000, self._tick)

    def close(self):
        self.stop_event.set()
        self.root.destroy()


def _run_console():
    engine = AnalysisEngine()
    if not engine.load_cached() or engine.cache_age_hours() >= 14:
        engine.rebuild(lambda text, pct: print(f"[{pct:5.1f}%] {text}"), force=False)
    profile = "均衡"
    while True:
        try:
            results = engine.refresh_latest(profile)
        except DataError:
            results = engine.rankings(profile)
        os.system("cls" if os.name == "nt" else "clear")
        print(f"{APP_NAME} {VERSION} · 均衡 · {time.strftime('%Y-%m-%d %H:%M:%S')}")
        print("模型候选，仅供研究；请在支付宝按代码复核在售、份额、费率与风险。\n")
        for rank, item in enumerate(results, 1):
            stats = item["stats"]
            print(
                f"{rank:2d}. {item['code']}  {item['name'][:22]:22s}  "
                f"分数 {item['score']:4.1f}  三年年化 {stats['return_3y_ann']:+6.1%}  "
                f"最大回撤 {stats['max_drawdown']:6.1%}  {item['reason']}"
            )
        print("\n按 Ctrl+C 退出；10 秒后查询最新披露。")
        time.sleep(REFRESH_SECONDS)


def _self_test():
    rng = random.Random(20260815)
    funds = []
    types = ("混合型-偏股", "股票型", "债券型", "指数型")
    for index in range(72):
        quality = (index - 36) / 800000.0
        returns = [0.0]
        for _ in range(1450):
            daily = 0.00020 + quality + rng.gauss(0, 0.007 + (index % 4) * 0.0015)
            returns.append(_clamp(daily, -0.15, 0.15))
        funds.append({
            "code": f"{index:06d}", "name": f"测试基金{index}A", "type": types[index % 4],
            "dates": [f"D{i}" for i in range(len(returns))], "returns": returns,
            "latest_nav": 1.0, "latest_date": "2026-08-14",
        })
    ranker = AdaptiveRanker()
    model = ranker.train(funds)
    scored = ranker.score(funds, model, "均衡")
    assert len(model["weights"]) == len(AdaptiveRanker.FEATURE_NAMES)
    assert len(scored) == len(funds)
    assert scored[0]["score"] >= scored[-1]["score"]
    json.dumps(model, ensure_ascii=False)
    print(f"SELF-TEST OK · {len(funds)} funds · {model['training_samples']} samples · IC {model['validation_ic']:+.3f}")


def _set_windows_dpi():
    if os.name != "nt":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def main():
    if sys.version_info < MIN_PYTHON:
        message = f"需要 Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} 或更高版本（64 位）。"
        if os.name == "nt":
            try:
                ctypes.windll.user32.MessageBoxW(0, message, APP_NAME, 0x10)
            except Exception:
                print(message)
        else:
            print(message)
        raise SystemExit(2)
    if "--version" in sys.argv:
        print(VERSION)
        return
    if "--self-test" in sys.argv:
        _self_test()
        return
    if "--console" in sys.argv:
        _run_console()
        return
    _set_windows_dpi()
    try:
        import tkinter as tk
        from tkinter import messagebox, ttk

        root = tk.Tk()
        FundsApp(root, tk, ttk, messagebox)
        root.mainloop()
    except ImportError:
        _run_console()
    except Exception as exc:
        try:
            import tkinter.messagebox as messagebox
            messagebox.showerror(APP_NAME, f"启动失败：{exc}")
        except Exception:
            print(f"启动失败：{exc}", file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
