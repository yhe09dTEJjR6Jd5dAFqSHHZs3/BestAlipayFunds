# -*- coding: utf-8 -*-
from __future__ import annotations

import concurrent.futures
import ctypes
import datetime as _dt
import base64
import bisect
import calendar
import gzip
import hashlib
import hmac
import html
import io
import json
import math
import platform
import struct
import os
import queue
import random
import re
import statistics
import sys
import threading
import time
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


APP_NAME = "Best Alipay Funds"
VERSION = "7.0.0"
LATEST_TIMEOUT = 4.0
LATEST_ATTEMPTS = 2
LATEST_BATCH_SIZE = 50
MIN_HISTORY_POINTS = 757
MIN_PYTHON = (3, 10)
BASE_DIR = Path(__file__).resolve().parent
CACHE_PATH = BASE_DIR / "BestAlipayFunds_cache.json.gz"
MODEL_PATH = BASE_DIR / "BestAlipayFunds_AI.json"
ALIPAY_FILE_PATH = BASE_DIR / "BestAlipayFunds_AlipayAvailability.json"
ALIPAY_MAX_AGE_SECONDS = 30 * 60
DEFAULT_RISK_FREE_RATE = 0.015
OOS_DEPLOYMENT_WINDOWS = 2
OOS_UNTOUCHED_TEST_WINDOWS = 2
MIN_OOS_GATE_WINDOWS = 2
REFRESH_MIN_COVERAGE = 0.97
LATEST_PRIORITY_COUNT = 20
HISTORY_YEARS = 12
CACHE_VERSION = 12
MODEL_VERSION = 11
AVAILABILITY_SCHEMA_VERSION = 5
MIN_AVAILABILITY_FUNDS = 25
MAX_AVAILABILITY_FUTURE_SKEW_SECONDS = 5 * 60
MODEL_RETRAIN_DAYS = 7
MAX_HTTP_RESPONSE_BYTES = 16 * 1024 * 1024
MAX_HTTP_DECOMPRESSED_BYTES = 64 * 1024 * 1024
TARGET_HALF_YEAR_DAYS = 183
TARGET_ONE_YEAR_DAYS = 365
MIN_HALF_YEAR_OBSERVATIONS = 100
MIN_ONE_YEAR_OBSERVATIONS = 200
METADATA_ENRICH_PER_PROFILE = 36
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
)

CHINA_TZ = _dt.timezone(_dt.timedelta(hours=8))


def _availability_max_age_seconds(now: _dt.datetime | None = None) -> int:
    """Freshness window for signed Alipay declarations; expires_at remains the hard deadline."""
    now_cn = (now or _dt.datetime.now(tz=CHINA_TZ)).astimezone(CHINA_TZ)
    minute = now_cn.hour * 60 + now_cn.minute
    if now_cn.weekday() >= 5:
        return 6 * 60 * 60
    if 9 * 60 <= minute < 23 * 60:
        return ALIPAY_MAX_AGE_SECONDS
    return 4 * 60 * 60


def _human_seconds(seconds: float) -> str:
    seconds = max(0, int(math.ceil(seconds)))
    if seconds < 60:
        return f"{seconds}秒"
    minutes, seconds = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes}分{seconds:02d}秒" if seconds else f"{minutes}分钟"
    hours, minutes = divmod(minutes, 60)
    return f"{hours}小时{minutes:02d}分"


class SmartRefreshPolicy:
    """Adaptive polling for China-market fund NAV/availability data."""

    def __init__(self, rng=None):
        self.rng = rng or random.Random()
        self.error_streak = 0
        self.low_coverage_streak = 0
        self.stable_streak = 0
        self.last_delay = 0.0
        self.last_reason = "等待首次分析"

    @staticmethod
    def _latest_date(results: list[dict] | None) -> str:
        dates = [str(item.get("latest_date") or "")[:10] for item in (results or [])]
        dates = [value for value in dates if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value)]
        return max(dates, default="")

    @staticmethod
    def _phase(now: _dt.datetime) -> tuple[str, float, float]:
        now = now.astimezone(CHINA_TZ)
        minute = now.hour * 60 + now.minute
        if now.weekday() >= 5:
            return "周末低活跃", 900.0, 1200.0
        if 15 * 60 <= minute < 23 * 60:
            return "收盘净值披露", 75.0, 600.0
        if 9 * 60 <= minute < 15 * 60:
            return "交易时段", 240.0, 720.0
        if 7 * 60 + 30 <= minute < 9 * 60:
            return "开盘前", 360.0, 900.0
        return "低活跃时段", 720.0, 1200.0

    @classmethod
    def _nav_pending(cls, results: list[dict] | None, now: _dt.datetime) -> bool:
        now_cn = now.astimezone(CHINA_TZ)
        if now_cn.weekday() >= 5 or now_cn.hour < 15:
            return False
        latest = cls._latest_date(results)
        return bool(latest and latest < now_cn.date().isoformat())

    def _jitter(self, seconds: float, spread: float = 0.08) -> float:
        return max(20.0, seconds * self.rng.uniform(1.0 - spread, 1.0 + spread))

    def _finish(self, seconds: float, reason: str, elapsed: float = 0.0) -> float:
        if elapsed > 0:
            seconds = max(seconds, min(900.0, elapsed * 6.0))
        self.last_delay = self._jitter(_clamp(seconds, 20.0, 1200.0))
        self.last_reason = reason
        return self.last_delay

    def initial_delay(self, results: list[dict] | None, now: _dt.datetime | None = None) -> float:
        now = now or _dt.datetime.now(tz=CHINA_TZ)
        phase, base, cap = self._phase(now)
        if self._nav_pending(results, now):
            base = min(base, 60.0)
            reason = f"{phase}·等待今日净值"
        else:
            reason = phase
        return self._finish(min(base, cap), reason)

    def on_success(self, outcome: dict, now: _dt.datetime | None = None) -> float:
        now = now or _dt.datetime.now(tz=CHINA_TZ)
        self.error_streak = 0
        coverage = _finite(outcome.get("coverage"), 0.0)
        elapsed = _finite(outcome.get("elapsed_seconds"), 0.0)
        results = outcome.get("results") or []
        changed = int(outcome.get("updated_series") or 0)
        pool_changes = len(outcome.get("new_codes") or []) + len(outcome.get("removed_codes") or [])

        if coverage < REFRESH_MIN_COVERAGE or outcome.get("ranking_updated") is False:
            self.low_coverage_streak += 1
            self.stable_streak = 0
            delay = min(600.0, 45.0 * (2 ** min(self.low_coverage_streak - 1, 4)))
            detail = "Top候选不完整" if outcome.get("priority_complete") is False else f"覆盖率{coverage:.1%}"
            return self._finish(delay, f"{detail}·自适应退避重试", elapsed)

        self.low_coverage_streak = 0
        if pool_changes:
            self.stable_streak = 0
            return self._finish(35.0, f"可购池变化{pool_changes}项·快速复核", elapsed)
        if changed:
            self.stable_streak = 0
            delay = 45.0 if self._nav_pending(results, now) else 90.0
            return self._finish(delay, f"发现{changed}个新净值·快速复核", elapsed)

        self.stable_streak += 1
        phase, base, cap = self._phase(now)
        pending = self._nav_pending(results, now)
        if pending:
            base, cap = min(base, 75.0), min(cap, 360.0)
            reason = f"{phase}·今日净值待披露"
        else:
            if phase == "收盘净值披露":
                base = max(base, 300.0)
            reason = f"{phase}·数据稳定"
        multiplier = min(2.6, 1.0 + 0.28 * max(0, self.stable_streak - 1))
        return self._finish(min(cap, base * multiplier), reason, elapsed)

    def on_error(self, elapsed: float = 0.0) -> float:
        self.error_streak += 1
        self.low_coverage_streak = 0
        self.stable_streak = 0
        delay = min(900.0, 60.0 * (2 ** min(self.error_streak - 1, 4)))
        return self._finish(delay, f"网络/数据失败×{self.error_streak}·指数退避", elapsed)



class DataError(RuntimeError):
    pass


def _now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def _parse_iso(value: str | None) -> _dt.datetime | None:
    if not value:
        return None
    try:
        text = str(value).strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        return _dt.datetime.fromisoformat(text)
    except (TypeError, ValueError):
        return None


def _finite(value, default=0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _compound(values) -> float:
    total = 1.0
    for value in values:
        total *= max(0.01, 1.0 + _clamp(_finite(value), -0.95, 3.0))
    return total - 1.0


def _max_drawdown(values) -> float:
    wealth = 1.0
    peak = 1.0
    worst = 0.0
    for value in values:
        wealth *= max(0.01, 1.0 + _clamp(_finite(value), -0.95, 3.0))
        peak = max(peak, wealth)
        worst = min(worst, wealth / peak - 1.0)
    return worst


def _pearson(xs, ys) -> float:
    if len(xs) != len(ys) or len(xs) < 3:
        return 0.0
    mx = sum(xs) / len(xs)
    my = sum(ys) / len(ys)
    numerator = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = sum((x - mx) ** 2 for x in xs)
    dy = sum((y - my) ** 2 for y in ys)
    if dx <= 1e-15 or dy <= 1e-15:
        return 0.0
    return numerator / math.sqrt(dx * dy)


def _spearman(xs, ys) -> float:
    if len(xs) != len(ys) or len(xs) < 3:
        return 0.0
    return _pearson(_rank_scale(xs), _rank_scale(ys))


def _median(values, default=0.0) -> float:
    clean = [_finite(v, float("nan")) for v in values]
    clean = [v for v in clean if math.isfinite(v)]
    return statistics.median(clean) if clean else default


def _chunks(values, size):
    for start in range(0, len(values), size):
        yield values[start:start + size]


def _rate(value, default=0.0) -> float:
    return _clamp(_finite(value, default), 0.0, 0.25)


def _risk_free_rate() -> float:
    """Annual risk-free assumption used by risk-adjusted statistics; user-overridable."""
    return _clamp(_finite(os.environ.get("BEST_ALIPAY_RISK_FREE_RATE"), DEFAULT_RISK_FREE_RATE), -0.02, 0.08)


def _asset_bucket(name: str, fund_type: str) -> str:
    wrapper = _wrapper_type(fund_type)
    if wrapper == "QDII":
        return "QDII"
    if wrapper == "FOF":
        return "FOF"
    coarse = _coarse_type(fund_type)
    if coarse == "债券":
        return "债券"
    if coarse == "指数":
        return "指数"
    if coarse in ("股票", "混合"):
        return "主动权益"
    return "其他"


def _holding_costs(fees: dict | None) -> dict:
    """Return investor-paid transaction costs separately from NAV-embedded expenses.

    Management/custody/sales-service fees are normally already reflected in published NAV,
    so they are reported for transparency but are not subtracted a second time by the model.
    """
    fees = fees or {}
    purchase = _rate(fees.get("purchase_fee"))
    embedded_annual = sum(_rate(fees.get(key)) for key in (
        "management_fee_annual", "custody_fee_annual", "sales_service_fee_annual",
    ))
    costs = {}
    for years in (3, 5, 10):
        redemption = _rate(fees.get(f"redemption_fee_{years}y", fees.get("redemption_fee", 0.0)))
        costs[f"holding_cost_{years}y"] = purchase + redemption
    costs["annual_cost"] = embedded_annual
    costs["embedded_annual_cost"] = embedded_annual
    costs["purchase_cost"] = purchase
    return costs


def _expected_holding_years(value=None) -> int:
    try:
        years = int(value if value is not None else os.environ.get("BEST_ALIPAY_HOLDING_YEARS", "5"))
    except (TypeError, ValueError):
        years = 5
    return years if years in (3, 5, 10) else 5


def _share_class_cost(fund: dict, years: int) -> float:
    """Comparable share-class cost for the requested holding period.

    Published NAV already includes annual expenses, so they are never subtracted from historical
    returns.  They do matter when choosing between otherwise equivalent A/C/I share classes today.
    """
    years = _expected_holding_years(years)
    fees = fund.get("fees") if isinstance(fund.get("fees"), dict) else {}
    transaction = _finite(fund.get(f"holding_cost_{years}y"), float("nan"))
    if not math.isfinite(transaction):
        transaction = _holding_costs(fees).get(f"holding_cost_{years}y", 0.0)
    embedded = sum(_rate(fees.get(key)) for key in (
        "management_fee_annual", "custody_fee_annual", "sales_service_fee_annual",
    ))
    return _clamp(transaction + years * embedded, 0.0, 3.0)


def _underlying_key(fund: dict) -> str:
    explicit = str(
        fund.get("underlying_fund_id") or fund.get("master_code")
        or fund.get("primary_code") or ""
    ).strip().casefold()
    if explicit:
        return explicit if explicit.startswith(("id:", "name:", "code:")) else "id:" + explicit
    base = _base_name(str(fund.get("name") or ""))
    wrapper = _wrapper_type(str(fund.get("type") or ""))
    return f"name:{base.casefold()}|{wrapper}" if base else "code:" + str(fund.get("code") or "")


def _add_years(day: _dt.date, years: int) -> _dt.date:
    try:
        return day.replace(year=day.year + years)
    except ValueError:
        return day.replace(year=day.year + years, day=28)


def _years_before(day: _dt.date, years: int) -> _dt.date:
    return _add_years(day, -years)


_LUNAR_NEW_YEAR = {
    2024: _dt.date(2024, 2, 10), 2025: _dt.date(2025, 1, 29),
    2026: _dt.date(2026, 2, 17), 2027: _dt.date(2027, 2, 6),
    2028: _dt.date(2028, 1, 26), 2029: _dt.date(2029, 2, 13),
    2030: _dt.date(2030, 2, 3),
}


def _probable_china_market_holiday(day: _dt.date) -> bool:
    if day.weekday() >= 5:
        return True
    if (day.month, day.day) in {(1, 1)} or (day.month == 4 and 4 <= day.day <= 6):
        return True
    if day.month == 5 and day.day <= 5:
        return True
    if day.month == 10 and day.day <= 7:
        return True
    lunar_new_year = _LUNAR_NEW_YEAR.get(day.year)
    if lunar_new_year and lunar_new_year - _dt.timedelta(days=2) <= day <= lunar_new_year + _dt.timedelta(days=7):
        return True
    return False


def _expected_market_sessions(start_exclusive: _dt.date, finish_inclusive: _dt.date) -> int:
    if finish_inclusive <= start_exclusive:
        return 0
    count = 0
    day = start_exclusive + _dt.timedelta(days=1)
    while day <= finish_inclusive:
        count += int(not _probable_china_market_holiday(day))
        day += _dt.timedelta(days=1)
    return count


def _age_seconds(iso_value: str | None) -> float:
    stamp = _parse_iso(iso_value)
    if stamp is None or stamp.tzinfo is None:
        return float("inf")
    return max(0.0, (_dt.datetime.now().astimezone() - stamp.astimezone()).total_seconds())


def _rank_scale(values) -> list[float]:
    count = len(values)
    if count <= 1:
        return [0.0] * count
    order = sorted(range(count), key=lambda i: (_finite(values[i]), i))
    result = [0.0] * count
    start = 0
    while start < count:
        end = start + 1
        current = _finite(values[order[start]])
        while end < count and abs(_finite(values[order[end]]) - current) < 1e-12:
            end += 1
        average_rank = (start + end - 1) / 2.0
        scaled = 2.0 * average_rank / (count - 1) - 1.0
        for position in range(start, end):
            result[order[position]] = scaled
        start = end
    return result


def _atomic_bytes(path: Path, data: bytes) -> None:
    path = Path(path)
    descriptor, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    temp = Path(temp_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass


def _write_json(path: Path, payload) -> None:
    raw = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
    _atomic_bytes(path, raw)


def _read_json(path: Path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError, TypeError):
        return default


def _decode_response(raw: bytes, charset: str | None) -> str:
    candidates = [charset, "utf-8-sig", "utf-8", "gb18030"]
    for candidate in candidates:
        if not candidate:
            continue
        try:
            return raw.decode(candidate)
        except (LookupError, UnicodeDecodeError):
            pass
    return raw.decode("utf-8", errors="replace")


def _read_response_limited(response, limit: int = MAX_HTTP_RESPONSE_BYTES) -> bytes:
    try:
        content_length = int(response.headers.get("Content-Length") or 0)
    except (TypeError, ValueError):
        content_length = 0
    if content_length > limit:
        raise DataError(f"网络响应声明大小 {content_length} 字节，超过安全上限 {limit} 字节")
    raw = response.read(limit + 1)
    if len(raw) > limit:
        raise DataError(f"网络响应超过安全上限 {limit} 字节")
    return raw


def _safe_gzip_decompress(raw: bytes, limit: int = MAX_HTTP_DECOMPRESSED_BYTES) -> bytes:
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(raw), mode="rb") as handle:
            decoded = handle.read(limit + 1)
    except (OSError, EOFError) as exc:
        raise DataError(f"gzip 响应损坏：{exc}") from exc
    if len(decoded) > limit:
        raise DataError(f"gzip 解压结果超过安全上限 {limit} 字节")
    return decoded


class _PinnedRedirectHandler(urllib.request.HTTPRedirectHandler):
    def __init__(self, allowed_hosts: set[str] | frozenset[str]):
        super().__init__()
        self.allowed_hosts = {str(host).strip().lower() for host in allowed_hosts if str(host).strip()}

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        host = (parsed.hostname or "").lower()
        if parsed.scheme.lower() != "https" or host not in self.allowed_hosts:
            raise urllib.error.HTTPError(
                req.full_url, code,
                f"已阻止携带受信请求头跳转到白名单外地址：{newurl}", headers, fp,
            )
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _http_text(
    url: str,
    *,
    data: dict | None = None,
    referer: str = "https://fund.eastmoney.com/",
    timeout: float = 9.0,
    attempts: int = 2,
    headers_extra: dict | None = None,
    allowed_redirect_hosts: set[str] | frozenset[str] | None = None,
    max_response_bytes: int = MAX_HTTP_RESPONSE_BYTES,
) -> str:
    encoded = None
    if data is not None:
        encoded = urllib.parse.urlencode(data).encode("utf-8")
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/json,text/javascript,*/*;q=0.8",
        "Accept-Encoding": "gzip",
        "Referer": referer,
        "Cache-Control": "no-cache",
        "X-Requested-With": "XMLHttpRequest",
    }
    if encoded is not None:
        headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
    if headers_extra:
        headers.update({str(k): str(v) for k, v in headers_extra.items() if v is not None})
    last_error = None
    for attempt in range(attempts):
        try:
            request = urllib.request.Request(url, data=encoded, headers=headers)
            opener = (
                urllib.request.build_opener(_PinnedRedirectHandler(allowed_redirect_hosts))
                if allowed_redirect_hosts is not None else urllib.request.build_opener()
            )
            with opener.open(request, timeout=timeout) as response:
                raw = _read_response_limited(response, max_response_bytes)
                if response.headers.get("Content-Encoding", "").lower() == "gzip":
                    raw = _safe_gzip_decompress(raw)
                return _decode_response(raw, response.headers.get_content_charset())
        except (OSError, urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as exc:
            last_error = exc
            if attempt + 1 < attempts:
                time.sleep(0.35 * (attempt + 1) + random.random() * 0.2)
    raise DataError(f"网络请求失败：{last_error}")


def _http_json(url: str, **kwargs):
    text = _http_text(url, **kwargs)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        match = re.search(r"\{[\s\S]*\}", text)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                pass
        raise DataError(f"数据格式无法识别：{exc}") from exc


def _wrapper_type(value: str) -> str:
    text = (value or "").upper()
    if "QDII" in text or "海外" in text:
        return "QDII"
    if "FOF" in text or "基金中基金" in text:
        return "FOF"
    return "普通"


def _coarse_type(value: str) -> str:
    """Underlying asset bucket; QDII/FOF are represented separately by _wrapper_type()."""
    text = value or "其他"
    if "债" in text:
        return "债券"
    if "指数" in text or "ETF" in text.upper():
        return "指数"
    if "股票" in text:
        return "股票"
    if "混合" in text:
        return "混合"
    if _wrapper_type(text) == "FOF":
        return "混合"
    if _wrapper_type(text) == "QDII":
        return "指数" if "指数" in text else "股票"
    return "其他"


def _base_name(name: str) -> str:
    value = re.sub(r"[（(](人民币|前端|后端|场外)[）)]", "", name or "")
    value = re.sub(r"(?:ETF)?联接基金?([AC])?$", "联接", value, flags=re.I)
    value = re.sub(r"(?:人民币)?[A-EH-IY]类?$", "", value, flags=re.I)
    value = re.sub(r"[\s·\-_（）()]", "", value)
    return value


def _share_preference(name: str) -> int:
    """Informational share-class hint only; purchasable classes are never hard-excluded."""
    compact = (name or "").strip().upper()
    if re.search(r"A类?$", compact):
        return 4
    if re.search(r"C类?$", compact):
        return 3
    if re.search(r"[BDEHIY]类?$", compact):
        return 2
    return 3


def _theme(name: str) -> str:
    groups = {
        "医药医疗": ("医药", "医疗", "生物", "创新药"),
        "科技半导体": ("科技", "半导体", "芯片", "软件", "计算机", "人工智能", "机器人"),
        "新能源": ("新能源", "光伏", "电池", "汽车"),
        "消费": ("消费", "白酒", "食品", "家电"),
        "周期资源": ("煤炭", "有色", "钢铁", "资源", "化工", "黄金"),
        "军工": ("军工", "国防", "航天"),
        "金融地产": ("金融", "银行", "证券", "地产"),
        "海外": ("全球", "海外", "美国", "纳斯达克", "标普", "港股", "恒生"),
    }
    for label, words in groups.items():
        if any(word in (name or "") for word in words):
            return label
    return "宽基/全市场"


def _candidate_allowed(name: str, fund_type: str) -> bool:
    text = f"{name} {fund_type}".upper()
    blocked = (
        "货币", "理财", "同业存单", "REIT", "封闭", "定期开放", "定开",
        "后端", "分级", "杠杆", "商品", "原油", "白银",
    )
    if any(word.upper() in text for word in blocked):
        return False
    if not re.fullmatch(r"[\s\S]{2,80}", name or ""):
        return False
    return _coarse_type(fund_type) != "其他"


class AlipayAvailabilitySource:
    """Fail-closed Alipay availability adapter with signed-manifest rollback protection.

    Public releases accept only a built-in HTTPS endpoint + built-in RSA public key.  A private
    deployment may explicitly set BEST_ALIPAY_AVAILABILITY_URL and use HMAC-SHA256, but unsigned
    JSON is never accepted.  A stale, previously verified manifest is retained only as historical
    evidence and is never presented as "current Alipay purchasable".
    """

    SCHEMA = "best-alipay-funds-availability-v5"

    # A distributor can make the one-file release genuinely zero-configuration only by publishing
    # a maintained signed manifest and embedding its URL + public key here.  We intentionally do
    # not invent such an endpoint or key: doing so would turn an unverifiable market catalogue into
    # a false claim of current Alipay availability.
    DEFAULT_URL = ""
    PUBLIC_RSA_KEYS: dict[str, tuple[int, int]] = {}
    DEFAULT_PUBLIC_HOSTS: frozenset[str] = frozenset()

    def __init__(self):
        self.last_snapshot_state: dict = {}

    @staticmethod
    def _payload_time(payload: dict) -> str:
        return str(payload.get("generated_at") or payload.get("declared_at") or payload.get("verified_at") or "")

    @staticmethod
    def _canonical_signature_bytes(payload: dict) -> bytes:
        unsigned = dict(payload)
        unsigned.pop("signature", None)
        return json.dumps(unsigned, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")

    @staticmethod
    def _verify_rsa_sha256(signature_b64: str, message: bytes, n: int, e: int = 65537) -> bool:
        """Minimal PKCS#1 v1.5 SHA-256 verification using only the Python standard library."""
        try:
            signature = base64.b64decode(signature_b64, validate=True)
            size = (int(n).bit_length() + 7) // 8
            if size < 128 or len(signature) != size:
                return False
            em = pow(int.from_bytes(signature, "big"), int(e), int(n)).to_bytes(size, "big")
            digest_info = bytes.fromhex("3031300d060960864801650304020105000420") + hashlib.sha256(message).digest()
            padding_len = size - len(digest_info) - 3
            expected = b"\x00\x01" + b"\xff" * padding_len + b"\x00" + digest_info
            return padding_len >= 8 and hmac.compare_digest(em, expected)
        except (ValueError, TypeError, OverflowError):
            return False

    @classmethod
    def _trusted_url(cls) -> tuple[str, bool, frozenset[str]]:
        custom = os.environ.get("BEST_ALIPAY_AVAILABILITY_URL", "").strip()
        url = custom or cls.DEFAULT_URL
        if not url:
            return "", False, frozenset()
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme.lower() != "https" or not parsed.hostname:
            raise DataError("可信支付宝可购状态源必须是有效 HTTPS 地址")
        host = parsed.hostname.lower()
        is_public = not bool(custom)
        if is_public:
            allowed = set(cls.DEFAULT_PUBLIC_HOSTS)
            default_host = urllib.parse.urlsplit(cls.DEFAULT_URL).hostname if cls.DEFAULT_URL else None
            if default_host:
                allowed.add(default_host.lower())
            if not allowed or host not in allowed:
                raise DataError(f"内置公共可购源域名 {host} 不在发行版固定白名单")
        else:
            configured = {
                h.strip().lower() for h in os.environ.get("BEST_ALIPAY_AVAILABILITY_HOSTS", "").split(",") if h.strip()
            }
            # Private deployments are still pinned to exactly one host by default; HOSTS can make
            # an explicit multi-host allowlist without weakening the public-release policy.
            allowed = configured or {host}
            if host not in allowed:
                raise DataError(f"私有可购状态源域名 {host} 不在固定白名单中")
        return url, is_public, frozenset(allowed)

    def _write_snapshot(self, payload: dict) -> None:
        try:
            _write_json(ALIPAY_FILE_PATH, payload)
        except OSError as exc:
            raise DataError(f"无法在脚本同目录写入可购状态快照：{exc}") from exc

    @staticmethod
    def _dt_aware(value: str, field: str) -> _dt.datetime:
        stamp = _parse_iso(value)
        if stamp is None:
            raise DataError(f"可购状态源缺少合法 {field}")
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=_dt.timezone.utc)
        return stamp

    def _verify_signature(self, payload: dict, *, public_source: bool) -> None:
        source_id = str(payload.get("source_id") or "").strip()
        alg = str(payload.get("signature_alg") or "").strip().lower()
        signature = str(payload.get("signature") or "").strip()
        message = self._canonical_signature_bytes(payload)
        if not signature:
            raise DataError("可购状态缺少数字签名，已拒绝")
        if alg == "rsa-sha256":
            key_tuple = self.PUBLIC_RSA_KEYS.get(source_id)
            if key_tuple is None and not public_source:
                n_text = os.environ.get("BEST_ALIPAY_AVAILABILITY_RSA_N", "").strip()
                e_text = os.environ.get("BEST_ALIPAY_AVAILABILITY_RSA_E", "65537").strip()
                if n_text:
                    try:
                        key_tuple = (int(n_text, 0), int(e_text, 0))
                    except ValueError as exc:
                        raise DataError("私有可购状态 RSA 公钥参数无效") from exc
            if key_tuple is None:
                scope = "发行版内置" if public_source else "受信"
                raise DataError(f"可购状态源 {source_id} 没有{scope} RSA 公钥")
            if not self._verify_rsa_sha256(signature, message, *key_tuple):
                raise DataError("可购状态 RSA-SHA256 签名校验失败")
            return
        if alg == "hmac-sha256" and not public_source:
            key = os.environ.get("BEST_ALIPAY_AVAILABILITY_HMAC_KEY", "")
            if not key:
                raise DataError("私有 HMAC 可购源缺少 BEST_ALIPAY_AVAILABILITY_HMAC_KEY")
            expected = hmac.new(key.encode("utf-8"), message, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(signature.lower(), expected):
                raise DataError("可购状态 HMAC-SHA256 签名校验失败")
            return
        if public_source:
            raise DataError("发行版公共可购源必须使用 RSA-SHA256 非对称签名")
        raise DataError(f"不支持或不允许的可购状态签名算法：{alg or 'missing'}")

    def _validate_payload(self, payload: dict, *, require_fresh: bool = True, public_source: bool = False) -> dict:
        if not isinstance(payload, dict):
            raise DataError("可购状态数据必须是 JSON object")
        if payload.get("schema") != self.SCHEMA or int(_finite(payload.get("schema_version"), -1)) != AVAILABILITY_SCHEMA_VERSION:
            raise DataError(f"可购状态 schema 必须是 {self.SCHEMA} / version {AVAILABILITY_SCHEMA_VERSION}")
        source_id = str(payload.get("source_id") or "").strip()
        if not re.fullmatch(r"[A-Za-z0-9._:-]{3,100}", source_id):
            raise DataError("可购状态源缺少合法 source_id")
        try:
            sequence = int(payload.get("sequence"))
        except (TypeError, ValueError) as exc:
            raise DataError("可购状态源缺少合法 sequence") from exc
        if sequence < 1:
            raise DataError("可购状态 sequence 必须 >= 1")
        generated_at = str(payload.get("generated_at") or "")
        expires_at = str(payload.get("expires_at") or "")
        generated = self._dt_aware(generated_at, "generated_at")
        expires = self._dt_aware(expires_at, "expires_at")
        now = _dt.datetime.now().astimezone()
        generated_local = generated.astimezone(now.tzinfo)
        expires_local = expires.astimezone(now.tzinfo)
        if generated_local > now + _dt.timedelta(seconds=MAX_AVAILABILITY_FUTURE_SKEW_SECONDS):
            raise DataError("可购状态 generated_at 比本机时间超前超过 5 分钟")
        if expires <= generated:
            raise DataError("可购状态 expires_at 必须晚于 generated_at")
        if expires - generated > _dt.timedelta(hours=24):
            raise DataError("可购状态有效期超过 24 小时，拒绝过宽可信窗口")

        # Verify the signed envelope before trusting business-level declarations.
        self._verify_signature(payload, public_source=public_source)
        if payload.get("declared") is not True and payload.get("verified") is not True:
            raise DataError("可购状态源没有明确声明 declared/verified=true")
        if require_fresh:
            if now > expires_local:
                raise DataError(f"可购状态已于 {expires_at} 过期")
            max_age = _availability_max_age_seconds(now)
            if _age_seconds(generated_at) > max_age:
                raise DataError(f"可购状态 generated_at 已超过当前时段可信窗口 {max_age // 60} 分钟")

        rows = payload.get("funds")
        if not isinstance(rows, list):
            raise DataError("可购状态 funds 必须是数组")
        seen = set(); purchasable_count = 0
        for index, row in enumerate(rows):
            if not isinstance(row, dict):
                raise DataError(f"可购状态 funds[{index}] 不是对象")
            code = str(row.get("code") or "")
            if not re.fullmatch(r"\d{6}", code):
                raise DataError(f"可购状态包含非法基金代码：{code!r}")
            if code in seen:
                raise DataError(f"可购状态基金代码重复：{code}")
            seen.add(code)
            if row.get("purchasable") is not True:
                continue
            if row.get("declared") is not True and row.get("verified") is not True:
                raise DataError(f"{code} 标为 purchasable 但未声明 declared/verified=true")
            item_time = str(row.get("declared_at") or row.get("verified_at") or generated_at)
            item_stamp = self._dt_aware(item_time, f"{code}.declared_at")
            if item_stamp.astimezone(now.tzinfo) > now + _dt.timedelta(seconds=MAX_AVAILABILITY_FUTURE_SKEW_SECONDS):
                raise DataError(f"{code} 声明时间超前超过 5 分钟")
            if require_fresh and item_stamp > expires:
                raise DataError(f"{code} 声明时间晚于清单 expires_at")
            if require_fresh and _age_seconds(item_time) > _availability_max_age_seconds(now):
                raise DataError(f"{code} 可购声明本身已超过当前时段可信窗口")
            purchasable_count += 1
        if purchasable_count < MIN_AVAILABILITY_FUNDS:
            raise DataError(f"可信可购状态源仅声明 {purchasable_count} 个当前可购具体份额，低于最低 {MIN_AVAILABILITY_FUNDS} 个")
        return payload

    @staticmethod
    def _rollback_guard(new_payload: dict, old_payload: dict) -> None:
        if not isinstance(old_payload, dict):
            return
        if str(new_payload.get("source_id") or "") != str(old_payload.get("source_id") or ""):
            return
        try:
            new_seq, old_seq = int(new_payload.get("sequence")), int(old_payload.get("sequence"))
        except (TypeError, ValueError):
            return
        if new_seq < old_seq:
            raise DataError(f"检测到可购清单 sequence 回滚：{new_seq} < {old_seq}")
        if new_seq == old_seq and AlipayAvailabilitySource._canonical_signature_bytes(new_payload) != AlipayAvailabilitySource._canonical_signature_bytes(old_payload):
            raise DataError("相同 sequence 对应不同可购清单内容，已拒绝")

    def _stale_summary(self, local: dict, *, public_source: bool) -> str:
        try:
            stale = self._validate_payload(local, require_fresh=False, public_source=public_source)
            rows = sum(1 for r in stale.get("funds") or [] if isinstance(r, dict) and r.get("purchasable") is True)
            return (
                f"已保留最后一份验签成功的历史缓存：source_id={stale.get('source_id')}，"
                f"sequence={stale.get('sequence')}，generated_at={stale.get('generated_at')}，"
                f"expires_at={stale.get('expires_at')}，当时可购 {rows} 个份额。"
                "该缓存仅供历史参考，不代表当前支付宝可购。"
            )
        except Exception as exc:
            return f"本地历史快照也无法通过签名/结构校验：{exc}"

    def _load_payload(self) -> tuple[dict, bool]:
        url, is_public, allowed_hosts = self._trusted_url()
        local = _read_json(ALIPAY_FILE_PATH, {})
        if url:
            token = os.environ.get("BEST_ALIPAY_AVAILABILITY_TOKEN", "").strip()
            headers = {"Authorization": f"Bearer {token}"} if token else {}
            try:
                downloaded = _http_json(url, referer="https://open.alipay.com/", timeout=LATEST_TIMEOUT,
                                        attempts=LATEST_ATTEMPTS, headers_extra=headers,
                                        allowed_redirect_hosts=allowed_hosts)
                validated = self._validate_payload(downloaded, require_fresh=True, public_source=is_public)
                # Compare only after the local envelope itself has been validated; an attacker must
                # not be able to pin sequence using an unsigned local file.
                try:
                    old_valid = self._validate_payload(local, require_fresh=False, public_source=is_public)
                except Exception:
                    old_valid = {}
                self._rollback_guard(validated, old_valid)
                self._write_snapshot(validated)
                self.last_snapshot_state = {"current": True, "source_id": validated.get("source_id"),
                                            "generated_at": validated.get("generated_at"), "expires_at": validated.get("expires_at"),
                                            "sequence": validated.get("sequence"), "origin": "online"}
                return validated, is_public
            except Exception as online_exc:
                try:
                    validated = self._validate_payload(local, require_fresh=True, public_source=is_public)
                    self.last_snapshot_state = {"current": True, "source_id": validated.get("source_id"),
                                                "generated_at": validated.get("generated_at"), "expires_at": validated.get("expires_at"),
                                                "sequence": validated.get("sequence"), "origin": "verified-cache"}
                    return validated, is_public
                except Exception:
                    stale = self._stale_summary(local, public_source=is_public)
                    self.last_snapshot_state = {"current": False, "historical_only": stale}
                    raise DataError(f"可信在线可购状态源不可用，且没有仍在有效期内的验签快照：{online_exc}\n{stale}") from online_exc

        # No public endpoint is embedded.  A signed local snapshot can still be inspected as history,
        # but it cannot silently become a zero-configuration current source.
        stale = self._stale_summary(local, public_source=True)
        self.last_snapshot_state = {"current": False, "historical_only": stale}
        raise DataError(
            "未取得可信的支付宝当前可购买基金份额，程序已拒绝生成“支付宝 Top 10”。\n"
            "截至本发行版构建时，公开资料没有提供一个无需机构 app_id/权限、可覆盖支付宝全量当前可购份额的官方公共 API；"
            "因此发行版不会伪造默认地址或把第三方全市场申购状态冒充成支付宝可购。\n"
            "要实现真正开箱即用，发行维护方必须发布并运营 HTTPS 签名清单，然后把 DEFAULT_URL、固定域名白名单和对应 RSA 公钥写入发行版。\n"
            + stale
        )

    @staticmethod
    def _normalize_fee_row(row: dict) -> dict:
        fees = row.get("fees") if isinstance(row.get("fees"), dict) else {}
        return {
            "purchase_fee": _rate(fees.get("purchase_fee")),
            "management_fee_annual": _rate(fees.get("management_fee_annual")),
            "custody_fee_annual": _rate(fees.get("custody_fee_annual")),
            "sales_service_fee_annual": _rate(fees.get("sales_service_fee_annual")),
            "redemption_fee_3y": _rate(fees.get("redemption_fee_3y", fees.get("redemption_fee"))),
            "redemption_fee_5y": _rate(fees.get("redemption_fee_5y", fees.get("redemption_fee"))),
            "redemption_fee_10y": _rate(fees.get("redemption_fee_10y", fees.get("redemption_fee"))),
        }

    def snapshot(self) -> dict[str, dict]:
        payload, is_public = self._load_payload()
        payload = self._validate_payload(payload, require_fresh=True, public_source=is_public)
        declared_at = str(payload.get("generated_at") or "")
        evidence = str(payload.get("evidence") or "signed-source-declaration")
        source_id = str(payload.get("source_id") or "")
        output = {}
        for row in payload.get("funds") or []:
            if row.get("purchasable") is not True:
                continue
            code = str(row.get("code") or "")
            item_time = str(row.get("declared_at") or row.get("verified_at") or declared_at)
            fees = self._normalize_fee_row(row)
            output[code] = {
                "code": code,
                "name": str(row.get("name") or "").strip(),
                "type": str(row.get("type") or "").strip(),
                "share_class": str(row.get("share_class") or "").strip(),
                "availability_declared": True,
                "availability_status": "confirmed_purchasable",
                "availability_note": "支付宝可购：签名清单已确认",
                "fund_data_source": "东方财富基金公开数据（净值）",
                "availability_declared_at": item_time,
                "availability_generated_at": declared_at,
                "availability_expires_at": str(payload.get("expires_at") or ""),
                "availability_sequence": int(payload.get("sequence") or 0),
                "availability_signature_alg": str(payload.get("signature_alg") or ""),
                "availability_source": str(payload.get("source") or "signed-external"),
                "availability_source_id": source_id,
                "availability_evidence": evidence,
                "availability_schema_version": AVAILABILITY_SCHEMA_VERSION,
                "fees_verified": row.get("fees_verified") is True,
                "fees": fees,
                "fees_history": row.get("fees_history") if isinstance(row.get("fees_history"), list) else [],
                "available_from": str(row.get("available_from") or "")[:10],
                "available_to": str(row.get("available_to") or "")[:10],
                "availability_history": row.get("availability_history") if isinstance(row.get("availability_history"), list) else [],
                "product_features": row.get("product_features") if isinstance(row.get("product_features"), dict) else {},
                "product_features_history": row.get("product_features_history") if isinstance(row.get("product_features_history"), list) else [],
                "benchmark": str(row.get("benchmark") or "").strip(),
                "index_code": str(row.get("index_code") or "").strip(),
                "fund_company": str(row.get("fund_company") or "").strip(),
                "theme": str(row.get("theme") or "").strip(),
            }
            output[code].update(_holding_costs(fees))
        if len(output) < 10:
            raise DataError(f"当前可信可购状态源仅返回 {len(output)} 个具体份额，无法生成 Top 10")
        return output


class FundDataSource:
    LIST_URL = "https://fund.eastmoney.com/js/fundcode_search.js"
    HISTORY_URL = "https://api.fund.eastmoney.com/f10/lsjz"
    PING_URL = "https://fund.eastmoney.com/pingzhongdata/{code}.js"
    MOBILE_BASE = "https://fundmobapi.eastmoney.com/FundMNewApi"
    SINA_VERIFY_URL = "https://money.finance.sina.com.cn/fund/go.php/vAkFundInfo_JJGLR/q/{code}.phtml"
    BASIC_URL = "https://fundf10.eastmoney.com/jbgk_{code}.html"
    FEE_URL = "https://fundf10.eastmoney.com/jjfl_{code}.html"

    def all_funds(self) -> list[dict]:
        text = _http_text(self.LIST_URL)
        start, end = text.find("["), text.rfind("]")
        if start < 0 or end <= start:
            raise DataError("基金清单接口返回异常")
        try:
            rows = json.loads(text[start:end + 1])
        except json.JSONDecodeError as exc:
            raise DataError("基金清单解析失败") from exc
        funds = []
        for row in rows:
            if not isinstance(row, list) or len(row) < 4 or not re.fullmatch(r"\d{6}", str(row[0])):
                continue
            funds.append({"code": str(row[0]), "name": str(row[2]), "type": str(row[3])})
        return funds

    def public_fallback_universe(self, limit: int | None = None) -> dict[str, dict]:
        """Zero-configuration non-Alipay fallback.

        It never claims Alipay purchasability. Every structurally eligible catalogue row is kept;
        the normal >=3y history gate decides whether it is usable. No code-order cap or recent-return
        leaderboard is allowed, avoiding both arbitrary universe bias and startup look-ahead.
        """
        # ``limit`` is retained only for source compatibility.  It is intentionally ignored:
        # code-order truncation creates an arbitrary universe bias that is unacceptable for Top 10.
        chosen = sorted(
            (row for row in self.all_funds() if _candidate_allowed(row.get("name", ""), row.get("type", ""))),
            key=lambda row: int(row.get("code") or 999999),
        )
        observed = _now_iso()
        output = {}
        for row in chosen:
            code = row["code"]
            output[code] = {
                **row,
                "availability_declared": False,
                "availability_status": "unknown",
                "availability_declared_at": "",
                "availability_generated_at": observed,
                "availability_expires_at": "",
                "availability_sequence": 0,
                "availability_signature_alg": "",
                "availability_source": "东方财富基金公开基金清单（非支付宝）",
                "availability_source_id": "eastmoney-public-fallback",
                "availability_evidence": "未取得支付宝可购证明；仅确认公开基金数据存在",
                "availability_note": "支付宝可购状态未知（不会因此排除；下单前需在支付宝确认）",
                "availability_schema_version": 0,
                "fund_data_source": "东方财富基金公开基金清单/历史净值",
                "fees_verified": False, "fees": {}, "fees_history": [],
                "available_from": "", "available_to": "", "availability_history": [],
                "share_class": "", "product_features": {}, "product_features_history": [],
                "benchmark": "", "index_code": "", "fund_company": "", "theme": "",
                **_holding_costs({}),
            }
        if len(output) < 25:
            raise DataError(f"公开基金候选池仅 {len(output)} 个，无法进行长期分析")
        return output

    @staticmethod
    def structural_prefilter(availability: dict[str, dict], limit: int | None = None) -> dict[str, dict]:
        """Compatibility shim: never truncate a catalogue by code or a fixed quota."""
        return dict(availability)

    @staticmethod
    def _strip_html(value: str) -> str:
        value = re.sub(r"<script[\s\S]*?</script>|<style[\s\S]*?</style>", " ", value or "", flags=re.I)
        value = re.sub(r"<[^>]+>", " ", value)
        return re.sub(r"\s+", " ", html.unescape(value)).strip()

    @classmethod
    def _parse_basic_metadata(cls, text: str) -> dict:
        """Parse structural metadata published on a fund's public archive page."""
        def cell(*labels: str) -> str:
            for label in labels:
                patterns = (
                    rf">\s*{re.escape(label)}\s*</(?:th|td)>\s*<(?:td|th)[^>]*>([\s\S]*?)</(?:td|th)>",
                    rf"{re.escape(label)}\s*</[^>]+>\s*<(?:td|th)[^>]*>([\s\S]*?)</(?:td|th)>",
                )
                for pattern in patterns:
                    match = re.search(pattern, text or "", flags=re.I)
                    if match:
                        value = cls._strip_html(match.group(1))
                        if value:
                            return value
            return ""

        company = cell("基金管理人", "管理人")
        benchmark = cell("业绩比较基准")
        tracking = cell("跟踪标的", "标的指数")
        inception_raw = cell("成立日期/规模", "成立日期")
        termination_raw = cell("终止日期", "清盘日期")
        objective_match = re.search(
            r"(?:投资目标|投资方向)\s*</[^>]+>\s*(?:<[^>]+>)*([\s\S]{0,1200}?)(?=<h\d|</div>)",
            text or "", flags=re.I,
        )
        objective = cls._strip_html(objective_match.group(1)) if objective_match else ""
        inception_match = re.search(r"\d{4}[-年]\d{1,2}[-月]\d{1,2}", inception_raw)
        termination_match = re.search(r"\d{4}[-年]\d{1,2}[-月]\d{1,2}", termination_raw)

        def normalized_date(match) -> str:
            if not match:
                return ""
            value = match.group(0).replace("年", "-").replace("月", "-").replace("日", "")
            try:
                return _dt.date.fromisoformat("-".join(f"{int(x):02d}" if i else x for i, x in enumerate(value.split("-")))).isoformat()
            except ValueError:
                return ""

        no_tracking = any(word in tracking for word in ("无跟踪标的", "不适用", "--", "暂无"))
        index_code = "" if no_tracking else tracking
        public_theme = _theme(" ".join(value for value in (tracking, objective) if value))
        if public_theme == "宽基/全市场":
            public_theme = ""
        return {
            "fund_company": company,
            "benchmark": benchmark,
            "index_code": index_code,
            "theme": public_theme,
            "inception_date": normalized_date(inception_match),
            "termination_date": normalized_date(termination_match),
            "metadata_source": "东方财富基金档案公开结构化页面",
            "metadata_checked_at": _now_iso(),
        }

    @classmethod
    def _parse_fee_schedule(cls, text: str) -> dict:
        plain = cls._strip_html(text)

        def labelled_rate(label: str) -> float | None:
            match = re.search(rf"{re.escape(label)}[^0-9%]{{0,40}}([0-9]+(?:\.[0-9]+)?)\s*%", plain)
            if match:
                return _rate(float(match.group(1)) / 100.0)
            empty = re.search(rf"{re.escape(label)}\s*(?:---|--|无|不收取)", plain)
            return 0.0 if empty else None

        def segment_after(label: str) -> str:
            position = (text or "").find(label)
            return (text or "")[position:position + 24000] if position >= 0 else ""

        purchase = None
        purchase_rows = re.findall(r"<tr[^>]*>([\s\S]*?)</tr>", segment_after("申购费率"), flags=re.I)
        for row in purchase_rows:
            row_text = cls._strip_html(row)
            rates = [float(value) / 100.0 for value in re.findall(r"([0-9]+(?:\.[0-9]+)?)\s*%", row_text)]
            if rates and any(word in row_text for word in ("小于", "以下", "万元", "申购")):
                purchase = min(rates)
                break

        def duration_bounds(row_text: str) -> tuple[float, float]:
            lower, upper = 0.0, float("inf")
            units = {"天":1.0, "日":1.0, "月":30.4369, "年":365.2425}
            for pattern, kind in (
                (r"(?:大于等于|不少于|≥)([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)", "lower"),
                (r"([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)(?:及|或)?以上", "lower"),
                (r"(?:小于|少于|<)([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)", "upper"),
                (r"([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)(?:以内|以下)", "upper"),
            ):
                for value, unit in re.findall(pattern, row_text):
                    days = float(value) * units[unit]
                    if kind == "lower": lower = max(lower, days)
                    else: upper = min(upper, days)
            return lower, upper

        redemption_rows = []
        for row in re.findall(r"<tr[^>]*>([\s\S]*?)</tr>", segment_after("赎回费率"), flags=re.I):
            row_text = cls._strip_html(row)
            rates = [float(value) / 100.0 for value in re.findall(r"([0-9]+(?:\.[0-9]+)?)\s*%", row_text)]
            if not rates or not any(unit in row_text for unit in ("天", "日", "月", "年", "以上", "以下")):
                continue
            lower, upper = duration_bounds(row_text)
            redemption_rows.append((lower, upper, min(rates)))

        fees = {
            "purchase_fee": purchase,
            "management_fee_annual": labelled_rate("管理费率"),
            "custody_fee_annual": labelled_rate("托管费率"),
            "sales_service_fee_annual": labelled_rate("销售服务费率"),
        }
        for years in (3, 5, 10):
            days = years * 365.2425
            matching = [rate for lower, upper, rate in redemption_rows if lower <= days < upper]
            fees[f"redemption_fee_{years}y"] = min(matching) if matching else None
        complete = fees["purchase_fee"] is not None and all(
            fees.get(key) is not None for key in (
                "sales_service_fee_annual", "redemption_fee_3y", "redemption_fee_5y", "redemption_fee_10y",
            )
        )
        normalized = {key:(0.0 if value is None else _rate(value)) for key,value in fees.items()}
        return {
            "fees": normalized, "fees_verified": bool(complete),
            "fee_schedule_complete": bool(complete),
            "fees_source": "东方财富公开费率表（支付宝下单前仍需复核）",
            **_holding_costs(normalized),
        }

    def basic_metadata(self, code: str) -> dict:
        text = _http_text(
            self.BASIC_URL.format(code=code), referer=f"https://fund.eastmoney.com/{code}.html",
            timeout=5.0, attempts=1,
        )
        result = self._parse_basic_metadata(text)
        try:
            fee_text = _http_text(
                self.FEE_URL.format(code=code), referer=f"https://fund.eastmoney.com/{code}.html",
                timeout=5.0, attempts=1,
            )
            result.update(self._parse_fee_schedule(fee_text))
        except DataError:
            pass
        return result

    def metadata_many(self, funds: list[dict]) -> dict[str, dict]:
        targets = [fund for fund in funds if re.fullmatch(r"\d{6}", str(fund.get("code") or ""))]
        output = {}
        if not targets:
            return output
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(6, len(targets)), thread_name_prefix="fund-meta") as pool:
            future_map = {pool.submit(self.basic_metadata, str(fund["code"])): str(fund["code"]) for fund in targets}
            for future in concurrent.futures.as_completed(future_map):
                code = future_map[future]
                try:
                    output[code] = future.result()
                except Exception:
                    output[code] = {"metadata_source": "公开基金档案暂不可用", "metadata_checked_at": _now_iso()}
        return output

    def candidates(self, availability: dict[str, dict], progress=lambda *_: None) -> list[dict]:
        # No current-return leaderboard is used here. This removes the former selection/look-ahead
        # mechanism where today's winners were selected before historical walk-forward training.
        progress("读取基金全集并与当前可购声明求交集", 6)
        market = {item["code"]: item for item in self.all_funds()}
        selected = []
        for code, verified in availability.items():
            meta = market.get(code, {})
            name = verified.get("name") or meta.get("name") or code
            fund_type = verified.get("type") or meta.get("type") or "其他"
            if not _candidate_allowed(name, fund_type):
                continue
            selected.append({**meta, **verified, "code": code, "name": name, "type": fund_type})
        selected.sort(key=lambda item: item["code"])
        if len(selected) < 25:
            raise DataError(f"当前声明可购且可用于长期量化分析的份额仅 {len(selected)} 个，样本不足")
        return selected

    @staticmethod
    def _history_rows(payload) -> tuple[list[dict], int]:
        if not isinstance(payload, dict):
            return [], 0
        data = payload.get("Data")
        if isinstance(data, dict):
            rows = data.get("LSJZList") or []
            total = int(_finite(data.get("TotalCount"), len(rows)))
            return rows, total
        rows = payload.get("Datas") or []
        total = int(_finite(payload.get("TotalCount"), len(rows)))
        return rows, total

    @staticmethod
    def _normalize_history(rows: list[dict]) -> dict:
        """Build one explicit adjusted total-return series from unit NAV plus corporate actions.

        Reported daily growth is used only when it agrees with the mechanical NAV return, or when
        an explicit dividend/split event explains why unit NAV alone is discontinuous.
        """
        clean = []
        for row in rows:
            date = str(row.get("FSRQ") or "")[:10]
            nav = _finite(row.get("DWJZ"), float("nan"))
            accumulated = _finite(row.get("LJJZ"), float("nan"))
            event = str(row.get("FHFCZ") or row.get("unitMoney") or "").strip()
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) or not math.isfinite(nav) or nav <= 0:
                continue
            change_raw = row.get("JZZZL")
            change = None if change_raw in (None, "", "--") else _finite(change_raw) / 100.0
            clean.append((date, nav, accumulated if math.isfinite(accumulated) and accumulated > 0 else None, change, event))
        clean.sort(key=lambda item: item[0])
        clean = list({item[0]: item for item in clean}.values())
        dates, returns = [], []
        previous_nav = None
        previous_accumulated = None
        provider_fallbacks = corporate_actions = accumulated_confirmations = 0

        def cash_dividend(text: str) -> float:
            if not text:
                return 0.0
            # Common Eastmoney wording: 每份派现金0.123元 / 每10份派1.23元.
            match = re.search(r"每\s*(10)?\s*份[^0-9]{0,12}(?:派|分红|现金)[^0-9]{0,8}([0-9]+(?:\.[0-9]+)?)", text)
            if match:
                amount = _finite(match.group(2), 0.0)
                return amount / 10.0 if match.group(1) else amount
            match = re.search(r"(?:派现金|现金分红)[^0-9]{0,6}([0-9]+(?:\.[0-9]+)?)", text)
            return _finite(match.group(1), 0.0) if match else 0.0

        for date, nav, accumulated, reported, event in clean:
            dates.append(date)
            if previous_nav is None:
                value = 0.0
            else:
                mechanical = nav / previous_nav - 1.0
                accumulated_move = None
                if accumulated is not None and previous_accumulated is not None and previous_accumulated > 0:
                    accumulated_move = accumulated / previous_accumulated - 1.0
                dividend = cash_dividend(event)
                event_flag = bool(event and event not in ("--", "暂无分红"))
                lggj_support = (
                    reported is not None and accumulated_move is not None and -0.8 < reported < 2.0
                    and abs(reported - accumulated_move) <= 0.006
                    and abs(reported - mechanical) >= 0.015
                )
                if dividend > 0:
                    value = (nav + dividend) / previous_nav - 1.0
                    corporate_actions += 1
                    if reported is not None and abs(value - reported) <= 0.006:
                        accumulated_confirmations += int(accumulated_move is not None)
                elif reported is not None and -0.8 < reported < 2.0 and abs(reported - mechanical) <= 0.0035:
                    # Independent agreement: use the mechanically reproducible unit-NAV return.
                    value = mechanical
                elif reported is not None and -0.8 < reported < 2.0 and (event_flag or lggj_support):
                    # Explicit action text remains strong evidence, but LJJZ is an independent second
                    # signal: when unit NAV jumps while cumulative NAV and provider growth agree, a
                    # split/conversion is more plausible than a genuine one-day return.
                    value = reported
                    corporate_actions += 1
                    provider_fallbacks += 1
                    accumulated_confirmations += int(lggj_support)
                else:
                    value = mechanical
            returns.append(_clamp(value, -0.8, 2.0))
            previous_nav = nav
            if accumulated is not None:
                previous_accumulated = accumulated
        return {
            "dates": dates, "returns": returns,
            "latest_nav": clean[-1][1] if clean else None,
            "latest_date": clean[-1][0] if clean else "",
            "return_basis": "adjusted-unit-nav+explicit-corporate-actions",
            "return_provider_fallbacks": provider_fallbacks,
            "return_corporate_actions": corporate_actions,
            "return_accumulated_confirmations": accumulated_confirmations,
        }

    def _ping_history(self, code: str, start: _dt.date) -> dict:
        params = urllib.parse.urlencode({"v": int(time.time() * 1000)})
        text = _http_text(
            self.PING_URL.format(code=code) + "?" + params,
            referer=f"https://fund.eastmoney.com/{code}.html", attempts=1,
        )
        match = re.search(r"var\s+Data_netWorthTrend\s*=\s*(\[[\s\S]*?\])\s*;", text)
        if not match:
            raise DataError(f"{code} 走势图数据缺失")
        try:
            source_rows = json.loads(match.group(1))
        except json.JSONDecodeError:
            source_rows = []
            for object_text in re.findall(r"\{[^{}]*\}", match.group(1)):
                x_match = re.search(r'["\']?x["\']?\s*:\s*(\d+)', object_text)
                y_match = re.search(r'["\']?y["\']?\s*:\s*(-?\d+(?:\.\d+)?)', object_text)
                r_match = re.search(r'["\']?equityReturn["\']?\s*:\s*(-?\d+(?:\.\d+)?)', object_text)
                if x_match and y_match:
                    source_rows.append({
                        "x": int(x_match.group(1)), "y": float(y_match.group(1)),
                        "equityReturn": float(r_match.group(1)) if r_match else None,
                        "unitMoney": "",
                    })
        rows = []
        for row in source_rows:
            try:
                day = _dt.datetime.fromtimestamp(float(row.get("x")) / 1000.0, tz=_dt.timezone.utc).date()
            except (TypeError, ValueError, OSError, OverflowError):
                continue
            if day < start:
                continue
            rows.append({"FSRQ": day.isoformat(), "DWJZ": row.get("y"), "JZZZL": row.get("equityReturn"), "FHFCZ": row.get("unitMoney")})
        result = self._normalize_history(rows)
        if len(result["dates"]) < 450:
            raise DataError(f"{code} 走势图历史不足")
        name_match = re.search(r"var\s+fS_name\s*=\s*['\"]([^'\"]+)['\"]", text)
        if name_match:
            result["name"] = name_match.group(1).strip()
        return result

    def history(self, code: str) -> dict:
        today = _dt.date.today()
        start = today - _dt.timedelta(days=366 * HISTORY_YEARS + 60)
        errors = []
        try:
            return self._ping_history(code, start)
        except DataError as exc:
            errors.append(str(exc))
        mobile_params = {
            "FCODE": code, "pageIndex": 1, "pageSize": 4200, "plat": "Android",
            "appType": "ttjj", "product": "EFund", "version": "6.2.4",
            "deviceid": "best-alipay-funds-local",
        }
        try:
            payload = _http_json(f"{self.MOBILE_BASE}/FundMNHisNetList?" + urllib.parse.urlencode(mobile_params), attempts=1)
            rows, _ = self._history_rows(payload)
            result = self._normalize_history(rows)
            if len(result["dates"]) >= 450:
                return result
        except DataError as exc:
            errors.append(str(exc))
        params = {
            "fundCode": code, "pageIndex": 1, "pageSize": 4200,
            "startDate": start.isoformat(), "endDate": today.isoformat(), "_": int(time.time() * 1000),
        }
        try:
            payload = _http_json(
                self.HISTORY_URL + "?" + urllib.parse.urlencode(params),
                referer="https://fundf10.eastmoney.com/", attempts=1,
            )
            rows, total = self._history_rows(payload)
            if len(rows) >= 450 or total <= len(rows):
                result = self._normalize_history(rows)
                if len(result["dates"]) >= 450:
                    return result
        except DataError as exc:
            errors.append(str(exc))
        raise DataError(f"{code} 历史净值不足或暂不可用：{'；'.join(errors[-2:]) or '数据不足'}")

    def update_history(self, code: str, cached: dict) -> dict:
        """Append only the missing date range when a valid history cache already exists."""
        dates = list(cached.get("dates") or [])
        returns = list(cached.get("returns") or [])
        if len(dates) < MIN_HISTORY_POINTS or len(dates) != len(returns):
            return self.history(code)
        try:
            last_date = _dt.date.fromisoformat(str(cached.get("latest_date") or dates[-1])[:10])
        except ValueError:
            return self.history(code)
        today = _dt.date.today()
        if last_date >= today:
            return {
                "dates": dates, "returns": returns,
                "latest_nav": cached.get("latest_nav"), "latest_date": str(cached.get("latest_date") or dates[-1])[:10],
            }
        delta = max(1, (today - last_date).days)
        params = {
            "fundCode": code, "pageIndex": 1, "pageSize": min(3200, max(64, delta * 3 + 20)),
            "startDate": (last_date - _dt.timedelta(days=7)).isoformat(), "endDate": today.isoformat(), "_": int(time.time() * 1000),
        }
        try:
            payload = _http_json(
                self.HISTORY_URL + "?" + urllib.parse.urlencode(params),
                referer="https://fundf10.eastmoney.com/", attempts=1,
            )
            rows, _ = self._history_rows(payload)
            incremental = self._normalize_history(rows)
            if incremental.get("dates"):
                known = set(dates)
                for day, value in zip(incremental["dates"], incremental["returns"]):
                    if day > dates[-1] and day not in known:
                        dates.append(day)
                        returns.append(value)
                        known.add(day)
                latest_date = max(str(cached.get("latest_date") or dates[-1])[:10], incremental.get("latest_date") or "")
                latest_nav = incremental.get("latest_nav") if incremental.get("latest_date") == latest_date else cached.get("latest_nav")
                return {"dates": dates, "returns": returns, "latest_nav": latest_nav, "latest_date": latest_date}
        except Exception:
            pass
        # Incremental endpoint failed or was incomplete; only then pay the cost of full history.
        return self.history(code)

    def latest(self, codes: list[str], *, timeout=LATEST_TIMEOUT, attempts=LATEST_ATTEMPTS) -> dict[str, dict]:
        if not codes:
            return {}
        params = {
            "pageIndex": 1, "pageSize": max(10, len(codes)), "plat": "Android",
            "appType": "ttjj", "product": "EFund", "Version": "6.2.4",
            "deviceid": "best-alipay-funds-local", "Fcodes": ",".join(codes),
        }
        payload = _http_json(
            f"{self.MOBILE_BASE}/FundMNFInfo?" + urllib.parse.urlencode(params),
            attempts=attempts, timeout=timeout,
        )
        output = {}
        for row in payload.get("Datas") or []:
            code = str(row.get("FCODE") or "")
            if code not in codes:
                continue
            nav = _finite(row.get("NAV"), float("nan"))
            nav_date = str(row.get("PDATE") or "")[:10]
            if not math.isfinite(nav) or nav <= 0 or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", nav_date):
                continue
            output[code] = {
                "code": code, "name": str(row.get("SHORTNAME") or "").strip(),
                "nav": nav,
                "day_change": _finite(row.get("NAVCHGRT"), float("nan")),
                "nav_date": nav_date,
            }
        return output

    def latest_many(self, codes: list[str]) -> dict:
        codes = list(dict.fromkeys(str(code) for code in codes if re.fullmatch(r"\d{6}", str(code))))
        if not codes:
            return {"rows": {}, "requested": 0, "received": 0, "failed_codes": [], "errors": []}
        output = {}
        errors = []
        failed_batches = []
        batches = list(_chunks(codes, LATEST_BATCH_SIZE))
        workers = min(6, len(batches))
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, workers), thread_name_prefix="latest") as pool:
            future_map = {
                pool.submit(self.latest, batch, timeout=LATEST_TIMEOUT, attempts=LATEST_ATTEMPTS): batch
                for batch in batches
            }
            for future in concurrent.futures.as_completed(future_map):
                batch = future_map[future]
                try:
                    output.update(future.result())
                except Exception as exc:
                    failed_batches.extend(batch)
                    errors.append(str(exc))
        missing = [code for code in codes if code not in output]
        failed_codes = list(dict.fromkeys(failed_batches + missing))
        return {
            "rows": output,
            "requested": len(codes),
            "received": len(output),
            "failed_codes": failed_codes,
            "errors": errors,
        }


    def _sina_verify_one(self, item: dict) -> dict:
        code = str(item.get("code") or "")
        if not re.fullmatch(r"\d{6}", code):
            return {"ok": False, "reason": "invalid-code"}
        try:
            text = _http_text(
                self.SINA_VERIFY_URL.format(code=code), referer="https://finance.sina.com.cn/fund/",
                timeout=3.5, attempts=1,
            )
            normalized = re.sub(r"\s+", " ", text)
            code_ok = code in normalized
            name = str(item.get("name") or "").strip()
            # Share-class suffixes and punctuation vary across providers; compare a conservative
            # stem only. Code agreement remains the primary identity check.
            stem = re.sub(r"[A-HI-ZＡ-Ｚ]$", "", name, flags=re.I).strip()
            stem = re.sub(r"[（）()\s·•]", "", stem)
            name_ok = (not stem) or stem[:6] in re.sub(r"[（）()\s·•]", "", normalized)
            company = re.sub(r"基金管理有限公司$|基金管理$|基金$", "", str(item.get("fund_company") or "")).strip()
            company_ok = (not company) or company[:4] in normalized
            nav_match = re.search(r"(?:最新净值|昨日净值)\s*[:：]?\s*([0-9]+(?:\.[0-9]+)?)", normalized)
            sina_nav = _finite(nav_match.group(1), float("nan")) if nav_match else float("nan")
            local_nav = _finite(item.get("display_nav", item.get("latest_nav")), float("nan"))
            # NAV is supporting evidence only because provider publication times differ. Very large
            # disagreement is flagged, never silently overwritten.
            nav_ratio = abs(sina_nav / local_nav - 1.0) if math.isfinite(sina_nav) and math.isfinite(local_nav) and local_nav > 0 else None
            nav_ok = nav_ratio is None or nav_ratio <= 0.25
            return {
                "ok": bool(code_ok and name_ok and nav_ok and company_ok), "code_ok": bool(code_ok), "name_ok": bool(name_ok),
                "company_ok": bool(company_ok),
                "nav_ok": bool(nav_ok), "sina_nav": sina_nav if math.isfinite(sina_nav) else None,
                "nav_relative_diff": nav_ratio, "source": "新浪财经基金中心",
                "url_kind": "money.finance.sina.com.cn/fund",
            }
        except Exception as exc:
            return {"ok": False, "reason": str(exc)[:160], "source": "新浪财经基金中心"}

    def cross_verify_top10(self, items: list[dict]) -> dict:
        rows = list(items[:10])
        if not rows:
            return {"verified": 0, "requested": 0, "source": "新浪财经基金中心"}
        verified = 0; details = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(5, len(rows)), thread_name_prefix="sina-verify") as pool:
            future_map = {pool.submit(self._sina_verify_one, item): item for item in rows}
            for future in concurrent.futures.as_completed(future_map):
                item = future_map[future]
                try:
                    result = future.result()
                except Exception as exc:
                    result = {"ok": False, "reason": str(exc)[:160], "source": "新浪财经基金中心"}
                details[item["code"]] = result
                if result.get("ok"):
                    verified += 1
        for item in rows:
            result = details.get(item["code"], {})
            item["independent_source_verified"] = result.get("ok") is True
            item["metadata_cross_verified"] = result.get("company_ok") is True
            item["independent_source"] = "新浪财经基金中心"
            item["independent_source_nav"] = result.get("sina_nav")
            item["independent_source_note"] = result.get("reason") or ("代码/名称/净值证据一致" if result.get("ok") else "交叉核验不完整")
        return {"verified": verified, "requested": len(rows), "source": "新浪财经基金中心", "details": details}



class LocalStore:
    def __init__(self):
        self.cache = self._load_cache()
        self.model = self._load_model()

    @staticmethod
    def _load_cache() -> dict:
        try:
            with gzip.open(CACHE_PATH, "rt", encoding="utf-8") as handle:
                data = json.load(handle)
            if data.get("version") != CACHE_VERSION:
                raise ValueError("version")
            data.setdefault("funds", {})
            data.setdefault("fund_master", {})
            return data
        except (OSError, ValueError, TypeError, EOFError):
            return {"version": CACHE_VERSION, "updated_at": None, "funds": {}, "fund_master": {}}

    @staticmethod
    def default_model() -> dict:
        return {
            "version": MODEL_VERSION,
            "trained_at": None,
            "feature_names": AdaptiveRanker.FEATURE_NAMES,
            "linear_weights": [0.0] * len(AdaptiveRanker.FEATURE_NAMES),
            "nonlinear_models": [],
            "component_weights": {"expert": 1.0, "linear": 0.0, "nonlinear": 0.0, "external": 0.0},
            "optional_ml": None,
            "validation_ic": 0.0,
            "model_quality": 0.0,
            "validation_metrics": {},
            "full_pipeline_oos": {},
            "untouched_test_oos": {},
            "candidate_deployment_oos": {},
            "expert_deployment_oos": {},
            "training_samples": 0,
            "tuning_samples": 0,
            "deployment_validation_samples": 0,
            "universe_size": 0,
            "historical_availability_coverage": 0.0,
            "historical_availability_used_for_model_selection": False,
            "ai_enabled": False,
            "model_status": "expert-fallback",
            "baseline_metrics": {},
            "split_boundaries": {},
            "universe_codes": [],
            "selection_dataset": "deployment-validation-only; untouched-test-report-only",
            "survivorship_bias": True,
            "engine": "synchronized purged four-way walk-forward; expert fallback; hard-constrained Top10",
        }

    def _load_model(self) -> dict:
        model = _read_json(MODEL_PATH, self.default_model())
        if (
            model.get("version") != MODEL_VERSION
            or model.get("feature_names") != AdaptiveRanker.FEATURE_NAMES
            or len(model.get("linear_weights") or []) != len(AdaptiveRanker.FEATURE_NAMES)
        ):
            model = self.default_model()
        if not MODEL_PATH.exists():
            try:
                _write_json(MODEL_PATH, model)
            except OSError as exc:
                raise DataError(
                    f"无法在脚本目录创建 AI：{MODEL_PATH}\n"
                    f"请将程序解压到具有写权限的文件夹。\n{exc}"
                ) from exc
        return model

    def save_cache(self) -> None:
        raw = json.dumps(self.cache, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        try:
            _atomic_bytes(CACHE_PATH, gzip.compress(raw, compresslevel=6))
        except OSError as exc:
            raise DataError(f"无法在脚本目录写入缓存：{CACHE_PATH}\n{exc}") from exc

    def save_model(self, model: dict) -> None:
        try:
            _write_json(MODEL_PATH, model)
        except OSError as exc:
            raise DataError(f"无法在脚本目录写入 AI：{MODEL_PATH}\n{exc}") from exc
        self.model = model


class AdaptiveRanker:
    FEATURE_NAMES = [
        "return_6m", "return_1y", "return_3y_ann", "sharpe_3y", "sortino_3y",
        "calmar_3y", "drawdown_quality", "volatility_quality", "worst_year",
        "positive_months", "trend_quality", "tail_quality", "stability_quality",
        "recovery_quality", "holding_cost_3y_quality", "holding_cost_5y_quality",
        "holding_cost_10y_quality",
        "return_5y_ann", "return_7y_ann", "return_10y_ann", "drawdown_5y_quality",
        "rolling_3y_worst", "rolling_5y_worst", "recovery_time_quality", "ulcer_quality",
        "bear_stress_quality", "regime_stability_quality", "long_evidence_strength",
    ]
    EXPERT_WEIGHTS = [
        0.28, 0.42, 0.55, 0.68, 0.52, 0.58, 0.78, 0.40, 0.55,
        0.34, 0.22, 0.42, 0.46, 0.22, 0.24, 0.38, 0.34,
        0.95, 0.72, 0.52, 0.88, 0.74, 0.82, 0.48, 0.62, 0.55, 0.58, 0.70,
    ]
    NONLINEAR_SEEDS = (20260816, 27182818, 31415926)
    RANDOM_FEATURE_COUNT = 28
    _RANDOM_RECIPES = {}

    @staticmethod
    def features(
        returns: list[float], end: int | None = None, fees: dict | None = None,
        dates: list[str] | None = None,
    ) -> tuple[list[float], dict] | None:
        end = len(returns) if end is None else min(end, len(returns))
        if end < MIN_HISTORY_POINTS or not dates or len(dates) != len(returns):
            return None
        clean = [_clamp(_finite(value), -0.8, 2.0) for value in returns[:end]]
        date_values = [str(value)[:10] for value in dates[:end]]
        if any(not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) for value in date_values):
            return None
        try:
            history_start_day = _dt.date.fromisoformat(date_values[0])
            feature_day = _dt.date.fromisoformat(date_values[-1])
        except ValueError:
            return None
        long_n = min(756, len(clean) - 1)
        long_values = clean[-long_n:]
        ret_6m = _compound(clean[-min(126, len(clean)):])
        ret_1y = _compound(clean[-min(252, len(clean)):])
        total_long = _compound(long_values)
        years = max(long_n / 252.0, 0.25)
        ann = max(0.01, 1.0 + total_long) ** (1.0 / years) - 1.0
        daily_mean = sum(long_values) / len(long_values)
        daily_std = statistics.pstdev(long_values) if len(long_values) > 1 else 0.0
        volatility = daily_std * math.sqrt(252)
        risk_free = _risk_free_rate()
        sharpe = (daily_mean * 252 - risk_free) / max(volatility, 0.015)
        downside = math.sqrt(sum(min(0.0, r - risk_free / 252) ** 2 for r in long_values) / len(long_values)) * math.sqrt(252)
        sortino = (daily_mean * 252 - risk_free) / max(downside, 0.01)
        max_dd = _max_drawdown(long_values)
        calmar = (ann - risk_free) / max(abs(max_dd), 0.035)
        month_returns = []
        for start in range(max(0, len(long_values) - 504), len(long_values), 21):
            segment = long_values[start:min(start + 21, len(long_values))]
            if len(segment) >= 12:
                month_returns.append(_compound(segment))
        positive_months = sum(value > 0 for value in month_returns) / max(1, len(month_returns))
        rolling_year = []
        recent = long_values[-min(756, len(long_values)):]
        if len(recent) >= 252:
            for finish in range(252, len(recent) + 1, 21):
                rolling_year.append(_compound(recent[finish - 252:finish]))
        worst_year = min(rolling_year) if rolling_year else ret_1y
        rolling_quarter = []
        if len(recent) >= 63:
            for finish in range(63, len(recent) + 1, 21):
                rolling_quarter.append(_compound(recent[finish - 63:finish]))
        stability = -(statistics.pstdev(rolling_quarter) if len(rolling_quarter) > 1 else 0.0)
        trend_values = clean[-min(252, len(clean)):]
        logs, wealth = [], 1.0
        for value in trend_values:
            wealth *= max(0.01, 1.0 + value)
            logs.append(math.log(max(wealth, 1e-9)))
        n = len(logs); x_mean = (n - 1) / 2.0; y_mean = sum(logs) / n
        xx = sum((i - x_mean) ** 2 for i in range(n))
        xy = sum((i - x_mean) * (logs[i] - y_mean) for i in range(n))
        slope = xy / max(xx, 1e-12)
        fitted_var = sum((slope * (i - x_mean)) ** 2 for i in range(n))
        total_var = sum((value - y_mean) ** 2 for value in logs)
        r2 = _clamp(fitted_var / max(total_var, 1e-12), 0.0, 1.0)
        trend_quality = _clamp(slope * 252, -1.0, 1.5) * (0.35 + 0.65 * r2)
        sorted_returns = sorted(long_values); tail_count = max(5, int(len(sorted_returns) * 0.05))
        cvar = sum(sorted_returns[:tail_count]) / tail_count
        recent_year = clean[-min(252, len(clean)):]; wealth = peak = 1.0
        for value in recent_year:
            wealth *= max(0.01, 1.0 + value); peak = max(peak, wealth)
        recovery = wealth / peak - 1.0

        log_prefix = [0.0]
        for value in clean:
            log_prefix.append(log_prefix[-1] + math.log(max(0.01, 1.0 + value)))

        def compound_range(start: int, finish: int) -> float:
            return math.exp(log_prefix[finish] - log_prefix[start]) - 1.0

        def calendar_window(years: int) -> tuple[int, list[float], float, bool]:
            cutoff = _years_before(feature_day, years)
            start_index = bisect.bisect_left(date_values, cutoff.isoformat())
            if start_index >= len(clean) - 1:
                return start_index, [], 0.0, False
            try:
                actual_days = (feature_day - _dt.date.fromisoformat(date_values[start_index])).days
            except ValueError:
                return start_index, [], 0.0, False
            complete = actual_days >= 365 * years - 45
            return start_index, clean[start_index:], actual_days / 365.2425, complete

        def ann_window_years(years: int) -> float:
            start_index, values, actual_years, complete = calendar_window(years)
            if not values or not complete or actual_years <= 0:
                return 0.0
            total = compound_range(start_index, len(clean))
            return max(0.01, 1.0 + total) ** (1.0 / actual_years) - 1.0

        ret_5y_ann = ann_window_years(5)
        ret_7y_ann = ann_window_years(7)
        ret_10y_ann = ann_window_years(10)
        five_start, five_values, _five_years, _five_complete = calendar_window(5)
        max_dd_5y = _max_drawdown(five_values) if five_values else 0.0

        def worst_rolling_years(years: int) -> float:
            values = []
            for finish in range(MIN_HISTORY_POINTS, len(clean) + 1, 21):
                try:
                    finish_day = _dt.date.fromisoformat(date_values[finish - 1])
                except ValueError:
                    continue
                cutoff = _years_before(finish_day, years)
                start_index = bisect.bisect_left(date_values, cutoff.isoformat(), 0, finish)
                if start_index >= finish - 1:
                    continue
                try:
                    span = (finish_day - _dt.date.fromisoformat(date_values[start_index])).days
                except ValueError:
                    continue
                if span >= 365 * years - 45:
                    values.append(compound_range(start_index, finish))
            return min(values) if values else 0.0

        rolling_3y_worst = worst_rolling_years(3)
        rolling_5y_worst = worst_rolling_years(5)
        wealth = peak = 1.0; peak_index = 0; longest_recovery_days = 0; drawdowns = []
        for idx, value in enumerate(five_values):
            wealth *= max(0.01, 1.0 + value)
            if wealth >= peak:
                peak = wealth; peak_index = idx
            else:
                try:
                    recovery_days = (
                        _dt.date.fromisoformat(date_values[five_start + idx])
                        - _dt.date.fromisoformat(date_values[five_start + peak_index])
                    ).days
                except (ValueError, IndexError):
                    recovery_days = idx - peak_index
                longest_recovery_days = max(longest_recovery_days, recovery_days)
            drawdowns.append(wealth / max(peak, 1e-12) - 1.0)
        ulcer = math.sqrt(sum(dd*dd for dd in drawdowns) / max(1, len(drawdowns)))
        sorted_five = sorted(five_values)
        stress_n = max(5, int(len(sorted_five) * 0.05)) if sorted_five else 1
        bear_stress = abs(sum(sorted_five[:stress_n]) / stress_n) * math.sqrt(252) if sorted_five else 0.0
        annual_blocks = []
        for end_pos in range(252, len(five_values)+1, 252):
            annual_blocks.append(_compound(five_values[end_pos-252:end_pos]))
        regime_stability = -(statistics.pstdev(annual_blocks) if len(annual_blocks) > 1 else 0.0)
        history_years = max(0.0, (feature_day - history_start_day).days / 365.2425)
        long_evidence = _clamp((history_years - 3.0) / 7.0, 0.0, 1.0)
        costs = _holding_costs(fees)
        if fees is None:
            model_cost_3y, model_cost_5y, model_cost_10y = 0.20, 0.30, 0.45
        else:
            model_cost_3y, model_cost_5y, model_cost_10y = costs["holding_cost_3y"], costs["holding_cost_5y"], costs["holding_cost_10y"]
        vector = [
            ret_6m, ret_1y, ann, _clamp(sharpe, -5, 8), _clamp(sortino, -5, 12), _clamp(calmar, -5, 10),
            max_dd, -volatility, worst_year, positive_months, trend_quality, -abs(cvar) * math.sqrt(252), stability,
            recovery, -model_cost_3y, -model_cost_5y, -model_cost_10y,
            ret_5y_ann, ret_7y_ann, ret_10y_ann, max_dd_5y,
            rolling_3y_worst, rolling_5y_worst, -longest_recovery_days / (5.0 * 365.2425), -ulcer,
            -bear_stress, regime_stability, long_evidence,
        ]
        sensitivity = {}
        for rf in (0.0, DEFAULT_RISK_FREE_RATE, 0.03):
            s = (daily_mean * 252 - rf) / max(volatility, 0.015)
            d = math.sqrt(sum(min(0.0, r - rf / 252) ** 2 for r in long_values) / len(long_values)) * math.sqrt(252)
            sensitivity[f"{rf:.3f}"] = {"sharpe": s, "sortino": (daily_mean * 252 - rf) / max(d, 0.01)}
        stats = {
            "return_6m": ret_6m, "return_1y": ret_1y, "return_3y_ann": ann, "volatility": volatility,
            "max_drawdown": max_dd, "sharpe": sharpe, "sortino": sortino, "calmar": calmar,
            "positive_months": positive_months, "worst_year": worst_year, "current_drawdown": recovery,
            "return_5y_ann": ret_5y_ann, "return_7y_ann": ret_7y_ann, "return_10y_ann": ret_10y_ann,
            "max_drawdown_5y": max_dd_5y, "rolling_3y_worst": rolling_3y_worst, "rolling_5y_worst": rolling_5y_worst,
            "recovery_days_5y": longest_recovery_days, "ulcer_index_5y": ulcer, "bear_stress_5y": bear_stress,
            "regime_stability_5y": regime_stability, "long_evidence_strength": long_evidence,
            "observations": end, "history_years": history_years, "feature_date": date_values[-1],
            "risk_free_rate": risk_free, "risk_free_sensitivity": sensitivity, **costs,
        }
        return vector, stats

    @staticmethod
    def _solve_ridge(xs: list[list[float]], ys: list[float], sample_weights: list[float], lam: float) -> list[float]:
        if not xs:
            return []
        columns = len(xs[0])
        matrix = [[0.0] * columns for _ in range(columns)]
        target = [0.0] * columns
        for row, y, weight in zip(xs, ys, sample_weights):
            for i in range(columns):
                target[i] += weight * row[i] * y
                for j in range(i, columns):
                    matrix[i][j] += weight * row[i] * row[j]
        for i in range(columns):
            matrix[i][i] += lam
            for j in range(i):
                matrix[i][j] = matrix[j][i]
        augmented = [matrix[i][:] + [target[i]] for i in range(columns)]
        for pivot in range(columns):
            best = max(range(pivot, columns), key=lambda row: abs(augmented[row][pivot]))
            augmented[pivot], augmented[best] = augmented[best], augmented[pivot]
            divisor = augmented[pivot][pivot]
            if abs(divisor) < 1e-12:
                continue
            for column in range(pivot, columns + 1):
                augmented[pivot][column] /= divisor
            for row in range(columns):
                if row == pivot:
                    continue
                factor = augmented[row][pivot]
                if abs(factor) < 1e-15:
                    continue
                for column in range(pivot, columns + 1):
                    augmented[row][column] -= factor * augmented[pivot][column]
        return [augmented[i][-1] for i in range(columns)]

    @classmethod
    def _random_features(cls, row: list[float], seed: int) -> list[float]:
        n = len(row)
        key = (seed, n, cls.RANDOM_FEATURE_COUNT)
        recipes = cls._RANDOM_RECIPES.get(key)
        if recipes is None:
            rng = random.Random(seed)
            recipes = tuple((rng.randrange(n), rng.randrange(n), rng.randrange(n), rng.randrange(5)) for _ in range(cls.RANDOM_FEATURE_COUNT))
            cls._RANDOM_RECIPES[key] = recipes
        result = []
        for a, b, c, mode in recipes:
            if mode == 0: value = row[a] * row[b]
            elif mode == 1: value = abs(row[a] - row[b])
            elif mode == 2: value = row[a] * row[a] * (1.0 if row[a] >= 0 else -1.0)
            elif mode == 3: value = max(row[a], 0.0) + min(row[b], 0.0)
            else: value = math.tanh(1.25 * row[a] - 0.75 * row[b] + 0.50 * row[c])
            result.append(_clamp(value, -2.0, 2.0))
        return result

    @staticmethod
    def _eligibility_at(fund: dict, end: int, as_of_date: str | None = None) -> tuple[bool, bool]:
        """Return (market-investable, historical-Alipay-coverage-known).

        Platform availability is deliberately diagnostic only.  Model samples represent the
        historical public-market universe; today's Alipay status is applied after scoring.
        """
        dates = fund.get("dates") or []
        if end <= 0 or end > len(dates):
            return False, False
        date = str(as_of_date or dates[end - 1])[:10]
        try:
            feature_day = _dt.date.fromisoformat(date)
            observation_day = _dt.date.fromisoformat(str(dates[end - 1])[:10])
        except ValueError:
            return False, False
        if observation_day > feature_day or (feature_day - observation_day).days > 31:
            return False, False
        inception = str(fund.get("inception_date") or dates[0])[:10]
        termination = str(fund.get("termination_date") or "")[:10]
        if inception and date < inception:
            return False, False
        if termination and re.fullmatch(r"\d{4}-\d{2}-\d{2}", termination) and date > termination:
            return False, False
        history = fund.get("availability_history") or []
        if history:
            for span in history:
                if not isinstance(span, dict):
                    continue
                start = str(span.get("from") or "0000-00-00")[:10]
                finish = str(span.get("to") or "9999-99-99")[:10]
                if start <= date <= finish:
                    return True, True
            return True, True
        return True, False

    @staticmethod
    def _eligible_at(fund: dict, end: int, as_of_date: str | None = None) -> bool:
        return AdaptiveRanker._eligibility_at(fund, end, as_of_date)[0]

    @staticmethod
    def _aggregate_underlyings(funds: list[dict]) -> list[dict]:
        groups: dict[str, list[dict]] = {}
        for fund in funds:
            groups.setdefault(_underlying_key(fund), []).append(fund)
        output = []
        for key, shares in groups.items():
            representative = max(
                shares,
                key=lambda fund: (
                    len(fund.get("returns") or []),
                    _share_preference(str(fund.get("name") or "")),
                    -int(str(fund.get("code") or "999999")) if str(fund.get("code") or "").isdigit() else 0,
                ),
            )
            clone = dict(representative)
            clone["underlying_fund_id"] = key
            clone["share_codes"] = sorted(str(row.get("code") or "") for row in shares)
            clone["share_count"] = len(shares)
            output.append(clone)
        output.sort(key=lambda fund: str(fund.get("code") or ""))
        return output

    @staticmethod
    def _quarterly_rebalance_dates(funds: list[dict]) -> list[str]:
        first_dates, last_dates = [], []
        for fund in funds:
            dates = fund.get("dates") or []
            if dates and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(dates[0])[:10]) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(dates[-1])[:10]):
                first_dates.append(str(dates[0])[:10]); last_dates.append(str(dates[-1])[:10])
        if not first_dates or not last_dates:
            return []
        start = _dt.date.fromisoformat(min(first_dates))
        finish = _dt.date.fromisoformat(max(last_dates)) - _dt.timedelta(days=TARGET_ONE_YEAR_DAYS)
        output = []
        for year in range(start.year, finish.year + 1):
            for month in (3, 6, 9, 12):
                day = _dt.date(year, month, calendar.monthrange(year, month)[1])
                while day.weekday() >= 5:
                    day -= _dt.timedelta(days=1)
                if start <= day <= finish:
                    output.append(day.isoformat())
        return output[-48:]

    def _build_snapshots(self, funds: list[dict]) -> tuple[list[dict], dict]:
        underlying_funds = self._aggregate_underlyings(funds)
        snapshots, feature_memo = [], {}
        availability_checks = availability_known = 0
        for rebalance_date in self._quarterly_rebalance_dates(underlying_funds):
            day = _dt.date.fromisoformat(rebalance_date)
            half_end_date = (day + _dt.timedelta(days=TARGET_HALF_YEAR_DAYS)).isoformat()
            year_end_date = (day + _dt.timedelta(days=TARGET_ONE_YEAR_DAYS)).isoformat()
            rows = []
            for fund in underlying_funds:
                returns = fund.get("returns") or []
                dates = fund.get("dates") or []
                if len(dates) != len(returns):
                    continue
                end = bisect.bisect_right(dates, rebalance_date)
                half_end = bisect.bisect_right(dates, half_end_date)
                year_end = bisect.bisect_right(dates, year_end_date)
                if end < MIN_HISTORY_POINTS or half_end <= end or year_end <= half_end:
                    continue
                availability_checks += 1
                eligible, known = self._eligibility_at(fund, end, rebalance_date)
                availability_known += int(known)
                if not eligible:
                    continue
                f126 = returns[end:half_end]
                f252 = returns[end:year_end]
                if len(f126) < MIN_HALF_YEAR_OBSERVATIONS or len(f252) < MIN_ONE_YEAR_OBSERVATIONS:
                    continue
                _pit_product, pit_fees, pit_fees_verified = self._pit_fields(fund, rebalance_date)
                fee_fingerprint = json.dumps(
                    pit_fees if pit_fees_verified else {}, sort_keys=True,
                    ensure_ascii=True, separators=(",", ":"),
                )
                memo_key = (fund["code"], end, fee_fingerprint)
                feature_result = feature_memo.get(memo_key)
                if feature_result is None:
                    feature_result = self.features(
                        returns, end, pit_fees if pit_fees_verified else None, dates=dates,
                    )
                    feature_memo[memo_key] = feature_result
                if not feature_result:
                    continue
                ret126, ret252 = _compound(f126), _compound(f252)
                dd126, dd252 = abs(_max_drawdown(f126)), abs(_max_drawdown(f252))
                vol126 = statistics.pstdev(f126) * math.sqrt(252) if len(f126) > 1 else 0.0
                vol252 = statistics.pstdev(f252) * math.sqrt(252) if len(f252) > 1 else 0.0
                forward_utility = 0.35 * (ret126 - 0.50 * dd126 - 0.06 * vol126) + 0.65 * (ret252 - 0.65 * dd252 - 0.10 * vol252)
                rows.append((
                    fund["code"], feature_result[0], forward_utility, dd252, end, year_end,
                    str(dates[end - 1])[:10], fund.get("name", ""), fund.get("type", ""),
                    fund.get("underlying_fund_id") or _underlying_key(fund),
                ))
            if len(rows) < 24:
                continue
            raw_rows = [row[1] for row in rows]
            buckets = [_asset_bucket(row[7], row[8]) for row in rows]
            snapshots.append({
                "rows": self._scale_feature_rows(raw_rows, buckets),
                "targets": _rank_scale([row[2] for row in rows]),
                "codes": [row[0] for row in rows],
                "drawdowns": [row[3] for row in rows],
                "ends": [row[4] for row in rows],
                "future_ends": [row[5] for row in rows],
                "feature_observation_dates": [row[6] for row in rows],
                "underlying_keys": [row[9] for row in rows],
                "regime": self._regime_from_rows(raw_rows),
                "feature_date": rebalance_date,
                "target_end_date": year_end_date,
                "cross_section_synchronized": True,
            })
        snapshots.sort(key=lambda snap: snap["feature_date"])
        return snapshots, {
            "historical_availability_coverage": availability_known / max(1, availability_checks),
            "source_share_count": len(funds),
            "underlying_count": len(underlying_funds),
            "duplicate_shares_removed": max(0, len(funds) - len(underlying_funds)),
            "funds": underlying_funds,
        }

    @staticmethod
    def _non_overlapping_tail(snapshots: list[dict], limit: int) -> list[dict]:
        chosen = []
        next_feature_start = ""
        for snap in reversed(snapshots):
            if not next_feature_start or str(snap.get("target_end_date") or "") <= next_feature_start:
                chosen.append(snap)
                next_feature_start = str(snap.get("feature_date") or "")
                if len(chosen) >= limit:
                    break
        return list(reversed(chosen))

    @staticmethod
    def _regime_from_rows(rows: list[list[float]]) -> str:
        """Historical regime from *raw* feature vectors, before any cross-sectional rank scaling."""
        if not rows:
            return "range"
        ret6 = _median([row[0] for row in rows])
        vol = _median([-row[7] for row in rows])
        trend = _median([row[10] for row in rows])
        if ret6 < -0.08 or (ret6 < 0 and vol > 0.24):
            return "risk_off"
        if vol > 0.28:
            return "high_vol"
        if ret6 > 0.12 and trend > 0.08:
            return "trend"
        if ret6 > 0.05:
            return "risk_on"
        return "range"

    @staticmethod
    def _scale_feature_rows(rows: list[list[float]], buckets: list[str]) -> list[list[float]]:
        if not rows:
            return []
        groups = {}
        for i, bucket in enumerate(buckets):
            groups.setdefault(bucket, []).append(i)
        global_columns = list(zip(*rows))
        global_scaled = [_rank_scale(list(column)) for column in global_columns]
        output = [[0.0] * len(rows[0]) for _ in rows]
        for indexes in groups.values():
            if len(indexes) < 4:
                for i in indexes:
                    output[i] = [global_scaled[j][i] for j in range(len(global_columns))]
                continue
            for j in range(len(global_columns)):
                scaled = _rank_scale([rows[i][j] for i in indexes])
                for local, i in enumerate(indexes):
                    output[i][j] = scaled[local]
        return output

    @staticmethod
    def _history_snapshot(history, as_of_date: str, value_keys: tuple[str, ...]) -> dict:
        """Latest structured snapshot known on/before as_of_date; never backfill with today's value."""
        if not isinstance(history, list) or not as_of_date:
            return {}
        best_date, best = "", {}
        for row in history:
            if not isinstance(row, dict):
                continue
            date = str(row.get("feature_date") or row.get("effective_date") or row.get("date") or "")[:10]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) or date > as_of_date[:10] or date < best_date:
                continue
            value = None
            for key in value_keys:
                if isinstance(row.get(key), dict):
                    value = row.get(key); break
            if value is None and isinstance(row.get("values"), dict):
                value = row.get("values")
            if value is not None:
                best_date, best = date, dict(value)
        return best

    @classmethod
    def _pit_fields(cls, fund: dict, as_of_date: str) -> tuple[dict, dict, bool]:
        product = cls._history_snapshot(fund.get("product_features_history"), as_of_date, ("product_features", "features"))
        fees = cls._history_snapshot(fund.get("fees_history"), as_of_date, ("fees",))
        # Historical fees are trusted only if the snapshot explicitly declares verification, or
        # if the enclosing trusted manifest supplied a non-empty historical fee snapshot.
        fee_verified = bool(fees)
        return product, fees, fee_verified

    @staticmethod
    def _product_quality(fund: dict, profile: str) -> float:
        f = fund.get("product_features") if isinstance(fund.get("product_features"), dict) else {}
        if not f:
            return 0.0
        bucket = _asset_bucket(fund.get("name", ""), fund.get("type", ""))
        score = 0.0
        if bucket == "指数":
            te = _finite(f.get("tracking_error_annual"), float("nan"))
            size = _finite(f.get("fund_size_billion"), float("nan"))
            if math.isfinite(te): score += _clamp(0.03 - te, -0.04, 0.03)
            if math.isfinite(size): score += 0.008 * _clamp(math.log1p(max(0.0, size)) / 4.0, 0.0, 1.0)
        elif bucket == "主动权益":
            tenure = _finite(f.get("manager_tenure_years"), float("nan"))
            changes = _finite(f.get("manager_changes_3y"), float("nan"))
            alpha = _finite(f.get("benchmark_alpha_3y"), float("nan"))
            drift = _finite(f.get("style_drift"), float("nan"))
            if math.isfinite(tenure): score += 0.012 * _clamp((tenure - 2.0) / 5.0, -1.0, 1.0)
            if math.isfinite(changes): score -= 0.010 * _clamp(changes / 3.0, 0.0, 1.5)
            if math.isfinite(alpha): score += 0.025 * _clamp(alpha / 0.10, -1.0, 1.0)
            if math.isfinite(drift): score -= 0.015 * _clamp(drift, 0.0, 1.0)
        elif bucket == "债券":
            credit = _finite(f.get("credit_risk_score"), float("nan"))
            equity = _finite(f.get("equity_exposure"), float("nan"))
            if math.isfinite(credit): score -= 0.020 * _clamp(credit, 0.0, 1.0)
            if profile == "稳健" and math.isfinite(equity): score -= 0.020 * _clamp(equity / 0.20, 0.0, 1.0)
        return score

    @staticmethod
    def _train_optional_lightgbm(xs: list[list[float]], ys: list[float], weights: list[float]):
        """Train an optional tree model when LightGBM is already installed; never auto-install."""
        mode = os.environ.get("BEST_ALIPAY_OPTIONAL_ML", "auto").strip().lower()
        if mode in {"0","off","false","none","disable","disabled"}:
            return None, None
        try:
            import lightgbm as lgb
            if len(xs) < 180:
                return None, None
            dataset = lgb.Dataset(xs, label=ys, weight=weights or None, free_raw_data=True)
            params = {
                "objective":"regression_l2", "metric":"l2", "learning_rate":0.035,
                "num_leaves":15, "max_depth":5, "min_data_in_leaf":20,
                "feature_fraction":0.90, "bagging_fraction":0.90, "bagging_freq":1,
                "lambda_l1":0.15, "lambda_l2":1.2, "verbosity":-1,
                "seed":20260816, "feature_fraction_seed":20260816, "bagging_seed":20260816,
                "num_threads":max(1,min(4,os.cpu_count() or 2)),
            }
            booster = lgb.train(params, dataset, num_boost_round=90)
            spec = {"backend":"lightgbm", "model_string":booster.model_to_string(), "params":params}
            return spec, (lambda row, b=booster: float(b.predict([row])[0]))
        except Exception:
            # Optional means optional: correctness and the expert fallback must not depend on it.
            return None, None

    @staticmethod
    def _optional_predictor(spec: dict | None):
        if not isinstance(spec, dict) or spec.get("backend") != "lightgbm" or not spec.get("model_string"):
            return None
        try:
            import lightgbm as lgb
            booster = lgb.Booster(model_str=spec["model_string"])
            return lambda row, b=booster: float(b.predict([row])[0])
        except Exception:
            return None

    def _validation_metrics(self, snapshots: list[dict], predict) -> dict:
        rank_ics, top_utils, draw_quality, regimes, top_sets = [], [], [], [], []
        for snap in snapshots:
            preds = [predict(row) for row in snap["rows"]]; targets = snap["targets"]
            rank_ics.append(_spearman(preds, targets))
            k = min(10, len(preds))
            if k <= 0: continue
            order = sorted(range(len(preds)), key=lambda i: preds[i], reverse=True)[:k]
            top_utils.append(sum(targets[i] for i in order) / k)
            dd_scaled = _rank_scale([-snap["drawdowns"][i] for i in range(len(preds))])
            draw_quality.append(sum(dd_scaled[i] for i in order) / k)
            top_sets.append({snap["codes"][i] for i in order}); regimes.append((snap["regime"], rank_ics[-1]))
        rank_ic = sum(rank_ics) / max(1, len(rank_ics)); top10_utility = sum(top_utils) / max(1, len(top_utils))
        drawdown_quality = sum(draw_quality) / max(1, len(draw_quality))
        turnover_values = [1.0 - len(a & b) / max(1, len(a | b)) for a,b in zip(top_sets, top_sets[1:])]
        turnover = sum(turnover_values) / len(turnover_values) if turnover_values else 0.0
        per_regime = {}
        for regime, value in regimes: per_regime.setdefault(regime, []).append(value)
        regime_means = [sum(vs)/len(vs) for vs in per_regime.values()]
        worst_regime = min(regime_means) if regime_means else 0.0
        dispersion = statistics.pstdev(rank_ics) if len(rank_ics) > 1 else 0.0
        stability = 0.5 * (rank_ic - dispersion) + 0.5 * worst_regime
        quality = 0.30*rank_ic + 0.25*top10_utility + 0.20*drawdown_quality + 0.15*stability - 0.10*turnover
        return {
            "rank_ic": rank_ic, "median_rank_ic": statistics.median(rank_ics) if rank_ics else 0.0,
            "positive_rank_ic_ratio": sum(v > 0 for v in rank_ics)/max(1,len(rank_ics)),
            "worst_rank_ic": min(rank_ics) if rank_ics else 0.0, "rank_ic_std": dispersion,
            "top10_utility": top10_utility, "drawdown_quality": drawdown_quality,
            "regime_stability": stability, "worst_regime_rank_ic": worst_regime,
            "turnover": turnover, "model_quality": quality, "windows": len(rank_ics),
        }

    def train(self, funds: list[dict]) -> dict:
        """Synchronized cross-sectional walk-forward with four strictly separated segments."""
        snapshots, snapshot_info = self._build_snapshots(funds)
        training_funds = snapshot_info["funds"]
        historical_coverage = snapshot_info["historical_availability_coverage"]

        untouched_test = self._non_overlapping_tail(snapshots, OOS_UNTOUCHED_TEST_WINDOWS)
        test_feature_start = min((s["feature_date"] for s in untouched_test), default="")
        deployment_candidates = [
            snap for snap in snapshots
            if test_feature_start and snap["target_end_date"] <= test_feature_start
        ]
        deployment_validation = self._non_overlapping_tail(
            deployment_candidates, OOS_DEPLOYMENT_WINDOWS,
        )
        deployment_feature_start = min((s["feature_date"] for s in deployment_validation), default="")
        tune_candidates = [
            snap for snap in snapshots
            if deployment_feature_start and snap["target_end_date"] <= deployment_feature_start
        ]
        tuning = self._non_overlapping_tail(tune_candidates, 2)
        tune_feature_start = min((s["feature_date"] for s in tuning), default="")
        training = [
            snap for snap in snapshots
            if tune_feature_start and snap["target_end_date"] <= tune_feature_start
            and snap not in tuning and snap not in deployment_validation and snap not in untouched_test
        ]

        def flatten(group):
            xs, ys, ws = [], [], []
            latest = max((s["feature_date"] for s in group), default="")
            latest_date = _dt.date.fromisoformat(latest) if latest else _dt.date.today()
            for snap in group:
                try:
                    age_years = max(0.0, (latest_date - _dt.date.fromisoformat(snap["feature_date"])).days / 365.25)
                except ValueError:
                    age_years = 0.0
                weight = math.exp(-0.10 * age_years)
                xs.extend(snap["rows"])
                ys.extend(snap["targets"])
                ws.extend([weight] * len(snap["rows"]))
            return xs, ys, ws

        training_x, training_y, training_w = flatten(training)
        tuning_samples = sum(len(s["rows"]) for s in tuning)
        deployment_samples = sum(len(s["rows"]) for s in deployment_validation)
        test_samples = sum(len(s["rows"]) for s in untouched_test)
        split_boundaries = {
            "train_target_end_max": max((s["target_end_date"] for s in training), default=""),
            "tune_feature_start": tune_feature_start,
            "tune_target_end_max": max((s["target_end_date"] for s in tuning), default=""),
            "deployment_feature_start": deployment_feature_start,
            "deployment_target_end_max": max((s["target_end_date"] for s in deployment_validation), default=""),
            "test_feature_start": test_feature_start,
            "test_target_end_max": max((s["target_end_date"] for s in untouched_test), default=""),
            "label_horizon": "common T to T+183/T+365 calendar days (~126/~252 trading observations)",
            "cross_section_dates": [s["feature_date"] for s in snapshots],
            "deployment_dates": [s["feature_date"] for s in deployment_validation],
            "untouched_test_dates": [s["feature_date"] for s in untouched_test],
            "oos_windows_non_overlapping": True,
        }
        if (
            len(training_x) < 180 or tuning_samples < 60
            or deployment_samples < 45 or test_samples < 45
            or len(deployment_validation) < MIN_OOS_GATE_WINDOWS
            or len(untouched_test) < MIN_OOS_GATE_WINDOWS
        ):
            model = LocalStore.default_model()
            model.update({
                "trained_at": _now_iso(), "universe_size": len(training_funds),
                "source_share_count": snapshot_info["source_share_count"],
                "duplicate_shares_removed": snapshot_info["duplicate_shares_removed"],
                "universe_codes": sorted(f["code"] for f in training_funds),
                "training_samples": len(training_x), "tuning_samples": tuning_samples,
                "deployment_validation_samples": deployment_samples,
                "validation_samples": test_samples,
                "historical_availability_coverage": historical_coverage,
                "split_boundaries": split_boundaries,
                "target": "35% synchronized ~126d + 65% synchronized ~252d risk-adjusted forward utility",
                "model_status": "expert-fallback-insufficient-purged-samples",
                "selection_dataset": "deployment-validation-only; untouched-test-report-only",
                "survivorship_bias": True,
            })
            return model

        linear_candidates = []
        for lam in (0.12, 0.35, 0.9, 2.2, 5.0):
            weights = self._solve_ridge(training_x, training_y, training_w, lam)
            metrics = self._validation_metrics(tuning, lambda row, w=weights: sum(a*b for a,b in zip(w,row)))
            linear_candidates.append((metrics["model_quality"], lam, weights, metrics))
        _, best_lambda, tune_linear_weights, tune_linear_metrics = max(linear_candidates, key=lambda x: x[0])

        tuned_nonlinear = []
        tune_nonlinear_predictors = []
        for seed in self.NONLINEAR_SEEDS:
            train_nl = [self._random_features(row, seed) for row in training_x]
            candidates = []
            for lam in (0.35, 1.2, 3.5):
                weights = self._solve_ridge(train_nl, training_y, training_w, lam)
                predictor = lambda row, w=weights, seed=seed: sum(a*b for a,b in zip(w, self._random_features(row, seed)))
                metrics = self._validation_metrics(tuning, predictor)
                candidates.append((metrics["model_quality"], lam, weights, metrics))
            _, lam, weights, metrics = max(candidates, key=lambda x: x[0])
            tuned_nonlinear.append((seed, lam, weights, metrics))
            tune_nonlinear_predictors.append(
                lambda row, w=weights, seed=seed: sum(a*b for a,b in zip(w, self._random_features(row, seed)))
            )

        optional_tune_spec, optional_tune_predict = self._train_optional_lightgbm(training_x, training_y, training_w)

        expert_scale = sum(abs(v) for v in self.EXPERT_WEIGHTS) or 1.0
        expert_weights = [v / expert_scale for v in self.EXPERT_WEIGHTS]
        expert_predict = lambda row: sum(a*b for a,b in zip(expert_weights,row))
        defensive_predict = lambda row: 0.34*row[6] + 0.28*row[7] + 0.16*row[8] + 0.12*row[12] + 0.10*row[15]
        expert_tune = self._validation_metrics(tuning, expert_predict)
        defensive_tune = self._validation_metrics(tuning, defensive_predict)
        nonlinear_tune = self._validation_metrics(
            tuning,
            lambda row: sum(fn(row) for fn in tune_nonlinear_predictors) / max(1, len(tune_nonlinear_predictors)),
        )
        qualities = {
            "expert": expert_tune["model_quality"],
            "linear": tune_linear_metrics["model_quality"],
            "nonlinear": nonlinear_tune["model_quality"],
        }
        optional_tune_metrics = self._validation_metrics(tuning, optional_tune_predict) if optional_tune_predict else None
        if optional_tune_metrics is not None:
            qualities["external"] = optional_tune_metrics["model_quality"]
        raw_component = {key: max(0.05, value + 0.20) for key, value in qualities.items()}
        total_component = sum(raw_component.values()) or 1.0
        candidate_components = {key: value / total_component for key, value in raw_component.items()}
        def tune_ensemble_predict(row):
            value = (
                candidate_components.get("expert",0.0) * expert_predict(row)
                + candidate_components.get("linear",0.0) * sum(a*b for a,b in zip(tune_linear_weights,row))
                + candidate_components.get("nonlinear",0.0) * sum(fn(row) for fn in tune_nonlinear_predictors) / max(1, len(tune_nonlinear_predictors))
            )
            if optional_tune_predict is not None:
                value += candidate_components.get("external",0.0) * optional_tune_predict(row)
            return value
        tune_ensemble = self._validation_metrics(tuning, tune_ensemble_predict)
        baseline_best = max(expert_tune["model_quality"], defensive_tune["model_quality"])
        tune_gate = (
            tune_ensemble["rank_ic"] > 0.0
            and tune_ensemble["model_quality"] > baseline_best + 0.005
        )
        component_weights = candidate_components if tune_gate else {"expert": 1.0, "linear": 0.0, "nonlinear": 0.0, "external": 0.0}

        # Fit only on train+tune. Deployment validation can enable/disable ML; untouched test can
        # only report the already frozen decision.
        fit_x, fit_y, fit_w = flatten(training + tuning)
        linear_weights = self._solve_ridge(fit_x, fit_y, fit_w, best_lambda)
        scale = sum(abs(v) for v in linear_weights) or 1.0
        linear_weights = [_clamp(v / scale, -1.5, 1.5) for v in linear_weights]

        nonlinear_models = []
        final_nonlinear_predictors = []
        for seed, lam, _old_weights, tune_metrics in tuned_nonlinear:
            fit_nl = [self._random_features(row, seed) for row in fit_x]
            weights = self._solve_ridge(fit_nl, fit_y, fit_w, lam)
            scale = sum(abs(v) for v in weights) or 1.0
            weights = [_clamp(v / scale, -1.5, 1.5) for v in weights]
            nonlinear_models.append({"seed": seed, "lambda": lam, "weights": weights, "tune_metrics": tune_metrics})
            final_nonlinear_predictors.append(
                lambda row, w=weights, seed=seed: sum(a*b for a,b in zip(w, self._random_features(row, seed)))
            )

        optional_model, optional_final_predict = self._train_optional_lightgbm(fit_x, fit_y, fit_w)
        if optional_model is None:
            # A tune-time optional model can disappear only if the package/runtime changed mid-run.
            component_weights["external"] = 0.0
            total_components = sum(max(0.0,v) for v in component_weights.values()) or 1.0
            component_weights = {k:max(0.0,v)/total_components for k,v in component_weights.items()}

        candidate_model = {"linear_weights": linear_weights, "nonlinear_models": nonlinear_models, "optional_ml": optional_model, "component_weights": component_weights, "historical_availability_coverage": historical_coverage}
        expert_model = {"linear_weights": linear_weights, "nonlinear_models": nonlinear_models, "optional_ml": optional_model, "component_weights": {"expert":1.0,"linear":0.0,"nonlinear":0.0,"external":0.0}, "historical_availability_coverage": historical_coverage}
        candidate_deployment_oos = self._full_pipeline_oos(
            training_funds, deployment_validation, candidate_model, "均衡",
        )
        expert_deployment_oos = self._full_pipeline_oos(
            training_funds, deployment_validation, expert_model, "均衡",
        )
        ai_enabled = bool(
            tune_gate
            and candidate_deployment_oos.get("windows", 0) >= MIN_OOS_GATE_WINDOWS
            and candidate_deployment_oos.get("rank_ic_mean", 0) > 0
            and candidate_deployment_oos.get("rank_ic_positive_ratio", 0) >= 0.50
            and candidate_deployment_oos.get("rank_ic_worst", 0) > -0.35
            and candidate_deployment_oos.get("top10_benchmark_win_rate", 0) >= 0.50
            and candidate_deployment_oos.get("quality", -9) > expert_deployment_oos.get("quality", -9)
            and candidate_deployment_oos.get("rank_ic_mean", -9) >= expert_deployment_oos.get("rank_ic_mean", -9)
        )
        if not ai_enabled:
            component_weights = {"expert":1.0,"linear":0.0,"nonlinear":0.0,"external":0.0}
        ensemble_metrics = self._validation_metrics(untouched_test, lambda row: (component_weights.get("expert",0)*expert_predict(row)+component_weights.get("linear",0)*sum(a*b for a,b in zip(linear_weights,row))+component_weights.get("nonlinear",0)*sum(fn(row) for fn in final_nonlinear_predictors)/max(1,len(final_nonlinear_predictors))+(component_weights.get("external",0)*optional_final_predict(row) if optional_final_predict is not None else 0.0)))
        expert_final = self._validation_metrics(untouched_test, expert_predict); defensive_final = self._validation_metrics(untouched_test, defensive_predict)
        final_model_for_oos = {"linear_weights":linear_weights,"nonlinear_models":nonlinear_models,"optional_ml":optional_model,"component_weights":component_weights,"historical_availability_coverage":historical_coverage}
        full_oos = self._full_pipeline_oos(training_funds, untouched_test, final_model_for_oos, "均衡")
        adjusted_quality = full_oos.get("quality", ensemble_metrics["model_quality"])
        status = "ai-enabled-deployment-validation-gated" if ai_enabled else "expert-fallback-deployment-validation-gate"
        return {
            "version": MODEL_VERSION, "trained_at": _now_iso(), "feature_names": self.FEATURE_NAMES,
            "linear_weights": linear_weights, "ridge_lambda": best_lambda,
            "nonlinear_models": nonlinear_models, "optional_ml": optional_model, "component_weights": component_weights,
            "validation_ic": full_oos.get("rank_ic_mean", ensemble_metrics["rank_ic"]), "model_quality": adjusted_quality,
            "validation_metrics": {**full_oos, "base_model_rank_ic": ensemble_metrics["rank_ic"], "base_model_quality": ensemble_metrics["model_quality"]},
            "base_model_validation_metrics": ensemble_metrics,
            "full_pipeline_oos": full_oos, "untouched_test_oos": full_oos,
            "candidate_deployment_oos": candidate_deployment_oos,
            "expert_deployment_oos": expert_deployment_oos,
            "component_quality": qualities,
            "baseline_metrics": {"expert_tune": expert_tune, "defensive_tune": defensive_tune, "expert_untouched": expert_final, "defensive_untouched": defensive_final, "tune_ensemble": tune_ensemble},
            "training_samples": len(training_x), "tuning_samples": tuning_samples,
            "deployment_validation_samples": deployment_samples,
            "validation_samples": test_samples, "universe_size": len(training_funds),
            "source_share_count": snapshot_info["source_share_count"],
            "duplicate_shares_removed": snapshot_info["duplicate_shares_removed"],
            "universe_codes": sorted(f["code"] for f in training_funds),
            "historical_availability_coverage": historical_coverage,
            "historical_availability_used_for_model_selection": False,
            "ai_enabled": ai_enabled, "model_status": status,
            "split_boundaries": split_boundaries,
            "selection_dataset": "deployment-validation-only; untouched-test-report-only",
            "survivorship_bias": True,
            "historical_universe_mode": "current public catalogue plus retained inactive cache; incomplete before first observation",
            "target": "35% synchronized ~126d + 65% synchronized ~252d risk-adjusted forward utility",
            "engine": "synchronized purged four-way walk-forward; deployment gate; untouched report-only test",
            "optional_ml_backend": optional_model.get("backend") if isinstance(optional_model, dict) else "none",
        }

    @staticmethod
    def _market_regime(usable: list[dict]) -> str:
        ret6 = _median([item["stats"]["return_6m"] for item in usable])
        vol = _median([item["stats"]["volatility"] for item in usable])
        trends = _median([item["feature_vector"][10] for item in usable])
        if ret6 < -0.08 or (ret6 < 0 and vol > 0.24):
            return "risk_off"
        if vol > 0.28:
            return "high_vol"
        if ret6 > 0.12 and trends > 0.08:
            return "trend"
        if ret6 > 0.05:
            return "risk_on"
        return "range"

    @staticmethod
    def _choose_share_classes(funds: list[dict], holding_years: int) -> list[dict]:
        years = _expected_holding_years(holding_years)
        groups: dict[str, list[dict]] = {}
        for fund in funds:
            groups.setdefault(_underlying_key(fund), []).append(fund)
        chosen = []
        for underlying, shares in groups.items():
            def preference(fund: dict):
                verified = fund.get("fees_verified") is True
                cost = _share_class_cost(fund, years) if verified else float("inf")
                return (
                    0 if verified else 1,
                    cost,
                    -len(fund.get("returns") or []),
                    -_share_preference(str(fund.get("name") or "")),
                    str(fund.get("code") or ""),
                )
            selected = dict(min(shares, key=preference))
            selected["underlying_fund_id"] = underlying
            selected["selected_holding_years"] = years
            selected["selected_share_class_cost"] = (
                _share_class_cost(selected, years) if selected.get("fees_verified") is True else None
            )
            selected["alternative_share_codes"] = sorted(
                str(row.get("code") or "") for row in shares
                if str(row.get("code") or "") != str(selected.get("code") or "")
            )
            chosen.append(selected)
        return chosen

    def score(
        self, funds: list[dict], model: dict, profile: str,
        feature_cache: dict | None = None, as_of_date: str | None = None,
        holding_years: int | None = None,
    ) -> list[dict]:
        usable = []; feature_cache = feature_cache if feature_cache is not None else {}
        years = _expected_holding_years(holding_years)
        for fund in self._choose_share_classes(funds, years):
            availability_status = str(fund.get("availability_status") or ("confirmed_purchasable" if fund.get("availability_declared") is True else "unknown"))
            if availability_status in {"confirmed_unavailable", "unavailable"}:
                continue
            if fund.get("availability_declared") is True and as_of_date is None and _age_seconds(fund.get("availability_declared_at")) > _availability_max_age_seconds():
                continue
            returns = fund.get("returns") or []; fees = fund.get("fees") if fund.get("fees_verified") else None
            dates = fund.get("dates") or []
            fingerprint = (len(returns), fund.get("latest_date"), str(dates[-1]) if dates else "", round(_finite(returns[-1]) if returns else 0.0, 12), json.dumps(fees or {}, sort_keys=True, ensure_ascii=True, separators=(",", ":")))
            cached = feature_cache.get(fund["code"])
            if cached and cached.get("fingerprint") == fingerprint: result = (cached["vector"], cached["stats"])
            else:
                result = self.features(returns, fees=fees, dates=dates)
                if result: feature_cache[fund["code"]] = {"fingerprint": fingerprint, "vector": result[0], "stats": result[1]}
            if result:
                usable.append({**fund, "feature_vector": result[0], "stats": result[1], "asset_bucket": _asset_bucket(fund.get("name",""), fund.get("type",""))})
        if len(usable) < 10: return []
        scaled_rows = self._scale_feature_rows([item["feature_vector"] for item in usable], [item["asset_bucket"] for item in usable])
        for item, scaled in zip(usable, scaled_rows): item["scaled"] = scaled
        regime = self._market_regime(usable)
        expert_weights = self.EXPERT_WEIGHTS[:]
        if profile == "稳健": expert_weights = [0.12,0.24,0.38,0.68,0.64,0.76,1.18,0.94,0.92,0.48,0.16,0.72,0.72,0.42,0.38,0.58,0.52, 0.72,0.62,0.48,1.18,0.96,1.06,0.72,0.92,0.82,0.78,0.82]
        elif profile == "进取": expert_weights = [0.52,0.72,0.88,0.62,0.38,0.38,0.42,0.18,0.28,0.26,0.58,0.22,0.26,0.12,0.18,0.26,0.22, 1.08,0.82,0.62,0.52,0.62,0.68,0.28,0.36,0.42,0.54,0.62]
        if regime == "risk_off":
            for idx in (6,7,8,11,12,13,15,16): expert_weights[idx] *= 1.25
            for idx in (0,1,2,10): expert_weights[idx] *= 0.75
        elif regime == "trend":
            for idx in (2,3,10): expert_weights[idx] *= 1.20
        elif regime == "high_vol":
            for idx in (6,7,11,12): expert_weights[idx] *= 1.20
        expert_scale = sum(abs(v) for v in expert_weights) or 1.0; expert_weights = [v/expert_scale for v in expert_weights]
        linear_weights = model.get("linear_weights") or [0.0] * len(self.FEATURE_NAMES); nonlinear_models = model.get("nonlinear_models") or []
        optional_predict = self._optional_predictor(model.get("optional_ml"))
        components = dict(model.get("component_weights") or {"expert":1.0,"linear":0.0,"nonlinear":0.0,"external":0.0})
        if optional_predict is None:
            components["external"] = 0.0
        if regime == "risk_off": components["expert"] = components.get("expert",0.0)*1.20; components["nonlinear"] = components.get("nonlinear",0.0)*0.90
        total = sum(max(0.0,v) for v in components.values()) or 1.0; components = {k:max(0.0,v)/total for k,v in components.items()}
        for item in usable:
            vector=item["scaled"]; expert=sum(w*x for w,x in zip(expert_weights,vector)); linear=sum(w*x for w,x in zip(linear_weights,vector))
            nl_values=[]
            for model_row in nonlinear_models:
                rf=self._random_features(vector,int(model_row.get("seed",0))); nl_values.append(sum(w*x for w,x in zip(model_row.get("weights") or [],rf)))
            nonlinear=sum(nl_values)/len(nl_values) if nl_values else 0.0
            external=optional_predict(vector) if optional_predict is not None else 0.0
            raw=components.get("expert",0)*expert + components.get("linear",0)*linear + components.get("nonlinear",0)*nonlinear + components.get("external",0)*external
            # Name keywords are labels only. Product-level adjustments require structured features from the trusted source.
            raw += self._product_quality(item, profile)
            if item["stats"]["return_6m"] > 0.50 and item["stats"]["volatility"] > 0.25: raw -= 0.08
            if not item.get("fees_verified"): raw -= 0.025
            item["raw_score"] = raw; item["market_regime"] = regime; item["theme_label"] = _theme(item.get("name", ""))
            component_values=[expert,linear]+([nonlinear] if nl_values else [])+([external] if optional_predict is not None else []); disagreement=statistics.pstdev(component_values) if len(component_values)>1 else 0.0
            history_factor=0.65*min(1.0,_finite(item["stats"].get("history_years"))/10.0)+0.35*_clamp(_finite(item["stats"].get("long_evidence_strength")),0.0,1.0)
            survivorship_factor = 0.90 if model.get("survivorship_bias", True) else 1.0
            consistency=_clamp(0.58+0.32*history_factor-0.45*disagreement,0.25,0.95)*survivorship_factor
            item["model_consistency"] = round(100.0*_clamp(consistency,0.15,0.95),0)
        # Final score is comparable within asset class; portfolio construction decides cross-asset allocation.
        by_bucket={}
        for item in usable: by_bucket.setdefault(item["asset_bucket"],[]).append(item)
        for rows in by_bucket.values():
            scaled=_rank_scale([x["raw_score"] for x in rows])
            for item,pct in zip(rows,scaled): item["score"]=round(73.0+23.0*pct,1); item["risk"]=self._risk_label(item); item["reason"]=self._reason(item)
        usable.sort(key=lambda item: (item["score"],item["raw_score"]), reverse=True)
        return usable

    @staticmethod
    def _return_correlation(left: dict, right: dict, lookback: int = 504) -> float:
        ld, lr = left.get("dates") or [], left.get("returns") or []; rd, rr = right.get("dates") or [], right.get("returns") or []
        if len(ld) != len(lr) or len(rd) != len(rr): return 0.0
        lmap=dict(zip(ld[-lookback:],lr[-lookback:])); rmap=dict(zip(rd[-lookback:],rr[-lookback:])); common=sorted(set(lmap)&set(rmap))
        if len(common) < 126: return 0.0
        return _clamp(_pearson([lmap[d] for d in common],[rmap[d] for d in common]),-1.0,1.0)

    def select_portfolio(self, scored: list[dict], profile: str) -> list[dict]:
        # Portfolio constraints are hard caps, not score nudges.  Structured fields come only from
        # the trusted source; missing metadata never gets guessed from a fund name.
        profiles = {
            "稳健": {"min": {"债券":3,"指数":1}, "max": {"债券":5,"指数":3,"主动权益":2,"QDII":1,"FOF":2}},
            "均衡": {"min": {"债券":1,"指数":2,"主动权益":2}, "max": {"债券":3,"指数":4,"主动权益":4,"QDII":2,"FOF":2}},
            "进取": {"min": {"指数":2,"主动权益":3}, "max": {"债券":2,"指数":4,"主动权益":5,"QDII":2,"FOF":1}},
        }
        cfg = profiles.get(profile, profiles["均衡"])
        self.last_constraint_error = ""
        remaining=[]; seen=set()
        for item in scored:
            base=_base_name(item.get("name", ""))
            if base in seen:
                continue
            seen.add(base); remaining.append(item)

        available_by_bucket={}
        for item in remaining:
            bucket=item.get("asset_bucket") or _asset_bucket(item.get("name",""),item.get("type",""))
            available_by_bucket[bucket]=available_by_bucket.get(bucket,0)+1
        minimums=dict(cfg["min"])
        impossible = [
            f"{bucket}最低要求{required}只，但候选池仅{available_by_bucket.get(bucket, 0)}只"
            for bucket, required in minimums.items()
            if available_by_bucket.get(bucket, 0) < required
        ]
        if impossible:
            self.last_constraint_error = "组合硬约束无法满足：" + "；".join(impossible)
            return []

        chosen=[]; asset_counts={}; index_counts={}; theme_counts={}; company_counts={}

        def structured_key(item, field):
            value=str(item.get(field) or "").strip().casefold()
            return value if value and value not in {"未知","unknown","n/a","na"} else ""

        def allowed(item) -> bool:
            bucket=item.get("asset_bucket") or _asset_bucket(item.get("name",""),item.get("type",""))
            if asset_counts.get(bucket,0) >= cfg["max"].get(bucket,10):
                return False
            index_code=structured_key(item,"index_code")
            if index_code and index_counts.get(index_code,0) >= 1:
                return False
            theme=structured_key(item,"theme")
            if theme and theme_counts.get(theme,0) >= 2:
                return False
            company=structured_key(item,"fund_company")
            if company and company_counts.get(company,0) >= 2:
                return False
            return True

        def marginal(item):
            corr=[max(0.0,self._return_correlation(item,prior)) for prior in chosen]
            max_corr=max(corr) if corr else 0.0; avg_corr=sum(corr)/len(corr) if corr else 0.0
            div_pen=0.24*max(0.0,max_corr-0.65)+0.08*max(0.0,avg_corr-0.45)
            return item["raw_score"]-div_pen, div_pen, max_corr

        def pick(require_bucket: str | None = None) -> bool:
            best=None
            for index,item in enumerate(remaining):
                bucket=item.get("asset_bucket") or _asset_bucket(item.get("name",""),item.get("type",""))
                if require_bucket is not None and bucket != require_bucket:
                    continue
                if not allowed(item):
                    continue
                value,div_pen,max_corr=marginal(item)
                candidate=(value,index,div_pen,max_corr)
                if best is None or candidate[0]>best[0]:
                    best=candidate
            if best is None:
                return False
            _,idx,div_pen,max_corr=best; item=remaining.pop(idx)
            bucket=item.get("asset_bucket") or _asset_bucket(item.get("name",""),item.get("type",""))
            asset_counts[bucket]=asset_counts.get(bucket,0)+1
            for field,counts in (("index_code",index_counts),("theme",theme_counts),("fund_company",company_counts)):
                key=structured_key(item,field)
                if key:
                    counts[key]=counts.get(key,0)+1
            item["diversification_penalty"]=div_pen; item["asset_budget_penalty"]=0.0; item["max_portfolio_corr"]=max_corr
            item["portfolio_constraints"]="hard:index<=1,theme<=2,company<=2,asset-bounds"
            chosen.append(item)
            return True

        # Satisfy hard lower bounds first.  Pick one at a time to preserve correlation diversity.
        while len(chosen)<10:
            deficits=[(minimums.get(bucket,0)-asset_counts.get(bucket,0),bucket) for bucket in minimums]
            deficits=[row for row in deficits if row[0]>0]
            if not deficits:
                break
            deficits.sort(reverse=True)
            if not pick(deficits[0][1]):
                break
        while remaining and len(chosen)<10:
            if not pick():
                break

        violations = []
        if len(chosen) != 10:
            violations.append(f"要求恰好10只，约束内只能选出{len(chosen)}只")
        for bucket, required in minimums.items():
            actual = asset_counts.get(bucket, 0)
            if actual < required:
                violations.append(f"{bucket}最低{required}只，实际{actual}只")
        for bucket, cap in cfg["max"].items():
            actual = asset_counts.get(bucket, 0)
            if actual > cap:
                violations.append(f"{bucket}最多{cap}只，实际{actual}只")
        for label, counts, cap in (
            ("同一指数", index_counts, 1), ("同一主题", theme_counts, 2), ("同一基金公司", company_counts, 2),
        ):
            for key, actual in sorted(counts.items()):
                if actual > cap:
                    violations.append(f"{label}“{key}”最多{cap}只，实际{actual}只")
        underlying_counts = {}
        for item in chosen:
            key = _underlying_key(item)
            underlying_counts[key] = underlying_counts.get(key, 0) + 1
        duplicates = [key for key, count in underlying_counts.items() if count > 1]
        if duplicates:
            violations.append("同一底层基金出现重复份额：" + "、".join(duplicates[:3]))
        if violations:
            self.last_constraint_error = "组合硬约束无法满足：" + "；".join(violations)
            return []
        return chosen


    @staticmethod
    def _fixed_weight_portfolio_path(paths: list[dict]) -> tuple[float, list[float]]:
        """Initial equal weights, then buy-and-hold with missing-date positions carried forward."""
        clean_paths = []
        for path in paths:
            dates, returns = path.get("dates") or [], path.get("returns") or []
            if len(dates) == len(returns) and dates:
                clean_paths.append(dict(zip(dates, returns)))
        if not clean_paths:
            return 0.0, []
        calendar_dates = sorted(set().union(*(set(path) for path in clean_paths)))
        wealth = [1.0] * len(clean_paths)
        previous_nav = 1.0
        portfolio_returns = []
        for day in calendar_dates:
            for index, path in enumerate(clean_paths):
                if day in path:
                    wealth[index] *= max(0.01, 1.0 + _clamp(_finite(path[day]), -0.95, 3.0))
            nav = sum(wealth) / len(wealth)
            portfolio_returns.append(nav / max(previous_nav, 1e-12) - 1.0)
            previous_nav = nav
        return previous_nav - 1.0, portfolio_returns

    def _full_pipeline_oos(self, funds: list[dict], snapshots: list[dict], model: dict, profile: str = "均衡") -> dict:
        fund_map={f["code"]:f for f in funds}; rank_ics=[]; regime_ics=[]; excess=[]; dds=[]; sortinos=[]; corrs=[]; top_sets=[]; constraint_failures=[]
        for snap in snapshots:
            hist=[]; forward={}; all_forward=[]
            for code,end,future_end in zip(snap.get("codes",[]),snap.get("ends",[]),snap.get("future_ends",[])):
                fund=fund_map.get(code);
                if not fund: continue
                dates=fund.get("dates") or []; returns=fund.get("returns") or []
                final_index=bisect.bisect_right(dates,str(future_end)[:10])
                fwd=returns[end:final_index]; fwd_dates=dates[end:final_index]
                if len(fwd)<MIN_ONE_YEAR_OBSERVATIONS: continue
                feature_date=str(snap.get("feature_date") or "")[:10]
                pit_product,pit_fees,pit_fees_verified=self._pit_fields(fund,feature_date)
                clone={**fund,"returns":list(returns[:end]),"dates":list(dates[:end]),
                       "latest_date":feature_date,"availability_declared":True,"availability_declared_at":feature_date,
                       "product_features":pit_product,"fees":pit_fees,"fees_verified":pit_fees_verified}
                # These current-only fields must never travel backwards through a shallow dict copy.
                clone.pop("display_nav",None); clone.pop("display_nav_date",None)
                hist.append(clone); forward[code]={"dates":fwd_dates,"returns":fwd}; all_forward.append(forward[code])
            scored=self.score(hist,model,profile,{},as_of_date=str(snap.get("feature_date") or ""))
            chosen=self.select_portfolio(scored,profile)
            chosen=[x for x in chosen if x["code"] in forward]
            if len(chosen) != 10:
                constraint_failures.append(self.last_constraint_error or f"{snap.get('feature_date')} 未选满10只")
                continue
            pred={x["code"]:x["raw_score"] for x in scored}; target_map={c:t for c,t in zip(snap["codes"],snap["targets"])}; common=[c for c in pred if c in target_map]
            rank_ics.append(_spearman([pred[c] for c in common],[target_map[c] for c in common]) if len(common)>=3 else 0.0)
            regime_ics.append((str(snap.get("regime") or "unknown"), rank_ics[-1]))
            top_sets.append({x["code"] for x in chosen}); selected=[forward[x["code"]] for x in chosen]
            top_return,portfolio_daily=self._fixed_weight_portfolio_path(selected)
            bench,_bench_daily=self._fixed_weight_portfolio_path(all_forward); excess.append(top_return-bench)
            dds.append(abs(_max_drawdown(portfolio_daily))); rf=_risk_free_rate()/252; downside=math.sqrt(sum(min(0.0,r-rf)**2 for r in portfolio_daily)/max(1,len(portfolio_daily)))*math.sqrt(252)
            sortinos.append((sum(portfolio_daily)/max(1,len(portfolio_daily))*252-_risk_free_rate())/max(downside,0.01))
            pair=[]
            for i in range(len(chosen)):
                for j in range(i+1,len(chosen)): pair.append(max(0.0,self._return_correlation(chosen[i],chosen[j])))
            corrs.append(sum(pair)/len(pair) if pair else 0.0)
        turnovers=[1.0-len(a&b)/max(1,len(a|b)) for a,b in zip(top_sets,top_sets[1:])]; mean=lambda xs: sum(xs)/max(1,len(xs))
        ric=mean(rank_ics); ex=mean(excess); win=sum(v>0 for v in excess)/max(1,len(excess)); dd=max(dds) if dds else 0.0; so=mean(sortinos); turn=mean(turnovers); corr=mean(corrs)
        by_regime={}
        for regime,value in regime_ics: by_regime.setdefault(regime,[]).append(value)
        worst_regime=min((mean(values) for values in by_regime.values()), default=0.0)
        quality=0.30*ric+0.25*ex+0.12*(2*win-1)+0.08*_clamp(so/3.0,-1,1)-0.10*dd-0.08*turn-0.07*corr
        non_overlapping=all(
            str(left.get("target_end_date") or "") <= str(right.get("feature_date") or "")
            for left,right in zip(snapshots,snapshots[1:])
        )
        return {"windows":len(rank_ics),"rank_ic_mean":ric,"rank_ic_median":statistics.median(rank_ics) if rank_ics else 0.0,"rank_ic_positive_ratio":sum(v>0 for v in rank_ics)/max(1,len(rank_ics)),"rank_ic_worst":min(rank_ics) if rank_ics else 0.0,"worst_regime_rank_ic":worst_regime,"top10_excess_return":ex,"oos_annual_excess_return":ex,"top10_benchmark_win_rate":win,"max_oos_drawdown":dd,"oos_sortino":so,"turnover":turn,"portfolio_correlation":corr,"quality":quality,"portfolio_assumption":"initial-equal-weight-buy-and-hold","windows_non_overlapping":non_overlapping,"constraint_failures":constraint_failures}

    @staticmethod
    def _risk_label(item: dict) -> str:
        volatility = item["stats"]["volatility"]
        coarse = _coarse_type(item["type"])
        if coarse == "债券" and volatility < 0.07:
            return "中低"
        if volatility < 0.10:
            return "中"
        if volatility < 0.20:
            return "中高"
        return "高"

    @staticmethod
    def _reason(item: dict) -> str:
        stats = item["stats"]
        strengths = []
        if stats["sharpe"] >= 1.0:
            strengths.append("风险调整收益较强")
        if stats["max_drawdown"] > -0.16:
            strengths.append("长期回撤较低")
        if stats["holding_cost_5y"] <= 0.06 and item.get("fees_verified"):
            strengths.append("长期额外交易成本较低")
        if stats["positive_months"] >= 0.60:
            strengths.append("月度胜率较稳")
        if stats["return_3y_ann"] >= 0.10:
            strengths.append("三年复利靠前")
        if stats["current_drawdown"] < -0.16:
            strengths.append("当前仍在回撤")
        if stats["return_6m"] > 0.50:
            strengths.append("近期涨幅偏热")
        if not strengths:
            strengths.append("多周期综合均衡")
        return "；".join(strengths[:2])


class AnalysisEngine:
    def __init__(self, source=None, availability=None, store=None):
        self.source = source or FundDataSource()
        self.availability = availability or AlipayAvailabilitySource()
        self.store = store or LocalStore()
        self.ranker = AdaptiveRanker()
        self.funds: list[dict] = []
        self.market_funds: list[dict] = []
        self.feature_cache: dict[str, dict] = {}
        self.last_refresh_status = {}
        self.last_cross_check = {}
        self._cross_check_cache: dict[tuple[str,str], dict] = {}
        self.lock = threading.RLock()

    def _availability_snapshot(self) -> dict[str, dict]:
        try:
            snapshot = self.availability.snapshot()
            before = len(snapshot)
            if hasattr(self.source, "structural_prefilter"):
                snapshot = self.source.structural_prefilter(snapshot)
            self.last_availability_mode = "signed-alipay"
            self.last_availability_error = ""
            self.last_candidate_prefilter = {"before": before, "after": len(snapshot), "performance_blind": True}
            return snapshot
        except DataError as exc:
            if not hasattr(self.source, "public_fallback_universe"):
                raise
            snapshot = self.source.public_fallback_universe()
            self.last_availability_mode = "public-fallback-alipay-unknown"
            self.last_availability_error = str(exc)
            self.last_candidate_prefilter = {"before": None, "after": len(snapshot), "performance_blind": True}
            return snapshot

    def cache_age_hours(self) -> float:
        stamp = _parse_iso(self.store.cache.get("updated_at"))
        if stamp is None:
            return float("inf")
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        return max(0.0, (_dt.datetime.now().astimezone() - stamp).total_seconds() / 3600)

    def load_cached(self) -> bool:
        # Cache is performance state, never a trust root. Re-check Alipay evidence on each start;
        # when unavailable, intersect with the explicitly labelled public fallback candidate pool.
        availability = self._availability_snapshot()
        archive = self.store.cache.get("funds", {}) if isinstance(self.store.cache.get("funds", {}), dict) else {}
        active = []
        market_cached = []
        for code, item in archive.items():
            if not isinstance(item, dict):
                continue
            returns, dates = item.get("returns") or [], item.get("dates") or []
            if len(returns) >= MIN_HISTORY_POINTS and len(returns) == len(dates):
                market_cached.append({"code": code, **item})
        for code, declared in availability.items():
            item = archive.get(code)
            if not isinstance(item, dict):
                continue
            returns, dates = item.get("returns") or [], item.get("dates") or []
            if len(returns) < MIN_HISTORY_POINTS or len(returns) != len(dates):
                continue
            if not self._history_recent_enough(item, max_days=5):
                continue
            merged = {"code": code, **item}
            merged.update(self._availability_fields(declared))
            merged["availability_history"] = self._merge_observed_availability(declared, item)
            active.append(merged)
        with self.lock:
            self.funds = active
            self.market_funds = market_cached
            self.feature_cache.clear()
        return len(active) >= 25

    @staticmethod
    def _history_fresh(item: dict) -> bool:
        stamp = _parse_iso(item.get("updated_at"))
        if stamp is None:
            return False
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        return (_dt.datetime.now().astimezone() - stamp).total_seconds() < 14 * 3600

    @staticmethod
    def _history_recent_enough(item: dict, max_days: int = 5) -> bool:
        try:
            latest = _dt.date.fromisoformat(str(item.get("latest_date") or "")[:10])
        except ValueError:
            return False
        # ``max_days`` now means expected market sessions, not natural days.  This avoids treating
        # normal Spring Festival/National Day closures as stale while still rejecting an old series
        # promptly during ordinary weeks.
        return _expected_market_sessions(latest, _dt.date.today()) <= max_days

    @staticmethod
    def _cache_item(item: dict) -> dict:
        keys = (
            "name","type","dates","returns","latest_nav","latest_date","updated_at","day_change",
            "availability_declared","availability_status","availability_note","fund_data_source","availability_declared_at","availability_generated_at","availability_expires_at","availability_sequence","availability_signature_alg",
            "availability_source","availability_source_id","availability_evidence","availability_schema_version",
            "fees_verified","fees","fees_history","fees_source","fee_schedule_complete","annual_cost","embedded_annual_cost","purchase_cost",
            "holding_cost_3y","holding_cost_5y","holding_cost_10y",
            "available_from","available_to","availability_history","share_class","product_features","product_features_history",
            "benchmark","index_code","fund_company","theme",
            "underlying_fund_id","master_code","primary_code","inception_date","termination_date","merged_into",
            "catalog_active","catalog_first_seen","catalog_last_seen","metadata_source","metadata_checked_at",
            "display_nav","display_nav_date","return_pending_adjustment","return_basis","return_provider_fallbacks","return_corporate_actions","return_accumulated_confirmations",
        )
        return {key: item.get(key) for key in keys}

    @staticmethod
    def _normalized_spans(history) -> list[dict]:
        out, seen = [], set()
        if not isinstance(history, list):
            return out
        for span in history:
            if not isinstance(span, dict):
                continue
            start = str(span.get("from") or "")[:10]
            finish = str(span.get("to") or "")[:10]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", start):
                continue
            key = (start, finish, bool(span.get("purchasable", True)))
            if key in seen:
                continue
            seen.add(key)
            out.append({**span, "from": start, "to": finish, "purchasable": span.get("purchasable", True) is True})
        out.sort(key=lambda x: (x["from"], x.get("to") or "9999-99-99"))
        return out

    @classmethod
    def _merge_observed_availability(cls, declared: dict, cached: dict | None) -> list[dict]:
        # Source-supplied PIT history is authoritative when present. Otherwise persist only dates we
        # actually observed in signed manifests; never pretend today's pool existed in the past.
        source_history = cls._normalized_spans(declared.get("availability_history"))
        cached_history = cls._normalized_spans((cached or {}).get("availability_history"))
        history = source_history or cached_history
        if declared.get("availability_declared") is not True:
            return history
        observed = str(declared.get("availability_generated_at") or declared.get("availability_declared_at") or "")[:10]
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", observed):
            return history
        for span in history:
            finish = span.get("to") or "9999-99-99"
            if span.get("purchasable") is True and span.get("from", "") <= observed <= finish:
                return history
        history.append({"from": observed, "to": "", "purchasable": True, "evidence": "observed-signed-manifest"})
        history.sort(key=lambda x: x.get("from", ""))
        return history

    @classmethod
    def _close_observed_availability(cls, cached: dict, observed: str) -> dict:
        result = dict(cached)
        history = cls._normalized_spans(result.get("availability_history"))
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", observed):
            try:
                previous_day = (_dt.date.fromisoformat(observed) - _dt.timedelta(days=1)).isoformat()
            except ValueError:
                previous_day = observed
            for span in reversed(history):
                if span.get("purchasable") is True and not span.get("to"):
                    if span.get("from", "") <= previous_day:
                        span["to"] = previous_day
                    else:
                        history.remove(span)
                    break
        result["availability_history"] = history
        result["availability_declared"] = False
        return result

    @staticmethod
    def _unknown_market_declaration(meta: dict) -> dict:
        return {
            "availability_declared": False, "availability_status": "unknown",
            "availability_declared_at": "", "availability_generated_at": _now_iso(),
            "availability_expires_at": "", "availability_sequence": 0,
            "availability_signature_alg": "", "availability_source": "东方财富公开基金全集（非支付宝）",
            "availability_source_id": "eastmoney-public-market",
            "availability_evidence": "仅用于全市场模型训练；支付宝状态未知",
            "availability_note": "支付宝可购状态未知（仅在今天的最终候选过滤阶段处理）",
            "availability_schema_version": 0, "fund_data_source": "东方财富基金公开清单/历史净值",
            "fees_verified": False, "fees": {}, "fees_history": [],
            "available_from": "", "available_to": "", "availability_history": [],
            "share_class": "", "product_features": {}, "product_features_history": [],
            "benchmark": "", "index_code": "", "fund_company": "", "theme": "",
            **_holding_costs({}),
        }

    @staticmethod
    def _retained_training_pool(current_market: list[dict], archive: dict) -> list[dict]:
        output = {str(item.get("code") or ""): item for item in current_market}
        for code, cached in (archive or {}).items():
            if code in output or not isinstance(cached, dict):
                continue
            dates, returns = cached.get("dates") or [], cached.get("returns") or []
            if len(returns) < MIN_HISTORY_POINTS or len(dates) != len(returns):
                continue
            output[code] = {"code": code, **cached, "catalog_active": False}
        return list(output.values())

    def _enrich_structural_metadata(self, active: list[dict], model: dict, progress=lambda *_: None) -> None:
        if not active or not hasattr(self.source, "metadata_many"):
            model["public_metadata_coverage"] = 0.0
            return
        targets = set()
        for profile in ("稳健", "均衡", "进取"):
            prelim = self.ranker.score(active, model, profile, {}, holding_years=5)
            targets.update(item["code"] for item in prelim[:METADATA_ENRICH_PER_PROFILE])
            per_bucket = {}
            for item in prelim:
                bucket = item.get("asset_bucket") or _asset_bucket(item.get("name", ""), item.get("type", ""))
                if per_bucket.get(bucket, 0) < 12:
                    targets.add(item["code"]); per_bucket[bucket] = per_bucket.get(bucket, 0) + 1
        lookup = {item["code"]: item for item in active}
        pending = []
        for code in sorted(targets):
            item = lookup.get(code)
            if not item:
                continue
            metadata_complete = bool(item.get("fund_company")) and (
                (item.get("asset_bucket") or _asset_bucket(item.get("name", ""), item.get("type", ""))) != "指数"
                or bool(item.get("index_code"))
            ) and item.get("fees_verified") is True
            if metadata_complete and _age_seconds(item.get("metadata_checked_at")) < 90 * 86400:
                continue
            pending.append(item)
        if pending:
            progress(f"补齐 {len(pending)} 个高排名底层基金的公开公司/指数/主题元数据", 89)
            metadata = self.source.metadata_many(pending)
            for code, values in metadata.items():
                item = lookup.get(code)
                if not item or not isinstance(values, dict):
                    continue
                for field in (
                    "fund_company", "benchmark", "index_code", "theme", "inception_date",
                    "termination_date", "metadata_source", "metadata_checked_at",
                ):
                    if values.get(field):
                        item[field] = values[field]
                if values.get("fees_verified") is True and item.get("fees_verified") is not True:
                    for field in (
                        "fees", "fees_verified", "fees_source", "fee_schedule_complete", "annual_cost",
                        "embedded_annual_cost", "purchase_cost", "holding_cost_3y", "holding_cost_5y", "holding_cost_10y",
                    ):
                        if field in values:
                            item[field] = values[field]
        considered = [lookup[code] for code in targets if code in lookup]
        complete = sum(
            bool(item.get("fund_company")) and (
                _asset_bucket(item.get("name", ""), item.get("type", "")) != "指数" or bool(item.get("index_code"))
            )
            for item in considered
        )
        model["public_metadata_coverage"] = complete / max(1, len(considered))

    def _persist_current(self) -> None:
        archive = dict(self.store.cache.get("funds", {}))
        current_codes = {item["code"] for item in self.funds}
        observed_dates = [str(item.get("availability_generated_at") or item.get("availability_declared_at") or "")[:10] for item in self.funds]
        observed_dates = [d for d in observed_dates if re.fullmatch(r"\d{4}-\d{2}-\d{2}", d)]
        observed = max(observed_dates, default=_dt.date.today().isoformat())
        signed_observation = any(item.get("availability_declared") is True for item in self.funds)
        if signed_observation:
            for code, cached in list(archive.items()):
                if code not in current_codes and isinstance(cached, dict):
                    archive[code] = self._close_observed_availability(cached, observed)
        market_items = self.market_funds or self.funds
        for item in market_items:
            cached = archive.get(item["code"]) if isinstance(archive.get(item["code"]), dict) else {}
            if signed_observation and item["code"] not in current_codes:
                closed = self._close_observed_availability(cached, observed)
                item["availability_history"] = closed.get("availability_history") or []
                item["availability_declared"] = False
                item["availability_status"] = "unknown"
            else:
                item["availability_history"] = self._merge_observed_availability(item, cached)
            archive[item["code"]] = self._cache_item(item)
        master = dict(self.store.cache.get("fund_master", {}))
        for code, item in archive.items():
            if not isinstance(item, dict):
                continue
            previous = master.get(code) if isinstance(master.get(code), dict) else {}
            master[code] = {
                "code": code, "name": item.get("name"), "type": item.get("type"),
                "underlying_fund_id": item.get("underlying_fund_id") or _underlying_key({"code": code, **item}),
                "inception_date": item.get("inception_date") or ((item.get("dates") or [""])[0]),
                "termination_date": item.get("termination_date") or "", "merged_into": item.get("merged_into") or "",
                "catalog_first_seen": previous.get("catalog_first_seen") or item.get("catalog_first_seen") or _dt.date.today().isoformat(),
                "catalog_last_seen": item.get("catalog_last_seen") or previous.get("catalog_last_seen") or "",
                "catalog_active": item.get("catalog_active") is True,
            }
        self.store.cache = {"version": CACHE_VERSION, "updated_at": _now_iso(), "funds": archive, "fund_master": master}
        self.store.save_cache()

    def rebuild(self, progress=lambda *_: None, force: bool = False) -> None:
        progress("读取支付宝可购证据；不可得时自动切换公开基金候选池并标注未知", 1)
        availability = self._availability_snapshot()
        progress("扫描完整公开基金全集；历史模型与今天的支付宝过滤解耦", 4)
        if getattr(self, "last_availability_mode", "") == "public-fallback-alipay-unknown":
            market_rows = [
                {"code": code, "name": row.get("name") or code, "type": row.get("type") or "其他"}
                for code, row in availability.items()
            ]
        else:
            market_rows = self.source.all_funds()
        market = {item["code"]: item for item in market_rows}
        for code, declared in availability.items():
            if code not in market:
                market[code] = {"code": code, "name": declared.get("name") or code, "type": declared.get("type") or "其他"}
        existing = self.store.cache.get("funds", {}) if isinstance(self.store.cache.get("funds", {}), dict) else {}
        candidates = []
        today_text = _dt.date.today().isoformat()
        structural_fields = (
            "benchmark", "index_code", "fund_company", "theme", "underlying_fund_id", "master_code",
            "primary_code", "inception_date", "termination_date", "merged_into", "metadata_source", "metadata_checked_at",
        )
        for code, meta in market.items():
            declared = availability.get(code)
            cached = existing.get(code) if isinstance(existing.get(code), dict) else {}
            name = (declared or {}).get("name") or meta.get("name") or cached.get("name") or code
            fund_type = (declared or {}).get("type") or meta.get("type") or cached.get("type") or "其他"
            if not _candidate_allowed(name, fund_type):
                continue
            base = {**meta, **self._unknown_market_declaration(meta), "code": code, "name": name, "type": fund_type}
            for field in structural_fields:
                if cached.get(field):
                    base[field] = cached[field]
            if declared:
                base.update(self._availability_fields(declared))
                base["name"] = name; base["type"] = fund_type
                base["availability_history"] = self._merge_observed_availability(declared, cached)
            else:
                base["availability_history"] = self._normalized_spans(cached.get("availability_history"))
            base["catalog_active"] = True
            base["catalog_first_seen"] = cached.get("catalog_first_seen") or today_text
            base["catalog_last_seen"] = today_text
            candidates.append(base)
        candidates.sort(key=lambda item: item["code"])
        if len(candidates) < 25:
            raise DataError(f"公开全市场中符合分析条件的具体份额仅 {len(candidates)} 个，样本不足")
        completed, total, results, failures = 0, len(candidates), [], []

        def load_one(candidate):
            cached = existing.get(candidate["code"])
            if cached and not force and len(cached.get("returns") or []) >= MIN_HISTORY_POINTS and len(cached.get("returns") or []) == len(cached.get("dates") or []):
                history = self.source.update_history(candidate["code"], cached) if hasattr(self.source, "update_history") else {
                    "dates": cached["dates"], "returns": cached["returns"],
                    "latest_nav": cached.get("latest_nav"), "latest_date": cached.get("latest_date", ""),
                }
            else:
                history = self.source.history(candidate["code"])
            item = {**candidate, **history, "updated_at": _now_iso()}
            item["inception_date"] = item.get("inception_date") or ((item.get("dates") or [""])[0])
            item["underlying_fund_id"] = item.get("underlying_fund_id") or _underlying_key(item)
            return item

        workers = min(10, max(4, os.cpu_count() or 4))
        progress(f"首次全量/后续增量分析 {total} 个公开份额的最长 {HISTORY_YEARS} 年净值", 8)
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers, thread_name_prefix="fund-data") as executor:
            future_map = {executor.submit(load_one, candidate): candidate for candidate in candidates}
            for future in concurrent.futures.as_completed(future_map):
                candidate = future_map[future]
                completed += 1
                try:
                    item = future.result()
                    if len(item.get("returns") or []) >= MIN_HISTORY_POINTS and self._history_recent_enough(item, max_days=5):
                        results.append(item)
                except Exception as exc:
                    failures.append((candidate["code"], str(exc)))
                progress(f"全市场净值 {completed}/{total} · 有效 {len(results)}", 8 + 64 * completed / max(1,total))
        if len(results) < 25:
            if self.load_cached():
                raise DataError("本次全量更新失败，已保留上次可用结果")
            raise DataError(f"有效历史数据仅 {len(results)} 个份额，无法可靠训练")
        current_filter_codes = set(availability)
        active_results = [item for item in results if item["code"] in current_filter_codes]
        if len(active_results) < 10:
            raise DataError(f"今天的最终候选过滤后仅 {len(active_results)} 个历史充分份额，无法生成 Top 10")
        training_pool = self._retained_training_pool(results, existing)
        retained_inactive = sum(item.get("catalog_active") is False for item in training_pool)
        current_model = self.store.model
        trained_at = _parse_iso(current_model.get("trained_at"))
        if trained_at is not None and trained_at.tzinfo is None:
            trained_at = trained_at.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        model_age_days = float("inf") if trained_at is None else max(0.0, (_dt.datetime.now().astimezone() - trained_at).total_seconds() / 86400.0)
        old_codes = set(current_model.get("universe_codes") or [])
        new_codes = {item["code"] for item in training_pool}
        change_ratio = len(old_codes ^ new_codes) / max(1, len(old_codes | new_codes)) if old_codes else 1.0
        should_retrain = force or model_age_days >= MODEL_RETRAIN_DAYS or change_ratio >= 0.05 or current_model.get("version") != MODEL_VERSION
        if should_retrain:
            progress("统一日期横截面 + 四段式 purged walk-forward 训练长期 AI", 75)
            model = self.ranker.train(training_pool)
        else:
            progress(f"净值已刷新；AI 训练年龄 {model_age_days:.1f} 天，候选池变化 {change_ratio:.1%}，本轮不重训", 82)
            model = current_model
        model["full_market_scanned_shares"] = len(results)
        model["retained_inactive_funds"] = retained_inactive
        model["survivorship_bias"] = True
        model["survivorship_note"] = "已保留本机曾观察到的退出基金，但首次运行前的历史清盘/合并基金仍可能缺失"
        self._enrich_structural_metadata(active_results, model, progress)
        progress("按资产/同指数/主题/基金公司硬约束 + 相关性生成长期组合 Top 10", 92)
        with self.lock:
            self.market_funds = training_pool
            self.funds = active_results
            self.feature_cache.clear()
            self.store.save_model(model)
            self._persist_current()
        progress("AI、缓存与可购状态快照已原子保存到脚本目录", 100)

    @staticmethod
    def _return_correlation(left: dict, right: dict, lookback: int = 504) -> float:
        ld, lr = left.get("dates") or [], left.get("returns") or []
        rd, rr = right.get("dates") or [], right.get("returns") or []
        if len(ld) != len(lr) or len(rd) != len(rr):
            return 0.0
        lmap = dict(zip(ld[-lookback:], lr[-lookback:]))
        rmap = dict(zip(rd[-lookback:], rr[-lookback:]))
        common = sorted(set(lmap) & set(rmap))
        if len(common) < 126:
            return 0.0
        return _clamp(_pearson([lmap[d] for d in common], [rmap[d] for d in common]), -1.0, 1.0)

    def rankings(self, profile: str, *, cross_verify: bool = True, holding_years: int | None = None) -> list[dict]:
        with self.lock:
            scored = self.ranker.score(
                self.funds, self.store.model, profile, self.feature_cache,
                holding_years=_expected_holding_years(holding_years),
            )
            for raw_rank, item in enumerate(scored, 1):
                item["ai_raw_rank"] = raw_rank
            chosen = self.ranker.select_portfolio(scored, profile) if scored else []
            if scored and not chosen:
                raise DataError(self.ranker.last_constraint_error or "组合硬约束无法满足")
            for portfolio_rank, item in enumerate(chosen, 1):
                item["portfolio_rank"] = portfolio_rank
        if cross_verify and len(chosen) == 10 and hasattr(getattr(self, "source", None), "cross_verify_top10"):
            try:
                keys = [(item["code"], str(item.get("display_nav_date") or item.get("latest_date") or "")) for item in chosen]
                if all(key in self._cross_check_cache for key in keys):
                    for item,key in zip(chosen,keys):
                        item.update(self._cross_check_cache[key])
                    self.last_cross_check = {"verified":sum(bool(item.get("independent_source_verified")) for item in chosen),"requested":10,"source":"新浪财经基金中心","cached":True}
                else:
                    self.last_cross_check = self.source.cross_verify_top10(chosen)
                    for item,key in zip(chosen,keys):
                        self._cross_check_cache[key] = {k:item.get(k) for k in ("independent_source_verified","metadata_cross_verified","independent_source","independent_source_nav","independent_source_note")}
            except Exception as exc:
                self.last_cross_check = {"verified":0,"requested":10,"source":"新浪财经基金中心","error":str(exc)[:160]}
        return chosen

    @staticmethod
    def _apply_latest_rows(funds: list[dict], latest: dict[str, dict]) -> int:
        updated_series=0; lookup={item["code"]:item for item in funds}
        for code,row in latest.items():
            item=lookup.get(code)
            if not item: continue
            old_date=str(item.get("latest_date") or ((item.get("dates") or [""])[-1])); old_nav=_finite(item.get("latest_nav"),float("nan"))
            new_date=str(row.get("nav_date") or "")[:10]; new_nav=_finite(row.get("nav"),float("nan")); source_day=_finite(row.get("day_change"),float("nan"))
            if row.get("name"): item["name"]=row["name"]
            if math.isfinite(new_nav) and new_nav>0: item["display_nav"]=new_nav
            if new_date: item["display_nav_date"]=new_date
            if math.isfinite(source_day): item["day_change"]=source_day
            if new_date and new_date>old_date and math.isfinite(new_nav) and new_nav>0 and math.isfinite(old_nav) and old_nav>0:
                nav_return=new_nav/old_nav-1.0; source_return=source_day/100.0 if math.isfinite(source_day) else float("nan")
                # Append only when the provider change independently agrees with unit-NAV arithmetic.
                # A disagreement is commonly a dividend/split signal; defer it to history(), which has corporate-action text.
                agreed=math.isfinite(source_return) and abs(source_return-nav_return)<=max(0.0035,0.15*abs(source_return))
                if agreed:
                    item.setdefault("dates",[]).append(new_date); item.setdefault("returns",[]).append(_clamp(nav_return,-0.8,2.0))
                    item["latest_nav"]=new_nav; item["latest_date"]=new_date; item["return_pending_adjustment"]=False; item["updated_at"]=_now_iso(); updated_series+=1
                else:
                    item["return_pending_adjustment"]=True
            elif new_date==old_date and math.isfinite(new_nav) and new_nav>0:
                item["latest_nav"]=new_nav
        return updated_series

    def _resolve_pending_adjustments(self, funds: list[dict], max_workers: int = 4) -> int:
        pending = [item for item in funds if item.get("return_pending_adjustment") is True]
        if not pending:
            return 0
        resolved = 0
        def resolve(item):
            cached = {"dates": list(item.get("dates") or []), "returns": list(item.get("returns") or []),
                      "latest_nav": item.get("latest_nav"), "latest_date": item.get("latest_date", "")}
            return self.source.update_history(item["code"], cached) if hasattr(self.source, "update_history") else self.source.history(item["code"])
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(max_workers, len(pending)), thread_name_prefix="corp-action") as pool:
            futures = {pool.submit(resolve, item): item for item in pending}
            for future in concurrent.futures.as_completed(futures):
                item = futures[future]
                try:
                    history = future.result()
                except Exception:
                    continue
                dates, returns = history.get("dates") or [], history.get("returns") or []
                if len(dates) == len(returns) and len(returns) >= MIN_HISTORY_POINTS and str(history.get("latest_date") or "") >= str(item.get("display_nav_date") or ""):
                    for key in ("dates","returns","latest_nav","latest_date","return_basis","return_provider_fallbacks","return_corporate_actions","return_accumulated_confirmations"):
                        if key in history:
                            item[key] = history[key]
                    item["return_pending_adjustment"] = False; item["updated_at"] = _now_iso(); resolved += 1
        return resolved

    @staticmethod
    def _availability_fields(declared: dict) -> dict:
        keys = (
            "availability_declared","availability_status","availability_note","fund_data_source","availability_declared_at","availability_generated_at","availability_expires_at","availability_sequence","availability_signature_alg",
            "availability_source","availability_source_id","availability_evidence","availability_schema_version",
            "fees_verified","fees","fees_history","fees_source","fee_schedule_complete","annual_cost","embedded_annual_cost","purchase_cost",
            "holding_cost_3y","holding_cost_5y","holding_cost_10y",
            "available_from","available_to","availability_history","share_class","product_features","product_features_history",
            "benchmark","index_code","fund_company","theme",
            "underlying_fund_id","master_code","primary_code","inception_date","termination_date","merged_into",
            "metadata_source","metadata_checked_at",
            "display_nav","display_nav_date","return_pending_adjustment","return_basis","return_provider_fallbacks","return_corporate_actions","return_accumulated_confirmations",
        )
        optional_structural = {
            "benchmark","index_code","fund_company","theme","underlying_fund_id","master_code","primary_code",
            "inception_date","termination_date","merged_into","metadata_source","metadata_checked_at",
        }
        return {
            key: declared[key] for key in keys if key in declared
            and (key not in optional_structural or declared.get(key) not in (None, "", {}, []))
        }

    def _sync_candidate_pool(self, availability: dict[str, dict]) -> tuple[list[str], list[str], list[str]]:
        with self.lock:
            current = {item["code"]: item for item in self.funds}
        availability_codes = set(availability)
        current_codes = set(current)
        removed_codes = sorted(current_codes - availability_codes)
        new_codes = sorted(availability_codes - current_codes)

        # Removed codes are excluded immediately, before any NAV refresh decision.
        kept = []
        for code, item in current.items():
            if code not in availability_codes:
                continue
            declared = availability[code]
            updated = dict(item)
            updated.update(self._availability_fields(declared))
            updated["availability_history"] = self._merge_observed_availability(declared, item)
            updated["name"] = declared.get("name") or updated.get("name") or code
            updated["type"] = declared.get("type") or updated.get("type") or "其他"
            if _candidate_allowed(updated["name"], updated["type"]):
                kept.append(updated)

        needs_market = any(
            not (availability[code].get("name") and availability[code].get("type"))
            for code in new_codes
        )
        market = {row["code"]: row for row in self.source.all_funds()} if needs_market else {}
        new_items, failed_new = [], []
        archive = self.store.cache.get("funds", {})

        def load_new(code: str):
            declared = availability[code]
            name, fund_type = declared.get("name") or "", declared.get("type") or ""
            if not name or not fund_type:
                meta = market.get(code, {})
                name = name or meta.get("name") or code
                fund_type = fund_type or meta.get("type") or "其他"
            if not _candidate_allowed(name, fund_type):
                raise DataError("不符合长期分析条件")
            cached = archive.get(code) if isinstance(archive, dict) else None
            if (
                cached and len(cached.get("returns") or []) >= MIN_HISTORY_POINTS
                and len(cached.get("returns") or []) == len(cached.get("dates") or [])
            ):
                history = self.source.update_history(code, cached) if hasattr(self.source, "update_history") else {
                    "dates": list(cached["dates"]), "returns": list(cached["returns"]),
                    "latest_nav": cached.get("latest_nav"), "latest_date": cached.get("latest_date", ""),
                }
            else:
                history = self.source.history(code)
            if len(history.get("returns") or []) < MIN_HISTORY_POINTS:
                raise DataError("历史净值不足")
            merged_declared = dict(declared)
            merged_declared["availability_history"] = self._merge_observed_availability(declared, cached if isinstance(cached, dict) else None)
            return {**merged_declared, **history, "code": code, "name": name, "type": fund_type, "updated_at": _now_iso()}

        if new_codes:
            with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(new_codes)), thread_name_prefix="new-fund") as pool:
                futures = {pool.submit(load_new, code): code for code in new_codes}
                for future in concurrent.futures.as_completed(futures):
                    code = futures[future]
                    try:
                        new_items.append(future.result())
                    except Exception:
                        failed_new.append(code)

        with self.lock:
            self.funds = kept + new_items
            market_lookup = {item["code"]: item for item in (self.market_funds or self.funds)}
            for item in kept + new_items:
                market_lookup[item["code"]] = item
            self.market_funds = list(market_lookup.values())
            for code in removed_codes + failed_new:
                self.feature_cache.pop(code, None)
        return [item["code"] for item in new_items], removed_codes, failed_new

    def refresh_latest(self, profile: str, holding_years: int | None = None) -> dict:
        started = time.monotonic()
        years = _expected_holding_years(holding_years)
        # Snapshot first, then make the candidate pool exactly match that snapshot before
        # asking for latest NAVs. This is what lets newly listed funds enter within one tick.
        availability = self._availability_snapshot()
        added, removed, failed_new = self._sync_candidate_pool(availability)
        with self.lock:
            all_codes = [item["code"] for item in self.funds]
            priority_scored = self.ranker.score(
                self.funds, self.store.model, profile, self.feature_cache,
                holding_years=years,
            )
            priority_codes = {item["code"] for item in priority_scored[:LATEST_PRIORITY_COUNT]}
        if len(all_codes) < 10:
            self._persist_current()
            raise DataError("当前候选且历史数据充足的份额不足 10 个")

        report = self.source.latest_many(all_codes)
        requested = int(report.get("requested", len(all_codes)))
        received = int(report.get("received", len(report.get("rows") or {})))
        coverage = received / max(1, requested)
        priority_missing = sorted(priority_codes - set(report.get("rows") or {}))
        priority_complete = not priority_missing
        ranking_updated = coverage >= REFRESH_MIN_COVERAGE and priority_complete
        updated_series = 0
        resolved_adjustments = 0

        if ranking_updated:
            with self.lock:
                updated_series = self._apply_latest_rows(self.funds, report.get("rows") or {})
                resolved_adjustments = self._resolve_pending_adjustments(self.funds)
                updated_series += resolved_adjustments
                self._persist_current()
                results = self.rankings(profile, holding_years=years)
            if coverage >= 0.999999:
                status = "可购池与全候选池最新净值已刷新"
            else:
                status = f"最新净值覆盖 {coverage:.1%}，且 Top {len(priority_codes)} 候选完整，已重排"
        else:
            # Do not partially mutate returns: preserve the last internally consistent NAV
            # cross-section. Availability additions/removals have already been synchronized.
            with self.lock:
                self._persist_current()
                results = self.rankings(profile, holding_years=years)
            if coverage < REFRESH_MIN_COVERAGE:
                status = f"本轮最新净值覆盖 {coverage:.1%}，低于总体门槛 {REFRESH_MIN_COVERAGE:.1%}；净值排名未更新"
            else:
                status = f"总体覆盖 {coverage:.1%}，但 Top 候选缺失 {len(priority_missing)} 个；净值排名未更新"
            if added or removed:
                status += "（可购池增删已同步）"

        if len(results) != 10:
            raise DataError("当前候选且历史数据充足的份额不足 10 个，无法输出 Top 10")
        outcome = {
            "results": results, "status": status, "coverage": coverage,
            "requested": requested, "received": received,
            "failed_codes": report.get("failed_codes") or [],
            "priority_codes": sorted(priority_codes), "priority_missing_codes": priority_missing,
            "priority_complete": priority_complete,
            "ranking_updated": ranking_updated, "new_codes": added,
            "removed_codes": removed, "failed_new_codes": failed_new,
            "updated_series": updated_series, "resolved_adjustments": resolved_adjustments, "elapsed_seconds": time.monotonic() - started,
        }
        self.last_refresh_status = outcome
        return outcome


METHOD_TEXT = """这是什么

这是一个本地运行的长期基金筛选器。优先使用“通过签名验证、仍在有效期内的支付宝当前可购声明”；若发行方没有提供该清单或清单临时不可用，程序会自动使用东方财富公开基金清单/净值做非支付宝候选池，并把每只基金明确标为“支付宝可购状态未知（未排除）”。未知绝不会被写成已确认可购。

数据来源（用户应当知道）

1）支付宝当前可购：若存在 best-alipay-funds-availability-v5 签名清单，则使用它确认“已可购”；签名/时效不通过绝不升级为已确认。若没有可信清单，程序不再退出，而是将支付宝状态记为“未知”，并继续用非支付宝公开数据做基金质量分析。东方财富/新浪从不被冒充成支付宝可购证明。

2）基金全集、历史净值和最新净值主源：东方财富基金公开数据接口。

3）最终 Top 10 独立复核：新浪财经基金中心，交叉检查基金代码、名称与可解析净值证据。新浪复核只用于发现主数据异常，绝不升级为“支付宝可购证明”。

可信源与缓存安全

公共源无 RSA-SHA256 签名直接拒绝；私有 HMAC 只有显式私有 URL 才允许。清单 sequence 防回滚，同一 sequence 内容变化也拒绝；generated_at 最多允许轻微时钟偏差，expires_at 必须晚于 generated_at 且有效窗口不得超过 24 小时。下载内容先验签、再做业务校验、再原子落盘。启动时 gzip/cache 只是性能缓存，不是信任根：每个新进程必须重新验证当前签名可购清单后才能使用缓存排名。服务端不可达时，只要本地验签快照仍在有效期可继续；一旦过期则降级为“支付宝状态未知”的公开数据候选模式。expires_at 始终是硬期限；generated_at 的新鲜度按交易活跃时段较短、深夜/周末较长的窗口检查。

Point-in-time、全市场与历史可购

AI 在公开全市场的历史可投资底层基金上训练，availability_history 只作为支付宝历史覆盖诊断，不再决定 ML 能否启用；支付宝/疑似支付宝可购只过滤今天最终展示的候选。每次运行扫描完整结构合格全集，历史净值落盘后只做增量更新，不按基金代码截 140/220 只。客户端仍会积累签名可购区间，但不会把今天的可购状态伪造回过去。历史训练/回测里的 product_features 与 fees 只允许读取统一 feature_date 当天及以前的历史快照；没有历史快照就按未知处理。

长期持有特征

评分除 6个月/1年/3年外，5年、7年、10年年化均按真实日历日期窗口和实际 CAGR 计算，不再要求恰好 1260/1764/2520 条记录；默认下载 12 年。另含日期化滚动3年/5年最差收益、5年最大回撤/恢复时间、Ulcer Index、极端下行压力、年度 regime 稳定性与长期证据强度。成立不足5年的基金不硬排除，但长期证据强度下降。

同步横截面、四段式 walk-forward 与 AI

程序先生成统一季度再平衡日 T；每只基金只允许使用 <=T 的数据，未来约126/252交易观察统一覆盖 T→T+183/T+365 日。数据严格拆成 train → tune → deployment-validation → untouched-test，并按 target_end_date purge；是否启用 ML 只能读取 tune 与非重叠 deployment-validation，untouched-test 决策冻结后只负责报告。标准库专家模型始终是绝对 fallback；若环境已有 LightGBM，会额外训练小型树模型，但不会自动安装第三方包。

份额与 OOS 组合假设

A/C/I 等份额在训练、调参和 OOS 前按底层基金聚合，不重复增加样本量。今天推荐时可选预计持有 3/5/10 年；若取得可信费率，按申购费、赎回费及份额年度费用选择成本更低的具体份额，费率未知时明确标注。OOS 收益、回撤与 Sortino 全部来自同一条“初始等权、随后持有不动”的组合 NAV，不混用每日再平衡。

总回报与公司行动

历史收益以单位净值为机械基准。明示现金分红优先按现金分红复权；普通日涨跌必须与单位净值算术一致才直接采用。LJJZ 累计净值现在作为第二证据：当单位净值出现大幅不连续、而累计净值变化和提供方日增长一致时，可辅助识别拆分/折算，而不再只依赖 FHFCZ 文本正则。最新日若证据冲突，先标记待复权，不写入训练收益。

组合硬约束

界面同时显示“AI原始排名”和“分散化组合排名”。签名源或普通公开基金档案提供的 index_code / theme / fund_company 等结构化字段都会用于同一指数最多 1 只、同主题最多 2 只、同基金公司最多 2 只，并按稳健/均衡/进取设置资产类别硬上下限；结构化字段缺失时不从基金名称猜测。选完后会重新完整校验原始最低值、全部上限、底层基金去重及恰好10只；任何一条不满足都返回空结果并明确报出具体约束，绝不偷偷放宽。

存续偏差与网络可靠性

缓存维护基金主表、成立/终止/合并字段及本机曾观察到的退出基金，并在历史截面按当时净值存在性恢复候选；但首次运行之前已清盘且不在公开清单中的基金仍可能缺失，所以界面明确标注可能存在存续偏差。网络响应同时限制压缩前/解压后大小；签名可购请求的重定向只能留在 HTTPS 白名单主机。净值新鲜度按预计交易日而非10个自然日判断；实时更新采用“总体覆盖率 + Top候选必须完整”双门槛。

评分与风险

73～96 分是横截面“相对评分”，不是盈利概率；证据强度也不是推荐正确率。基金投资可能亏损，历史表现不预示未来。即使签名清单显示当前可购，下单前仍应在实际支付宝页面确认实时限购、费率、官方风险等级和适当性要求。
"""


class FundsApp:
    def __init__(self, root, tk, ttk, messagebox):
        self.root, self.tk, self.ttk, self.messagebox = root, tk, ttk, messagebox
        self.engine = AnalysisEngine()
        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.busy = False
        self.refreshing = False
        self.refresh_policy = SmartRefreshPolicy()
        self.next_refresh = float("inf")
        self.current = []
        self.profile = tk.StringVar(value="均衡")
        self.holding_years = tk.IntVar(value=_expected_holding_years())
        self.status = tk.StringVar(value="正在启动本地 AI…")
        self.clock = tk.StringVar(value="智能刷新：等待首次分析")
        self.model_info = tk.StringVar(value="模型：等待训练")
        self.data_info = tk.StringVar(value="数据日期：—")
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(120, self._poll_events)
        self.root.after(1000, self._tick)
        self._start_initial()

    def _build_ui(self):
        self.root.title(f"{APP_NAME} {VERSION}")
        self.root.geometry("1540x780")
        self.root.minsize(1120, 640)
        self.root.configure(bg="#0b1220")
        try:
            self.root.iconname(APP_NAME)
        except Exception:
            pass
        style = self.ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except self.tk.TclError:
            pass
        font = ("Microsoft YaHei UI", 10)
        style.configure(".", font=font)
        style.configure("Root.TFrame", background="#0b1220")
        style.configure("Card.TFrame", background="#111c31")
        style.configure("Title.TLabel", background="#0b1220", foreground="#f8fafc", font=("Microsoft YaHei UI", 22, "bold"))
        style.configure("Sub.TLabel", background="#0b1220", foreground="#94a3b8", font=("Microsoft YaHei UI", 10))
        style.configure("Badge.TLabel", background="#18263f", foreground="#cbd5e1", padding=(10, 5))
        style.configure("Status.TLabel", background="#0b1220", foreground="#94a3b8")
        style.configure("Warn.TLabel", background="#0b1220", foreground="#fbbf24", font=("Microsoft YaHei UI", 9))
        style.configure("TButton", padding=(11, 7), background="#1d4ed8", foreground="#ffffff")
        style.map("TButton", background=[("active", "#2563eb"), ("disabled", "#334155")])
        style.configure("TCombobox", padding=5)
        style.configure("Treeview", background="#111c31", fieldbackground="#111c31", foreground="#e2e8f0", rowheight=36, borderwidth=0)
        style.configure("Treeview.Heading", background="#18263f", foreground="#cbd5e1", relief="flat", padding=(6, 8), font=("Microsoft YaHei UI", 9, "bold"))
        style.map("Treeview", background=[("selected", "#1d4ed8")], foreground=[("selected", "#ffffff")])
        style.configure("Horizontal.TProgressbar", background="#22c55e", troughcolor="#18263f")

        outer = self.ttk.Frame(self.root, style="Root.TFrame", padding=(24, 20, 24, 16))
        outer.pack(fill="both", expand=True)
        header = self.ttk.Frame(outer, style="Root.TFrame")
        header.pack(fill="x")
        titles = self.ttk.Frame(header, style="Root.TFrame")
        titles.pack(side="left", fill="x", expand=True)
        self.ttk.Label(titles, text="长期分散化推荐组合 Top 10 · 本地 AI", style="Title.TLabel").pack(anchor="w")
        self.ttk.Label(
            titles,
            text="支付宝状态可确认/未知分层展示 · 长周期特征 · purged walk-forward",
            style="Sub.TLabel",
        ).pack(anchor="w", pady=(5, 0))

        controls = self.ttk.Frame(header, style="Root.TFrame")
        controls.pack(side="right", anchor="e")
        self.ttk.Label(controls, text="风险偏好", style="Sub.TLabel").grid(row=0, column=0, padx=(0, 7))
        profile_box = self.ttk.Combobox(controls, textvariable=self.profile, values=("稳健", "均衡", "进取"), state="readonly", width=7)
        profile_box.grid(row=0, column=1, padx=(0, 8))
        profile_box.bind("<<ComboboxSelected>>", lambda _event: self._rerank())
        self.ttk.Label(controls, text="预计持有", style="Sub.TLabel").grid(row=0, column=2, padx=(5, 7))
        holding_box = self.ttk.Combobox(controls, textvariable=self.holding_years, values=(3, 5, 10), state="readonly", width=4)
        holding_box.grid(row=0, column=3, padx=(0, 8))
        holding_box.bind("<<ComboboxSelected>>", lambda _event: self._rerank())
        self.ttk.Label(controls, text="年", style="Sub.TLabel").grid(row=0, column=4, padx=(0, 5))
        self.ttk.Button(controls, text="立即刷新", command=self._start_refresh).grid(row=0, column=5, padx=4)
        self.ttk.Button(controls, text="重建 AI", command=self._confirm_rebuild).grid(row=0, column=6, padx=4)
        self.ttk.Button(controls, text="复制代码", command=self._copy_selected).grid(row=0, column=7, padx=4)
        self.ttk.Button(controls, text="方法与风险", command=self._show_method).grid(row=0, column=8, padx=(4, 0))

        badges = self.ttk.Frame(outer, style="Root.TFrame")
        badges.pack(fill="x", pady=(18, 12))
        self.ttk.Label(badges, textvariable=self.data_info, style="Badge.TLabel").pack(side="left", padx=(0, 8))
        self.ttk.Label(badges, textvariable=self.model_info, style="Badge.TLabel").pack(side="left", padx=8)
        self.ttk.Label(badges, textvariable=self.clock, style="Badge.TLabel").pack(side="right")

        table_card = self.ttk.Frame(outer, style="Card.TFrame", padding=1)
        table_card.pack(fill="both", expand=True)
        columns = ("rank", "rawrank", "code", "name", "type", "alipay", "score", "consistency", "risk", "nav", "day", "ann", "ann5", "cost5y", "dd", "sharpe", "reason", "date")
        self.tree = self.ttk.Treeview(table_card, columns=columns, show="headings", selectmode="browse")
        headings = {
            "rank": "组合#", "rawrank": "AI原始#", "code": "基金代码", "name": "基金名称", "type": "类型", "alipay": "支付宝状态",
            "score": "相对评分", "consistency": "证据强度", "risk": "模型波动风险", "nav": "最新净值", "day": "披露日涨跌", "ann": "近3年年化", "ann5": "近5年年化",
            "cost5y": "预计持有总成本", "dd": "近5年最大回撤", "sharpe": "夏普", "reason": "入选理由", "date": "净值日期",
        }
        widths = {"rank": 54, "rawrank": 62, "code": 76, "name": 178, "type": 88, "alipay": 116, "score": 72, "consistency": 78, "risk": 86, "nav": 76, "day": 82, "ann": 82, "ann5": 82, "cost5y": 112, "dd": 96, "sharpe": 60, "reason": 190, "date": 88}
        for column in columns:
            self.tree.heading(column, text=headings[column])
            self.tree.column(column, width=widths[column], minwidth=widths[column], anchor="center" if column not in ("name", "reason") else "w", stretch=column in ("name", "reason"))
        scrollbar = self.ttk.Scrollbar(table_card, orient="vertical", command=self.tree.yview)
        hscrollbar = self.ttk.Scrollbar(table_card, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=scrollbar.set, xscrollcommand=hscrollbar.set)
        table_card.rowconfigure(0, weight=1); table_card.columnconfigure(0, weight=1)
        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        hscrollbar.grid(row=1, column=0, sticky="ew")
        self.tree.tag_configure("positive", foreground="#fb7185")
        self.tree.tag_configure("negative", foreground="#4ade80")
        self.tree.tag_configure("neutral", foreground="#e2e8f0")
        self.tree.bind("<Double-1>", lambda _event: self._copy_selected())

        footer = self.ttk.Frame(outer, style="Root.TFrame")
        footer.pack(fill="x", pady=(12, 0))
        self.progress = self.ttk.Progressbar(footer, mode="determinate", maximum=100, value=0, length=230)
        self.progress.pack(side="left", padx=(0, 10))
        self.ttk.Label(footer, textvariable=self.status, style="Status.TLabel").pack(side="left", fill="x", expand=True)
        self.ttk.Label(
            outer,
            text="支付宝可购状态无法确认时仍会给出公开基金数据的长期候选，但会明确标为“未知（未排除）”；下单前请在支付宝确认可购、费率、限购与适当性。",
            style="Warn.TLabel",
        ).pack(fill="x", pady=(9, 0))

    def _start_initial(self):
        self.busy = True

        def worker():
            try:
                cached = self.engine.load_cached()
                if cached:
                    self.events.put(("results", self.engine.rankings(self.profile.get(), holding_years=self.holding_years.get()), "已载入本地缓存"))
                if not cached or self.engine.cache_age_hours() >= 14:
                    self.engine.rebuild(lambda text, pct: self.events.put(("progress", text, pct)), force=False)
                    self.events.put(("results", self.engine.rankings(self.profile.get(), holding_years=self.holding_years.get()), "候选池长期分析完成"))
                self.events.put(("done",))
            except Exception as exc:
                self.events.put(("error", str(exc)))
                self.events.put(("done",))

        threading.Thread(target=worker, name="initial-analysis", daemon=True).start()

    def _confirm_rebuild(self):
        if self.busy:
            self.status.set("当前任务尚未完成")
            return
        if not self.messagebox.askyesno("重建本地 AI", "将重新下载候选基金历史净值并训练，可能需要几十秒。继续吗？"):
            return
        self.busy = True
        self.progress["value"] = 0

        def worker():
            try:
                self.engine.rebuild(lambda text, pct: self.events.put(("progress", text, pct)), force=True)
                self.events.put(("results", self.engine.rankings(self.profile.get(), holding_years=self.holding_years.get()), "AI 重建完成"))
            except Exception as exc:
                self.events.put(("error", str(exc)))
            finally:
                self.events.put(("done",))

        threading.Thread(target=worker, name="rebuild-analysis", daemon=True).start()

    def _start_refresh(self):
        if self.refreshing or self.busy or not self.current:
            return
        self.refreshing = True
        self.status.set("同步当前可购池 + 检查全候选池最新净值覆盖率…")

        def worker():
            started = time.monotonic()
            try:
                outcome = self.engine.refresh_latest(self.profile.get(), self.holding_years.get())
                self.events.put(("refresh_results", outcome))
            except Exception as exc:
                self.events.put(("refresh_error", str(exc), time.monotonic() - started))
            finally:
                self.events.put(("refresh_done",))

        threading.Thread(target=worker, name="latest-refresh", daemon=True).start()

    def _rerank(self):
        results = self.engine.rankings(self.profile.get(), holding_years=self.holding_years.get())
        if results:
            self._render(results)
            self.status.set(f"已切换为“{self.profile.get()}”权重 / 预计持有 {self.holding_years.get()} 年")

    def _render(self, results):
        self.current = results
        selected_code = None
        selected = self.tree.selection()
        if selected:
            values = self.tree.item(selected[0], "values")
            selected_code = values[2] if values else None
        for child in self.tree.get_children():
            self.tree.delete(child)
        latest_dates = []
        selected_id = None
        for rank, item in enumerate(results, 1):
            stats = item["stats"]
            day = item.get("day_change")
            day_text = "—" if day is None or not math.isfinite(_finite(day, float("nan"))) else f"{day:+.2f}%"
            tag = "positive" if _finite(day) > 0 else "negative" if _finite(day) < 0 else "neutral"
            nav = item.get("display_nav", item.get("latest_nav"))
            nav_text = "—" if nav is None or not math.isfinite(_finite(nav, float("nan"))) else f"{nav:.4f}"
            date = item.get("display_nav_date") or item.get("latest_date") or (item.get("dates") or [""])[-1]
            if date:
                latest_dates.append(date)
            status_key = str(item.get("availability_status") or "unknown")
            source_text = "已确认可购" if status_key == "confirmed_purchasable" else "未知（未排除）"
            row_id = self.tree.insert("", "end", values=(
                rank, item.get("ai_raw_rank", "—"), item["code"], item["name"], item["type"], source_text, f"{item['score']:.1f}",
                f"{_finite(item.get('model_consistency')):.0f}/100", item["risk"], nav_text, day_text, f"{stats['return_3y_ann']:+.1%}",
                (f"{stats['return_5y_ann']:+.1%}" if stats.get("long_evidence_strength",0) >= 0.28 else "证据不足"),
                f"{_share_class_cost(item, item.get('selected_holding_years', 5)):.1%}" if item.get("fees_verified") else "交易费率未知",
                f"{stats['max_drawdown_5y']:.1%}", f"{stats['sharpe']:.2f}", item["reason"], date or "—",
            ), tags=(tag,))
            if item["code"] == selected_code:
                selected_id = row_id
        if selected_id:
            self.tree.selection_set(selected_id)
        source_ids = sorted({str(item.get("availability_source_id") or "unknown") for item in results})
        declared = [str(item.get("availability_declared_at") or "") for item in results if item.get("availability_declared_at")]
        declared_text = min(declared)[:19].replace("T"," ") if declared else "—"
        confirmed = sum(str(item.get("availability_status") or "") == "confirmed_purchasable" for item in results)
        source_badge = (f"支付宝已确认 {confirmed}/10" if confirmed else "支付宝状态未知 10/10") + " · 来源：" + ",".join(source_ids[:2])
        cross = getattr(self.engine, "last_cross_check", {}) or {}
        cross_text = f"新浪复核 {int(cross.get('verified',0))}/{int(cross.get('requested',0))}" if cross.get("requested") else "新浪复核 —"
        self.data_info.set(f"基金/净值主源：东方财富 · {max(latest_dates) if latest_dates else '—'} · 支付宝声明：{declared_text} · {source_badge} · {cross_text}")
        model = self.engine.store.model; full = model.get("full_pipeline_oos") or {}; trained = (model.get("trained_at") or "—")[:10]
        coverage = _clamp(_finite(model.get("historical_availability_coverage")), 0.0, 1.0); mode = "AI启用" if model.get("ai_enabled") else "专家基线"
        bias = " · 存在存续偏差（已保留本机观察到的退出基金）" if model.get("survivorship_bias", True) else ""
        cutoff = ((model.get("split_boundaries") or {}).get("test_feature_start") or "—")[:10]
        self.model_info.set(f"{mode}：{model.get('universe_size',0)}底层基金 · untouched OOS RankIC {_finite(full.get('rank_ic_mean')):+.2f} · 胜基准 {_finite(full.get('top10_benchmark_win_rate')):.0%} · 测试起点 {cutoff} · 支付宝历史覆盖{coverage:.0%}(仅诊断) · 训练 {trained}{bias}")

    def _copy_selected(self):
        selected = self.tree.selection()
        if not selected:
            self.status.set("请先选择一只基金")
            return
        values = self.tree.item(selected[0], "values")
        if not values:
            return
        code = str(values[2])
        self.root.clipboard_clear()
        self.root.clipboard_append(code)
        self.root.update_idletasks()
        self.status.set(f"已复制 {code}；请在实际交易平台确认该份额当前可购与最新交易条件")

    def _show_method(self):
        window = self.tk.Toplevel(self.root)
        window.title("方法、数据与风险说明")
        window.geometry("780x620")
        window.configure(bg="#0b1220")
        text = self.tk.Text(
            window, wrap="word", bg="#111c31", fg="#e2e8f0", insertbackground="#ffffff",
            relief="flat", padx=22, pady=18, font=("Microsoft YaHei UI", 10), spacing2=4, spacing3=8,
        )
        text.insert("1.0", METHOD_TEXT)
        text.configure(state="disabled")
        text.pack(fill="both", expand=True, padx=16, pady=16)

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "progress":
                    self.status.set(event[1])
                    self.progress["value"] = event[2]
                elif kind == "results":
                    self._render(event[1])
                    self.status.set(event[2])
                    self.progress["value"] = 100
                    if not getattr(self, "schedule_started", False):
                        delay = self.refresh_policy.initial_delay(event[1])
                        self.next_refresh = time.monotonic() + delay
                        self.schedule_started = True
                elif kind == "refresh_results":
                    outcome = event[1]
                    self._render(outcome["results"])
                    delay = self.refresh_policy.on_success(outcome)
                    self.next_refresh = time.monotonic() + delay
                    self.status.set(outcome["status"] + f"；{self.refresh_policy.last_reason}")
                    self.progress["value"] = 100
                elif kind == "error":
                    self.status.set(f"更新失败：{event[1]}")
                    if not self.current:
                        self.messagebox.showerror("无法完成基金分析", event[1] + "\n\n请确认可信支付宝可购源与公开净值数据源均可访问后重试。")
                elif kind == "refresh_error":
                    delay = self.refresh_policy.on_error(event[2] if len(event) > 2 else 0.0)
                    self.next_refresh = time.monotonic() + delay
                    self.status.set(f"本轮刷新失败，保留上次数据：{event[1]}；{self.refresh_policy.last_reason}")
                elif kind == "done":
                    self.busy = False
                elif kind == "refresh_done":
                    self.refreshing = False
        except queue.Empty:
            pass
        if not self.stop_event.is_set():
            self.root.after(150, self._poll_events)

    def _tick(self):
        now = time.monotonic()
        if math.isfinite(self.next_refresh):
            remaining = max(0.0, self.next_refresh - now)
            self.clock.set(f"智能刷新：{self.refresh_policy.last_reason} · {_human_seconds(remaining)}后")
            if remaining <= 0 and not self.refreshing and not self.busy:
                self.next_refresh = float("inf")
                self._start_refresh()
        else:
            self.clock.set("智能刷新：正在刷新…" if self.refreshing else "智能刷新：等待分析完成")
        if not self.stop_event.is_set():
            self.root.after(1000, self._tick)

    def close(self):
        self.stop_event.set()
        self.root.destroy()


def _run_console():
    engine = AnalysisEngine()
    if not engine.load_cached() or engine.cache_age_hours() >= 14:
        engine.rebuild(lambda text, pct: print(f"[{pct:5.1f}%] {text}"), force=False)
    profile = "均衡"
    holding_years = _expected_holding_years()
    policy = SmartRefreshPolicy()
    results = engine.rankings(profile, holding_years=holding_years)
    delay = policy.initial_delay(results)
    refresh_note = "已载入结果"
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        print(f"{APP_NAME} {VERSION} · 均衡 · 预计持有{holding_years}年 · {time.strftime('%Y-%m-%d %H:%M:%S')}")
        source_ids = sorted({str(item.get("availability_source_id") or "unknown") for item in results})
        declared = min((str(item.get("availability_declared_at") or "") for item in results if item.get("availability_declared_at")), default="—")
        confirmed = sum(str(item.get("availability_status") or "") == "confirmed_purchasable" for item in results)
        alipay_text = f"已确认可购 {confirmed}/10" if confirmed else "10/10 状态未知（未排除）"
        cross = getattr(engine, "last_cross_check", {}) or {}
        print(f"数据来源：基金/净值=东方财富 · 支付宝={alipay_text}（{','.join(source_ids[:2])}） · Top10复核=新浪 {int(cross.get('verified',0))}/{int(cross.get('requested',0))} · 声明时间 {declared[:19].replace('T',' ')}。")
        print(f"刷新状态：{refresh_note}")
        print(f"调度策略：{policy.last_reason} · {_human_seconds(delay)}后刷新\n")
        for rank, item in enumerate(results, 1):
            stats = item["stats"]
            ann5_text = f"{stats['return_5y_ann']:+6.1%}" if stats.get("long_evidence_strength", 0) >= 0.28 else "证据不足"
            print(
                f"组合{rank:2d}/原始{int(item.get('ai_raw_rank') or 0):3d}  {item['code']}  {item['name'][:22]:22s}  "
                f"支付宝{'已确认' if item.get('availability_status') == 'confirmed_purchasable' else '未知':4s}  相对评分 {item['score']:4.1f}  证据强度 {_finite(item.get('model_consistency')):3.0f}/100  "
                f"3年 {stats['return_3y_ann']:+6.1%} / 5年 {ann5_text}  "
                f"预计持有总成本 {_share_class_cost(item,holding_years):5.1%}  5年最大回撤 {stats['max_drawdown_5y']:6.1%}  {item['reason']}"
            )
        print("\n按 Ctrl+C 退出。")
        deadline = time.monotonic() + delay
        while time.monotonic() < deadline:
            time.sleep(min(0.5, deadline - time.monotonic()))
        started = time.monotonic()
        try:
            outcome = engine.refresh_latest(profile, holding_years)
            results = outcome["results"]
            refresh_note = outcome["status"]
            delay = policy.on_success(outcome)
        except DataError as exc:
            results = engine.rankings(profile, holding_years=holding_years)
            if len(results) != 10:
                raise
            refresh_note = f"本轮刷新失败，保留上次结果：{exc}"
            delay = policy.on_error(time.monotonic() - started)


def _synthetic_funds(count=40, points=2400):
    rng = random.Random(20260815)
    funds = []
    types = ("混合型-偏股", "股票型", "债券型", "指数型")
    declared_at = _now_iso()
    for index in range(count):
        quality = (index - count/2) / 80000.0
        returns = [0.0]
        nav = 1.0
        dates = []
        day = _dt.date(2012, 1, 2)
        for day_index in range(points):
            while day.weekday() >= 5:
                day += _dt.timedelta(days=1)
            dates.append(day.isoformat())
            day += _dt.timedelta(days=1)
            if day_index:
                daily = 0.00020 + quality + rng.gauss(0, 0.007 + (index % 4) * 0.0015)
                daily = _clamp(daily, -0.15, 0.15)
                returns.append(daily)
                nav *= 1 + daily
        fees = {
            "purchase_fee": 0.0005 + (index % 3) * 0.0002,
            "management_fee_annual": 0.006 + (index % 5) * 0.001,
            "custody_fee_annual": 0.001,
            "sales_service_fee_annual": 0.0 if index % 2 == 0 else 0.003,
            "redemption_fee_3y": 0.0, "redemption_fee_5y": 0.0, "redemption_fee_10y": 0.0,
        }
        costs = _holding_costs(fees)
        funds.append({
            "code": f"{index:06d}", "name": f"测试基金{index}A", "type": types[index % 4],
            "dates": dates, "returns": returns, "latest_nav": nav, "latest_date": dates[-1],
            "availability_declared": True, "availability_status": "confirmed_purchasable", "availability_declared_at": declared_at, "availability_evidence": "self-test",
            "fees_verified": True, "fees": fees, **costs,
            "available_from": "2020-01-01", "available_to": "",
            "availability_history": [{"from":"2020-01-01","to":"2099-12-31","purchasable":True}],
        })
    return funds



def _validate_runtime(*, formal=False) -> list[tuple[str,str]]:
    checks = []
    if sys.version_info < MIN_PYTHON:
        raise DataError(f"需要 Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} 或更高版本")
    checks.append(("OK", f"Python >= {MIN_PYTHON[0]}.{MIN_PYTHON[1]}"))
    if struct.calcsize("P") * 8 != 64:
        raise DataError("需要 64 位 Python")
    checks.append(("OK", "64-bit Python"))
    if os.name == "nt":
        version = sys.getwindowsversion()
        if version.major < 10 or version.build < 22000:
            raise DataError("正式环境要求 Windows 11 x64")
        checks.append(("OK", "Windows 11 x64（正式环境）"))
    else:
        if formal:
            raise DataError("正式环境要求 Windows 11 x64")
        checks.append(("SKIP", f"Windows 11 x64（当前测试环境为 {platform.system()}）"))
    if MODEL_PATH.parent != BASE_DIR or CACHE_PATH.parent != BASE_DIR or ALIPAY_FILE_PATH.parent != BASE_DIR:
        raise DataError("AI/缓存/可购状态快照路径必须与脚本同目录")
    checks.append(("OK", "MODEL_PATH/CACHE_PATH/可购快照路径 == 脚本目录"))
    probe = BASE_DIR / ".BestAlipayFunds_write_test.tmp"
    try:
        _atomic_bytes(probe, b"ok")
        if probe.read_bytes() != b"ok":
            raise OSError("write verification failed")
    except OSError as exc:
        raise DataError(f"脚本目录不可写：{BASE_DIR}\n{exc}") from exc
    finally:
        try:
            probe.unlink(missing_ok=True)
        except OSError:
            pass
    checks.append(("OK", "脚本目录可写 + 原子写入"))
    return checks


def _self_test_impl(full=False):
    checks = _validate_runtime(formal=False)
    funds = _synthetic_funds(72, 3600) if full else _synthetic_funds(40, 3200)
    ranker = AdaptiveRanker()
    model = ranker.train(funds)
    scored = ranker.score(funds, model, "均衡", {})
    assert len(model["linear_weights"]) == len(AdaptiveRanker.FEATURE_NAMES)
    assert len(scored) == len(funds)
    assert scored[0]["score"] >= scored[-1]["score"]
    assert model.get("nonlinear_models") and model.get("tuning_samples", 0) > 0 and model.get("validation_samples", 0) > 0
    assert model.get("deployment_validation_samples", 0) > 0
    assert "126d" in model.get("target", "") and "252d" in model.get("target", "")
    boundaries = model.get("split_boundaries") or {}
    assert boundaries.get("train_target_end_max") <= boundaries.get("tune_feature_start")
    assert boundaries.get("tune_target_end_max") <= boundaries.get("deployment_feature_start")
    assert boundaries.get("deployment_target_end_max") <= boundaries.get("test_feature_start")
    assert boundaries.get("oos_windows_non_overlapping") is True
    assert model.get("selection_dataset") == "deployment-validation-only; untouched-test-report-only"
    untouched = model.get("untouched_test_oos") or {}
    assert untouched.get("windows", 0) >= MIN_OOS_GATE_WINDOWS and untouched.get("windows_non_overlapping") is True
    assert untouched.get("portfolio_assumption") == "initial-equal-weight-buy-and-hold"
    assert not untouched.get("constraint_failures")
    assert model.get("validation_ic", 0) > 0 and model.get("model_quality", 0) > 0
    checks.append(("OK", "统一横截面 + train/tune/deployment/untouched 四段 purge；测试集只报告且非重叠"))

    snapshots, snapshot_info = ranker._build_snapshots(funds)
    assert snapshots and snapshot_info.get("duplicate_shares_removed") == 0
    assert all(snap.get("cross_section_synchronized") is True for snap in snapshots)
    assert all(
        all(observed <= snap["feature_date"] for observed in snap.get("feature_observation_dates") or [])
        for snap in snapshots
    )
    assert all(len(keys) == len(set(keys)) for keys in (snap.get("underlying_keys") or [] for snap in snapshots))
    checks.append(("OK", "所有基金按同一季度 T 做 bisect_right；特征只读 <=T 且横截面无重复底层份额"))

    # Calendar-window regression: 10 calendar years must work with fewer than 2520 observations.
    sparse_dates = [(_dt.date(2010, 1, 1) + _dt.timedelta(days=2*i)).isoformat() for i in range(2200)]
    sparse_returns = [0.0] + [0.0002] * (len(sparse_dates) - 1)
    sparse_features = ranker.features(sparse_returns, dates=sparse_dates)
    assert sparse_features and len(sparse_returns) < 2520 and sparse_features[1]["history_years"] > 10
    assert sparse_features[1]["return_10y_ann"] > 0
    checks.append(("OK", "5/7/10年特征按日历跨度与实际 CAGR；不足2520条记录仍可形成10年特征"))

    # A predictable cross-sectional signal must win in multiple synthetic regimes.
    regime_snaps = []
    for regime in ("trend", "risk_off", "range"):
        values = [2*i/11-1 for i in range(12)]
        regime_snaps.append({
            "rows": [[value] + [0.0] * (len(AdaptiveRanker.FEATURE_NAMES)-1) for value in values],
            "targets": values, "drawdowns": [0.1] * 12,
            "codes": [f"{regime}-{i}" for i in range(12)], "regime": regime,
        })
    smart = ranker._validation_metrics(regime_snaps, lambda row: row[0])
    inverted = ranker._validation_metrics(regime_snaps, lambda row: -row[0])
    assert smart["rank_ic"] > 0.99 and smart["model_quality"] > inverted["model_quality"]
    checks.append(("OK", "模型质量回归：趋势/风险关闭/震荡 regime 中有效信号优于反向基线"))
    raw_regime_row = [0.15, 0.0, 0.0, 0.0, 0.0, 0.0, -0.10, -0.10, 0.0, 0.6, 0.12, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    assert AdaptiveRanker._regime_from_rows([raw_regime_row] * 5) == "trend"
    checks.append(("OK", "历史 regime 使用 rank-scale 前的真实收益/波动量纲"))

    biased_source = _synthetic_funds(30, 3200) if full else funds[:30]
    biased = [dict(fund) for fund in biased_source]
    for fund in biased:
        fund["availability_history"] = []
        fund["available_from"] = ""
    biased_model = ranker.train(biased)
    assert biased_model.get("historical_availability_coverage") == 0.0
    assert biased_model.get("historical_availability_used_for_model_selection") is False
    assert "historical-availability" not in biased_model.get("model_status", "")
    assert biased_model.get("training_samples", 0) > 0
    checks.append(("OK", "支付宝历史可购覆盖仅作诊断；全市场训练与 ML 安全门不再依赖它"))

    # Point-in-time structured data must never fall back to current fields.
    pit_probe = {
        "product_features": {"manager_tenure_years": 99.0, "benchmark_alpha_3y": 9.9},
        "fees": {"purchase_fee": 0.99}, "fees_verified": True,
        "product_features_history": [
            {"feature_date":"2022-01-01","product_features":{"manager_tenure_years":1.5}},
            {"feature_date":"2024-01-01","product_features":{"manager_tenure_years":3.5}},
        ],
        "fees_history": [
            {"feature_date":"2022-01-01","fees":{"purchase_fee":0.001}},
            {"feature_date":"2024-01-01","fees":{"purchase_fee":0.0005}},
        ],
    }
    pf, ff, fv = ranker._pit_fields(pit_probe, "2023-06-01")
    assert pf.get("manager_tenure_years") == 1.5 and abs(ff.get("purchase_fee")-0.001) < 1e-12 and fv
    pf0, ff0, fv0 = ranker._pit_fields({"product_features":pit_probe["product_features"],"fees":pit_probe["fees"]}, "2023-06-01")
    assert pf0 == {} and ff0 == {} and fv0 is False
    checks.append(("OK", "OOS/训练结构化字段严格 point-in-time；无历史快照不回填今天的产品特征/费率"))

    # Availability trust-chain regression: unsigned input must fail; private HMAC is allowed only
    # for an explicitly configured private URL; stale signed cache is history-only; sequence cannot roll back.
    ALIPAY_FILE_PATH.unlink(missing_ok=True)
    old_url = os.environ.pop("BEST_ALIPAY_AVAILABILITY_URL", None)
    old_hosts = os.environ.pop("BEST_ALIPAY_AVAILABILITY_HOSTS", None)
    old_hmac = os.environ.pop("BEST_ALIPAY_AVAILABILITY_HMAC_KEY", None)
    original_http_json = globals()["_http_json"]
    try:
        try:
            AlipayAvailabilitySource().snapshot()
            raise AssertionError("missing trusted availability must fail closed")
        except DataError as exc:
            assert "拒绝生成" in str(exc)

        now = _dt.datetime.now().astimezone()
        stamp = now.isoformat(timespec="seconds")
        expires = (now + _dt.timedelta(minutes=20)).isoformat(timespec="seconds")
        good_payload = {
            "schema": AlipayAvailabilitySource.SCHEMA, "schema_version": AVAILABILITY_SCHEMA_VERSION,
            "declared": True, "generated_at": stamp, "expires_at": expires, "sequence": 7,
            "source_id": "private:self-test", "source": "self-test", "evidence": "self-test-trusted",
            "signature_alg": "hmac-sha256",
            "funds": [
                {"code": f"{100000+i:06d}", "name": f"可信测试指数基金{i}A", "type": "指数型",
                 "declared": True, "purchasable": True, "declared_at": stamp, "fees_verified": False, "fees": {}}
                for i in range(30)
            ],
        }
        os.environ["BEST_ALIPAY_AVAILABILITY_URL"] = "https://trusted.example.test/availability.json"
        os.environ["BEST_ALIPAY_AVAILABILITY_HOSTS"] = "trusted.example.test"
        os.environ["BEST_ALIPAY_AVAILABILITY_HMAC_KEY"] = "self-test-secret"
        good_payload["signature"] = hmac.new(
            b"self-test-secret", AlipayAvailabilitySource._canonical_signature_bytes(good_payload), hashlib.sha256
        ).hexdigest()
        _write_json(ALIPAY_FILE_PATH, good_payload)
        before = ALIPAY_FILE_PATH.read_bytes()
        globals()["_http_json"] = lambda *_args, **_kwargs: {"schema": AlipayAvailabilitySource.SCHEMA}
        declared = AlipayAvailabilitySource().snapshot()
        assert len(declared) == 30 and all(row.get("availability_source_id") == "private:self-test" for row in declared.values())
        assert ALIPAY_FILE_PATH.read_bytes() == before

        unsigned = dict(good_payload); unsigned.pop("signature", None)
        _write_json(ALIPAY_FILE_PATH, unsigned)
        try:
            AlipayAvailabilitySource().snapshot()
            raise AssertionError("unsigned availability must fail")
        except DataError as exc:
            assert "签名" in str(exc)
        _write_json(ALIPAY_FILE_PATH, good_payload)

        # HMAC is never accepted for a public release source, even with the key present.
        try:
            AlipayAvailabilitySource()._validate_payload(good_payload, require_fresh=True, public_source=True)
            raise AssertionError("public source must not accept HMAC")
        except DataError as exc:
            assert "RSA-SHA256" in str(exc)

        lower = dict(good_payload); lower["sequence"] = 6; lower.pop("signature", None)
        lower["signature"] = hmac.new(
            b"self-test-secret", AlipayAvailabilitySource._canonical_signature_bytes(lower), hashlib.sha256
        ).hexdigest()
        try:
            AlipayAvailabilitySource._rollback_guard(lower, good_payload)
            raise AssertionError("sequence rollback must fail")
        except DataError as exc:
            assert "回滚" in str(exc)

        stale = dict(good_payload)
        stale["generated_at"] = (now - _dt.timedelta(hours=2)).isoformat(timespec="seconds")
        stale["expires_at"] = (now - _dt.timedelta(hours=1)).isoformat(timespec="seconds")
        stale["sequence"] = 8; stale.pop("signature", None)
        stale["signature"] = hmac.new(
            b"self-test-secret", AlipayAvailabilitySource._canonical_signature_bytes(stale), hashlib.sha256
        ).hexdigest()
        _write_json(ALIPAY_FILE_PATH, stale)
        try:
            AlipayAvailabilitySource().snapshot()
            raise AssertionError("expired signed cache must not be current")
        except DataError as exc:
            assert "历史缓存" in str(exc) and "不代表当前支付宝可购" in str(exc)
    finally:
        globals()["_http_json"] = original_http_json
        if old_url is None: os.environ.pop("BEST_ALIPAY_AVAILABILITY_URL", None)
        else: os.environ["BEST_ALIPAY_AVAILABILITY_URL"] = old_url
        if old_hosts is None: os.environ.pop("BEST_ALIPAY_AVAILABILITY_HOSTS", None)
        else: os.environ["BEST_ALIPAY_AVAILABILITY_HOSTS"] = old_hosts
        if old_hmac is None: os.environ.pop("BEST_ALIPAY_AVAILABILITY_HMAC_KEY", None)
        else: os.environ["BEST_ALIPAY_AVAILABILITY_HMAC_KEY"] = old_hmac
    checks.append(("OK", "未签名必拒绝 + 公共源强制RSA + 私有HMAC + sequence防回滚 + 过期缓存仅历史参考"))
    assert hasattr(FundDataSource(), "cross_verify_top10") and not hasattr(LocalStore(), "cross_verify_top10")
    checks.append(("OK", "新浪 Top10 交叉核验属于 FundDataSource，排名阶段可直接调用"))

    class CatalogueOnlySource(FundDataSource):
        def all_funds(self):
            return [{"code": f"{100000+i:06d}", "name": f"长期测试基金{i}A", "type": ("指数型" if i%3==0 else "债券型" if i%3==1 else "混合型-偏股")} for i in range(80)]
    fallback_map = CatalogueOnlySource().public_fallback_universe(limit=40)
    assert len(fallback_map) == 80 and len(CatalogueOnlySource.structural_prefilter(fallback_map, limit=25)) == 80
    assert all(row.get("availability_status") == "unknown" and row.get("availability_declared") is False for row in fallback_map.values())
    unknown_funds = [dict(f) for f in funds[:20]]
    for f in unknown_funds:
        f["availability_declared"] = False; f["availability_status"] = "unknown"; f["availability_declared_at"] = ""
    assert len(ranker.score(unknown_funds, model, "均衡", {})) == 20
    checks.append(("OK", "公开模式保留完整结构合格全集；limit 参数不再按代码任意截断"))

    metadata_html = """
    <table><tr><th>成立日期/规模</th><td>2014年03月18日 / 10亿元</td></tr>
    <tr><th>基金管理人</th><td><a>测试基金管理有限公司</a></td></tr>
    <tr><th>业绩比较基准</th><td>中证人工智能指数收益率*95%</td></tr>
    <tr><th>跟踪标的</th><td>中证人工智能指数</td></tr></table>
    <h4>投资目标</h4><p>紧密跟踪人工智能主题指数。</p><h4>投资范围</h4>
    """
    metadata = FundDataSource._parse_basic_metadata(metadata_html)
    assert metadata["fund_company"] == "测试基金管理有限公司"
    assert metadata["index_code"] == "中证人工智能指数" and metadata["theme"] == "科技半导体"
    assert metadata["inception_date"] == "2014-03-18"
    fee_html = """
    <div>管理费率 0.80% 托管费率 0.10% 销售服务费率 0.40%</div>
    <h3>申购费率</h3><table><tr><td>小于100万元</td><td>0.00%</td></tr></table>
    <h3>赎回费率</h3><table><tr><td>小于7天</td><td>1.50%</td></tr>
    <tr><td>730天以上</td><td>0.00%</td></tr></table>
    """
    parsed_fees = FundDataSource._parse_fee_schedule(fee_html)
    assert parsed_fees["fees_verified"] is True and parsed_fees["fees"]["sales_service_fee_annual"] == 0.004
    assert parsed_fees["holding_cost_10y"] == 0.0
    checks.append(("OK", "普通公开档案/费率表补齐公司、指数、主题、成立日及3/5/10年份额成本"))

    class DummyStore:
        def __init__(self, source_funds, model_value):
            self.model = model_value
            self.cache = {
                "version": CACHE_VERSION, "updated_at": _now_iso(),
                "funds": {f["code"]: AnalysisEngine._cache_item(f) for f in source_funds},
            }
        def save_cache(self):
            return None
        def save_model(self, value):
            self.model = value

    class FullMarketSource:
        def __init__(self, source_funds):
            self.source_funds = {fund["code"]:fund for fund in source_funds}
        def all_funds(self):
            return [{"code":fund["code"],"name":fund["name"],"type":fund["type"]} for fund in self.source_funds.values()]
        def history(self, code):
            fund = self.source_funds[code]
            return {"dates":list(fund["dates"]),"returns":list(fund["returns"]),"latest_nav":fund["latest_nav"],"latest_date":_dt.date.today().isoformat()}

    class TodayFilter:
        def __init__(self, source_funds):
            self.source_funds = source_funds
        def snapshot(self):
            return {
                fund["code"]:{"code":fund["code"],"name":fund["name"],"type":fund["type"],"availability_declared":True,"availability_status":"confirmed_purchasable","availability_declared_at":_now_iso()}
                for fund in self.source_funds
            }

    class CapturingRanker(AdaptiveRanker):
        def __init__(self):
            self.seen = 0
        def train(self, values):
            self.seen = len(values)
            value = LocalStore.default_model(); value.update({"trained_at":_now_iso(),"universe_codes":[row["code"] for row in values],"universe_size":len(values)})
            return value

    market_probe_funds = [dict(fund) for fund in funds[:30]]
    market_store = DummyStore([], LocalStore.default_model())
    market_engine = AnalysisEngine(
        source=FullMarketSource(market_probe_funds),
        availability=TodayFilter(market_probe_funds[:10]), store=market_store,
    )
    capture_ranker = CapturingRanker(); market_engine.ranker = capture_ranker
    market_engine.rebuild(force=False)
    assert capture_ranker.seen == 30 and len(market_engine.market_funds) == 30 and len(market_engine.funds) == 10
    checks.append(("OK", "模型训练读取完整公开市场；今天的支付宝清单仅过滤最终推荐池"))

    store = DummyStore(funds, model)
    engine = object.__new__(AnalysisEngine)
    engine.ranker = ranker
    engine.funds = [dict(fund) for fund in (funds[:48] if full else funds)]
    engine.feature_cache = {}
    engine.last_refresh_status = {}
    engine.lock = threading.RLock()
    engine.store = store
    top10 = AnalysisEngine.rankings(engine, "均衡")
    assert len(top10) == 10 and all(item.get("availability_declared") is True for item in top10)
    assert all("model_consistency" in item for item in top10)
    assert all("diversification_penalty" in item for item in top10)
    cache_size = len(engine.feature_cache)
    AnalysisEngine.rankings(engine, "均衡")
    assert cache_size == len(engine.feature_cache) >= 10
    assert all("return_5y_ann" in item["stats"] and "long_evidence_strength" in item["stats"] for item in top10)
    checks.append(("OK", "相对评分 + 5/7/10年长期证据 + 特征缓存 + 相关性边际分散化"))

    structured = [dict(item) for item in scored]
    for i,item in enumerate(structured):
        item["fund_company"] = f"公司{i%9}"
        item["theme"] = f"主题{i%7}"
        item["index_code"] = ("DUPLICATE-INDEX" if i < 2 else f"IDX-{i}") if item.get("asset_bucket") == "指数" else ""
    constrained = ranker.select_portfolio(structured, "均衡")
    assert len(constrained) == 10
    for field, cap in (("index_code",1),("theme",2),("fund_company",2)):
        counts={}
        for item in constrained:
            key=str(item.get(field) or "").strip()
            if key: counts[key]=counts.get(key,0)+1
        assert max(counts.values(), default=0) <= cap
    asset_counts={}
    for item in constrained: asset_counts[item.get("asset_bucket")]=asset_counts.get(item.get("asset_bucket"),0)+1
    assert 2 <= asset_counts.get("指数",0) <= 4 and 2 <= asset_counts.get("主动权益",0) <= 4 and 1 <= asset_counts.get("债券",0) <= 3
    impossible_minimum = [item for item in structured if item.get("asset_bucket") != "主动权益"]
    impossible_minimum += [next(item for item in structured if item.get("asset_bucket") == "主动权益")]
    assert ranker.select_portfolio(impossible_minimum, "均衡") == []
    assert "主动权益最低要求2只" in ranker.last_constraint_error
    same_company = [dict(item, fund_company="唯一公司", theme="", index_code="") for item in structured]
    assert ranker.select_portfolio(same_company, "均衡") == []
    assert "要求恰好10只" in ranker.last_constraint_error
    checks.append(("OK", "硬约束保留原始最低值；选后完整复核，资产/指数/主题/公司任一不可满足即空结果并说明"))

    declared_hist={"availability_declared":True,"availability_status":"confirmed_purchasable","availability_generated_at":"2026-08-16T08:00:00+08:00","availability_declared_at":"2026-08-16T08:00:00+08:00","availability_history":[]}
    cached_hist={"availability_history":[{"from":"2026-08-10","to":"","purchasable":True}]}
    merged_hist=AnalysisEngine._merge_observed_availability(declared_hist,cached_hist)
    assert merged_hist[0]["from"] == "2026-08-10" and merged_hist[0]["to"] == ""
    closed_hist=AnalysisEngine._close_observed_availability({"availability_history":merged_hist},"2026-08-16")
    assert closed_hist["availability_history"][0]["to"] == "2026-08-15" and closed_hist["availability_declared"] is False
    relisted=AnalysisEngine._merge_observed_availability({**declared_hist,"availability_generated_at":"2026-08-20T08:00:00+08:00"},closed_hist)
    assert len(relisted) == 2 and relisted[-1]["from"] == "2026-08-20"
    checks.append(("OK", "客户端持续积累签名可购池观测：下架关闭区间、重新出现开启新区间"))

    retired = AnalysisEngine._cache_item(dict(funds[0], code="777777", name="历史清盘测试基金A", termination_date="2022-12-31"))
    retained_pool = AnalysisEngine._retained_training_pool(funds[:5], {"777777":retired})
    retained = next(item for item in retained_pool if item["code"] == "777777")
    assert retained.get("catalog_active") is False and retained.get("termination_date") == "2022-12-31"
    assert model.get("survivorship_bias") is True
    checks.append(("OK", "基金主表保留已退出/终止基金供历史截面使用，并显式标注首次运行前存续偏差"))

    # latest_many must report coverage semantics, including missing codes.
    class BatchSource(FundDataSource):
        def latest(self, codes, *, timeout=LATEST_TIMEOUT, attempts=LATEST_ATTEMPTS):
            return {
                code: {"code": code, "name": code, "nav": 1.0, "day_change": 0.0, "nav_date": "2026-08-15"}
                for code in codes if not code.endswith("7")
            }
    batch_codes = [f"{i:06d}" for i in range(30)]
    report = BatchSource().latest_many(batch_codes)
    assert report["requested"] == 30 and report["received"] < 30 and report["failed_codes"]
    checks.append(("OK", "latest_many 返回 requested/received/failed_codes"))

    try:
        _safe_gzip_decompress(gzip.compress(b"x" * 2048), limit=1024)
        raise AssertionError("gzip expansion limit must fail")
    except DataError as exc:
        assert "解压结果超过" in str(exc)
    redirect_handler = _PinnedRedirectHandler({"trusted.example.test"})
    try:
        redirect_handler.redirect_request(
            urllib.request.Request("https://trusted.example.test/a", headers={"Authorization":"Bearer secret"}),
            None, 302, "Found", {}, "https://evil.example.test/b",
        )
        raise AssertionError("cross-host redirect must fail")
    except urllib.error.HTTPError as exc:
        assert "白名单外" in str(exc)
    holiday_sessions = _expected_market_sessions(_dt.date(2026,2,13), _dt.date(2026,2,24))
    ordinary_sessions = _expected_market_sessions(_dt.date(2026,3,2), _dt.date(2026,3,13))
    assert holiday_sessions < ordinary_sessions
    checks.append(("OK", "响应/解压大小上限 + Authorization重定向白名单 + 中国长假交易日新鲜度"))

    # Dividend regression: a large NAV/day-change disagreement is deferred to corporate-action-aware history.
    test_fund = dict(funds[0]); test_fund["returns"] = list(funds[0]["returns"]); test_fund["dates"] = list(funds[0]["dates"])
    old_len = len(test_fund["returns"])
    old_nav = test_fund["latest_nav"]
    new_date = (_dt.date.fromisoformat(test_fund["latest_date"]) + _dt.timedelta(days=1)).isoformat()
    AnalysisEngine._apply_latest_rows([test_fund], {test_fund["code"]: {
        "nav": old_nav * 0.90, "nav_date": new_date, "day_change": 1.0, "name": test_fund["name"],
    }})
    assert len(test_fund["returns"]) == old_len and test_fund.get("return_pending_adjustment") is True
    checks.append(("OK", "现金分红/折算疑点不会把普通日涨跌字段直接写入总回报序列"))
    missing_day = dict(funds[1]); missing_day["returns"] = list(funds[1]["returns"]); missing_day["dates"] = list(funds[1]["dates"])
    old_len2 = len(missing_day["returns"]); old_nav2 = missing_day["latest_nav"]
    new_date2 = (_dt.date.fromisoformat(missing_day["latest_date"]) + _dt.timedelta(days=1)).isoformat()
    AnalysisEngine._apply_latest_rows([missing_day], {missing_day["code"]: {"nav": old_nav2 * 1.01, "nav_date": new_date2, "day_change": float("nan")}})
    assert len(missing_day["returns"]) == old_len2 and missing_day.get("return_pending_adjustment") is True
    checks.append(("OK", "最新日缺少独立日涨跌证据时不直接追加单位净值机械收益"))

    lggj = FundDataSource._normalize_history([
        {"FSRQ":"2026-08-14","DWJZ":"1.0000","LJJZ":"1.0000","JZZZL":"0","FHFCZ":""},
        {"FSRQ":"2026-08-15","DWJZ":"0.5000","LJJZ":"1.0100","JZZZL":"1.0","FHFCZ":""},
    ])
    assert abs(lggj["returns"][-1]-0.01) < 1e-12 and lggj.get("return_accumulated_confirmations") == 1
    checks.append(("OK", "LJJZ 累计净值作为公司行动第二证据，减少仅依赖 FHFCZ 文本"))

    # Fees embedded in NAV are reported but not double-subtracted from investor costs.
    fee_test = _holding_costs({"management_fee_annual": 0.012, "custody_fee_annual": 0.002, "purchase_fee": 0.001})
    assert abs(fee_test["annual_cost"] - 0.014) < 1e-12 and abs(fee_test["holding_cost_5y"] - 0.001) < 1e-12
    assert _share_preference("测试基金I") > 0
    assert _wrapper_type("QDII指数型") == "QDII" and _coarse_type("QDII指数型") == "指数"
    share_a = dict(funds[0]); share_a.update({"code":"880001","name":"同底层长期基金A","fees_verified":True})
    share_a["fees"] = {"purchase_fee":0.012,"sales_service_fee_annual":0.0,"redemption_fee_3y":0.0,"redemption_fee_5y":0.0,"redemption_fee_10y":0.0}
    share_a.update(_holding_costs(share_a["fees"]))
    share_c = dict(share_a); share_c.update({"code":"880002","name":"同底层长期基金C"})
    share_c["fees"] = {"purchase_fee":0.0,"sales_service_fee_annual":0.002,"redemption_fee_3y":0.0,"redemption_fee_5y":0.0,"redemption_fee_10y":0.0}
    share_c.update(_holding_costs(share_c["fees"]))
    assert ranker._choose_share_classes([share_a,share_c],3)[0]["code"] == "880002"
    assert ranker._choose_share_classes([share_a,share_c],10)[0]["code"] == "880001"
    duplicate = dict(funds[0]); duplicate["code"]="889999"; duplicate["name"]="测试基金0C"
    _duplicate_snaps, duplicate_info = ranker._build_snapshots(funds + [duplicate])
    assert duplicate_info["duplicate_shares_removed"] == 1
    checks.append(("OK", "A/C/I训练与OOS按底层基金去重；推荐份额随3/5/10年真实费率成本切换"))

    fixed_return, fixed_daily = ranker._fixed_weight_portfolio_path([
        {"dates":["2026-01-02","2026-01-05"],"returns":[0.10,0.0]},
        {"dates":["2026-01-02","2026-01-05"],"returns":[0.0,0.10]},
    ])
    assert abs(fixed_return-0.10) < 1e-12 and abs(_compound(fixed_daily)-fixed_return) < 1e-12
    checks.append(("OK", "OOS收益/回撤/Sortino共用初始等权买入并持有的同一组合NAV"))

    # Candidate-pool sync + insufficient-coverage gate.
    active = [dict(fund) for fund in (funds[:48] if full else funds)]
    removed_code = active[0]["code"]
    new_code = "999999"
    template = dict(active[1])
    template["code"], template["name"] = new_code, "新增测试基金I"
    template["availability_declared_at"] = _now_iso()

    def availability_row(fund):
        return {
            "code": fund["code"], "name": fund["name"], "type": fund["type"],
            "availability_declared": True, "availability_status": "confirmed_purchasable", "availability_declared_at": _now_iso(),
            "availability_source": "self-test", "availability_evidence": "self-test",
            "fees_verified": True, "fees": fund.get("fees") or {}, **_holding_costs(fund.get("fees") or {}),
            "available_from": "2020-01-01", "available_to": "", "availability_history": fund.get("availability_history") or [],
            "share_class": "I" if fund["code"] == new_code else "A",
        }

    availability_map = {f["code"]: availability_row(f) for f in active[1:]}
    availability_map[new_code] = availability_row(template)

    class FakeAvailability:
        def snapshot(self):
            return availability_map

    class RefreshSource:
        def all_funds(self):
            return []
        def update_history(self, code, cached):
            return {"dates": list(cached["dates"]), "returns": list(cached["returns"]), "latest_nav": cached.get("latest_nav"), "latest_date": cached.get("latest_date", "")}
        def history(self, code):
            assert code == new_code
            return {
                "dates": template["dates"], "returns": template["returns"],
                "latest_nav": template["latest_nav"], "latest_date": template["latest_date"],
            }
        def latest_many(self, codes):
            received_codes = list(codes)[:max(1, int(len(codes) * 0.94))]
            rows = {code: {"code": code, "nav": 1.0, "day_change": 0.0, "nav_date": "2026-08-15"} for code in received_codes}
            return {
                "rows": rows, "requested": len(codes), "received": len(rows),
                "failed_codes": [c for c in codes if c not in rows], "errors": [],
            }

    refresh_store = DummyStore(active, model)
    refresh_engine = AnalysisEngine(source=RefreshSource(), availability=FakeAvailability(), store=refresh_store)
    refresh_engine.funds = active
    outcome = refresh_engine.refresh_latest("均衡")
    active_codes = {f["code"] for f in refresh_engine.funds}
    assert removed_code not in active_codes and new_code in active_codes
    assert outcome["ranking_updated"] is False and outcome["coverage"] < REFRESH_MIN_COVERAGE
    assert "排名未更新" in outcome["status"]
    checks.append(("OK", "自适应刷新同步 new/removed 候选；低覆盖率不写入部分净值排名"))

    class PriorityGapSource(RefreshSource):
        def __init__(self, omit_code):
            self.omit_code = omit_code
        def latest_many(self, codes):
            rows = {code:{"code":code,"nav":1.0,"day_change":0.0,"nav_date":"2026-08-15"} for code in codes if code != self.omit_code}
            return {"rows":rows,"requested":len(codes),"received":len(rows),"failed_codes":[self.omit_code],"errors":[]}

    predicted_pool = [dict(fund) for fund in active[1:]] + [dict(template)]
    priority_code = ranker.score(predicted_pool, model, "均衡", {})[0]["code"]
    priority_engine = AnalysisEngine(
        source=PriorityGapSource(priority_code), availability=FakeAvailability(),
        store=DummyStore(active, model),
    )
    priority_engine.funds = [dict(fund) for fund in active]
    priority_engine.market_funds = [dict(fund) for fund in active]
    priority_outcome = priority_engine.refresh_latest("均衡")
    assert priority_outcome["coverage"] >= REFRESH_MIN_COVERAGE
    assert priority_outcome["priority_complete"] is False and priority_outcome["ranking_updated"] is False
    checks.append(("OK", "最新净值采用总体覆盖 + Top候选必须完整双层门槛；总体达标也不掩盖关键缺口"))

    policy = SmartRefreshPolicy(random.Random(7))
    pending_time = _dt.datetime(2026, 8, 17, 16, 30, tzinfo=CHINA_TZ)
    quiet_time = _dt.datetime(2026, 8, 23, 2, 0, tzinfo=CHINA_TZ)
    pending_results = [{"latest_date": "2026-08-14"}]
    fast = policy.initial_delay(pending_results, pending_time)
    quiet = policy.initial_delay(pending_results, quiet_time)
    assert fast < quiet and fast < 120 and quiet >= 700
    low1 = policy.on_success({"coverage": 0.90, "results": pending_results}, pending_time)
    low2 = policy.on_success({"coverage": 0.90, "results": pending_results}, pending_time)
    assert low2 > low1
    err1 = policy.on_error(); err2 = policy.on_error()
    assert err2 > err1
    checks.append(("OK", "智能调度：时段/净值待披露感知 + 覆盖率退避 + 失败指数退避"))

    source_text = Path(__file__).read_text(encoding="utf-8")
    assert not re.search(r"^REFRESH_SECONDS\s*=", source_text, re.MULTILINE)
    checks.append(("OK", "已移除固定刷新秒数常量与固定周期调度"))

    checks.append(("OK", "标准库专家模型保留为绝对 fallback；发行版不再把“禁止第三方 ML 包”当作自测目标"))
    temp_model = BASE_DIR / ".BestAlipayFunds_model_test.json"
    temp_cache = BASE_DIR / ".BestAlipayFunds_cache_test.gz"
    try:
        _write_json(temp_model, model)
        _atomic_bytes(temp_cache, gzip.compress(b'{"ok":true}'))
        assert json.loads(temp_model.read_text(encoding="utf-8"))["version"] == MODEL_VERSION
        assert gzip.decompress(temp_cache.read_bytes()) == b'{"ok":true}'
    finally:
        temp_model.unlink(missing_ok=True); temp_cache.unlink(missing_ok=True)
    checks.append(("OK", "cache/model 原子写入"))
    assert all(Path(path).parent == BASE_DIR for path in (MODEL_PATH, CACHE_PATH, ALIPAY_FILE_PATH))
    checks.append(("OK", "AI、缓存、可购快照严格同级"))
    for status, text in checks:
        print(f"[{status}] {text}")
    print(
        f"SELF-TEST OK · {len(funds)} funds · train {model['training_samples']} · "
        f"tune {model.get('tuning_samples',0)} · deploy {model.get('deployment_validation_samples',0)} · "
        f"untouched {model['validation_samples']} · OOS RankIC {model['validation_ic']:+.3f} · "
        f"quality {model['model_quality']:+.3f}"
    )


def _self_test(full=False):
    """Run every disk-touching self-test inside an isolated temporary directory."""
    global BASE_DIR, CACHE_PATH, MODEL_PATH, ALIPAY_FILE_PATH
    original_paths = (BASE_DIR, CACHE_PATH, MODEL_PATH, ALIPAY_FILE_PATH)
    with tempfile.TemporaryDirectory(prefix="BestAlipayFunds-selftest-") as temp_dir:
        BASE_DIR = Path(temp_dir)
        CACHE_PATH = BASE_DIR / "BestAlipayFunds_cache.json.gz"
        MODEL_PATH = BASE_DIR / "BestAlipayFunds_AI.json"
        ALIPAY_FILE_PATH = BASE_DIR / "BestAlipayFunds_AlipayAvailability.json"
        try:
            _self_test_impl(full=full)
        finally:
            BASE_DIR, CACHE_PATH, MODEL_PATH, ALIPAY_FILE_PATH = original_paths


def _set_windows_dpi():
    if os.name != "nt":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def main():
    if sys.version_info < MIN_PYTHON:
        message = f"需要 Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} 或更高版本（64 位）。"
        print(message)
        raise SystemExit(2)
    if "--version" in sys.argv:
        print(VERSION)
        return
    if "--full-self-test" in sys.argv:
        _self_test(full=True)
        sys.stdout.flush(); sys.stderr.flush(); os._exit(0)
    if "--self-test" in sys.argv:
        _self_test(full=False)
        sys.stdout.flush(); sys.stderr.flush(); os._exit(0)
    try:
        _validate_runtime(formal=(os.name == "nt"))
    except DataError as exc:
        print(f"启动检查失败：{exc}", file=sys.stderr); raise SystemExit(2)
    if "--console" in sys.argv:
        try:
            _run_console()
        except DataError as exc:
            local = _read_json(ALIPAY_FILE_PATH, {})
            last = AlipayAvailabilitySource._payload_time(local) if isinstance(local, dict) else ""
            print("\n公开基金/净值数据源不可用，暂时无法生成 Top 10。", file=sys.stderr)
            print(str(exc), file=sys.stderr)
            print(f"最后成功的支付宝可购声明时间：{last or '无'}", file=sys.stderr)
            print("程序会自动在‘签名支付宝可购源’与‘支付宝状态未知的公开基金候选模式’之间降级，无需用户配置环境变量。请保持网络连接后重试。", file=sys.stderr)
            raise SystemExit(3)
        return
    _set_windows_dpi()
    try:
        import tkinter as tk
        from tkinter import messagebox, ttk

        root = tk.Tk()
        FundsApp(root, tk, ttk, messagebox)
        root.mainloop()
    except ImportError:
        _run_console()
    except Exception as exc:
        try:
            import tkinter.messagebox as messagebox
            messagebox.showerror(APP_NAME, f"启动失败：{exc}")
        except Exception:
            print(f"启动失败：{exc}", file=sys.stderr)
        if not isinstance(exc, DataError):
            raise


if __name__ == "__main__":
    main()
